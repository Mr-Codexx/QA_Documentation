"""
Notification Center - v4.0

Adds a persistent notification history with search, filtering, clear-all and
rich actions on top of the app's existing NotificationManager (toasts).

Architecture
  * NotificationStore  - Qt-free, testable: holds history, search, filter, unread.
  * NotificationCenter - thin bridge that ALSO calls the existing toast manager
                         so current behaviour is preserved (additive).
  * build_panel()      - optional PyQt6 panel widget (guarded import).

Usage
-----
    from notification_center import NotificationCenter
    nc = NotificationCenter(existing_toast_manager)   # may be None
    nc.notify("Export Finished", "report.docx saved", level="success",
              actions=[("Open", open_cb)])
    nc.store.search("export"); nc.store.unread_count()
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Tuple

LEVELS = ("info", "success", "warning", "error", "progress", "action")


@dataclass
class Notification:
    title: str
    message: str
    level: str
    timestamp: float
    read: bool = False
    actions: List[Tuple[str, Callable]] = field(default_factory=list)
    progress: Optional[int] = None      # 0..100 for progress notifications

    def age_text(self) -> str:
        secs = int(time.time() - self.timestamp)
        if secs < 60:
            return "just now"
        if secs < 3600:
            return f"{secs // 60}m ago"
        if secs < 86400:
            return f"{secs // 3600}h ago"
        return f"{secs // 86400}d ago"


class NotificationStore:
    """Qt-free history + query layer."""

    def __init__(self, capacity: int = 500):
        self.capacity = capacity
        self.items: List[Notification] = []
        self._subscribers: List[Callable] = []

    def add(self, title, message="", level="info", actions=None, progress=None) -> Notification:
        if level not in LEVELS:
            level = "info"
        n = Notification(title=title, message=message, level=level,
                         timestamp=time.time(), actions=actions or [], progress=progress)
        self.items.insert(0, n)
        del self.items[self.capacity:]
        self._emit()
        return n

    def mark_all_read(self):
        for n in self.items:
            n.read = True
        self._emit()

    def clear(self):
        self.items.clear()
        self._emit()

    def unread_count(self) -> int:
        return sum(1 for n in self.items if not n.read)

    def filter(self, level: str = None) -> List[Notification]:
        if not level or level == "all":
            return list(self.items)
        return [n for n in self.items if n.level == level]

    def search(self, query: str) -> List[Notification]:
        q = (query or "").lower().strip()
        if not q:
            return list(self.items)
        return [n for n in self.items
                if q in n.title.lower() or q in n.message.lower()]

    def subscribe(self, cb: Callable):
        self._subscribers.append(cb)

    def _emit(self):
        for cb in self._subscribers:
            try:
                cb()
            except Exception:
                pass


class NotificationCenter:
    """Bridges history store + the app's existing toast NotificationManager."""

    def __init__(self, toast_manager=None, capacity: int = 500):
        self.toast = toast_manager
        self.store = NotificationStore(capacity)

    def notify(self, title, message="", level="info", actions=None,
               progress=None, toast: bool = True):
        n = self.store.add(title, message, level, actions, progress)
        # Preserve existing toast behaviour for non-progress notifications.
        if toast and self.toast is not None and level != "progress":
            try:
                # existing manager signature: notify(title, message, level, ...)
                self.toast.notify(title, message, level)
            except Exception:
                pass
        return n

    # convenience wrappers matching the spec's notification types
    def info(self, t, m=""):     return self.notify(t, m, "info")
    def success(self, t, m=""):  return self.notify(t, m, "success")
    def warning(self, t, m=""):  return self.notify(t, m, "warning")
    def error(self, t, m=""):    return self.notify(t, m, "error")
    def progress(self, t, pct, m=""): return self.notify(t, m, "progress", progress=pct, toast=False)


def build_panel(center: "NotificationCenter"):
    """Return a PyQt6 notification-center panel, or None if Qt unavailable."""
    try:
        from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                     QLineEdit, QPushButton, QListWidget,
                                     QListWidgetItem, QComboBox)
        from PyQt6.QtCore import Qt
    except Exception:
        return None

    COLORS = {"info": "#2563EB", "success": "#059669", "warning": "#D97706",
              "error": "#DC2626", "progress": "#7C3AED", "action": "#0891B2"}

    panel = QWidget()
    lay = QVBoxLayout(panel)

    head = QHBoxLayout()
    title = QLabel("Notifications"); title.setStyleSheet("font-size:16px;font-weight:700;")
    clear = QPushButton("Clear All"); clear.setProperty("variant", "ghost")
    head.addWidget(title); head.addStretch(1); head.addWidget(clear)
    lay.addLayout(head)

    controls = QHBoxLayout()
    search = QLineEdit(); search.setPlaceholderText("Search notifications...")
    flt = QComboBox(); flt.addItems(["all", *LEVELS])
    controls.addWidget(search); controls.addWidget(flt)
    lay.addLayout(controls)

    lst = QListWidget(); lay.addWidget(lst)

    def refresh():
        items = center.store.search(search.text())
        lvl = flt.currentText()
        if lvl != "all":
            items = [n for n in items if n.level == lvl]
        lst.clear()
        for n in items:
            dot = COLORS.get(n.level, "#6B7280")
            text = f"  {n.title} — {n.message}    ({n.age_text()})"
            it = QListWidgetItem(text)
            it.setForeground(Qt.GlobalColor.darkGray if n.read else Qt.GlobalColor.black)
            lst.addItem(it)

    clear.clicked.connect(lambda: (center.store.clear(), refresh()))
    search.textChanged.connect(refresh)
    flt.currentTextChanged.connect(refresh)
    center.store.subscribe(refresh)
    refresh()
    return panel


if __name__ == "__main__":
    nc = NotificationCenter(toast_manager=None)
    nc.success("Screenshot Captured", "step_03.png")
    nc.info("AI Analysis Completed", "2 observations")
    nc.error("Export Failed", "disk full")
    nc.progress("Exporting", 40)
    print("total:", len(nc.store.items), "unread:", nc.store.unread_count())
    print("search 'export':", [n.title for n in nc.store.search("export")])
    print("errors only:", [n.title for n in nc.store.filter("error")])
    nc.store.mark_all_read()
    print("unread after mark:", nc.store.unread_count())
