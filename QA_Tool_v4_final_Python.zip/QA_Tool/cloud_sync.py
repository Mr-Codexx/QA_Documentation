"""
Cloud Sync — Firebase Realtime Database (REST, offline-first).

Backend config comes from app_backend.py (developer-managed) — never the UI.
Telemetry, feedback, acknowledgements and support tickets are bound to the
authenticated user (uid + email). Inbound /broadcasts drive the in-app modals.

Offline-first: every write is queued to cloud_state.json and flushed when the
network is available. The auth id-token (if any) is sent as the DB `auth` param.
"""

from __future__ import annotations

import json
import os
import platform
import time
import uuid
from typing import Dict, List

try:
    import requests
except Exception:  # pragma: no cover
    requests = None

from app_backend import FIREBASE_DB_URL, backend_configured


def store_onboarding(uid, id_token, data):
    """Best-effort write of onboarding answers to /onboarding/<uid> in Realtime DB."""
    if requests is None or not uid:
        return False
    base = (FIREBASE_DB_URL or "").rstrip("/")
    if not base:
        return False
    url = f"{base}/onboarding/{uid}.json"
    if id_token:
        url += f"?auth={id_token}"
    try:
        payload = dict(data or {})
        payload["ts"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        requests.patch(url, json=payload, timeout=10)
        return True
    except Exception:
        return False


class CloudConfig:
    """Developer-managed; not user-editable."""
    def __init__(self, base_path="."):
        self.database_url = (FIREBASE_DB_URL or "").rstrip("/")
        self.auth_token = ""          # set at runtime to the Firebase id token
        self.poll_interval = 2
        self.enabled = backend_configured()

    @property
    def ready(self) -> bool:
        return bool(self.enabled and self.database_url)


class FirebaseClient:
    def __init__(self, config: CloudConfig):
        self.config = config

    def _url(self, path):
        url = f"{self.config.database_url}/{path.strip('/')}.json"
        if self.config.auth_token:
            url += f"?auth={self.config.auth_token}"
        return url

    def _request(self, method, path, data=None, timeout=10):
        if requests is None or not self.config.ready:
            return None
        r = requests.request(method, self._url(path),
                             json=data if data is not None else None, timeout=timeout)
        r.raise_for_status()
        try:
            return r.json()
        except Exception:
            return None

    def get(self, p):        return self._request("GET", p)
    def put(self, p, d):     return self._request("PUT", p, d)
    def patch(self, p, d):   return self._request("PATCH", p, d)
    def post(self, p, d):    return self._request("POST", p, d)


class CloudSync:
    STATE_FILE = "cloud_state.json"

    def __init__(self, base_path="."):
        self.base_path = base_path
        self.config = CloudConfig(base_path)
        self.client = FirebaseClient(self.config)
        self.state_path = os.path.join(base_path, self.STATE_FILE)
        self.state = {"install_id": "", "first_seen": "", "uid": "", "email": "", "name": "",
                      "seen_broadcasts": [], "counters": {}, "outbox": [],
                      "cached_broadcasts": []}
        self._load()
        if not self.state["install_id"]:
            self.state["install_id"] = uuid.uuid4().hex[:16]
            self.state["first_seen"] = self._now()
            self._save()

    # ---- persistence ----
    def _load(self):
        if os.path.exists(self.state_path):
            try:
                self.state.update(json.load(open(self.state_path, encoding="utf-8")))
            except Exception:
                pass

    def _save(self):
        try:
            json.dump(self.state, open(self.state_path, "w", encoding="utf-8"), indent=2)
        except Exception:
            pass

    @staticmethod
    def _now():
        return time.strftime("%Y-%m-%dT%H:%M:%S")

    @property
    def install_id(self): return self.state["install_id"]
    @property
    def enabled(self): return self.config.ready

    # ---- identity ----
    def bind_user(self, uid, email, name=""):
        self.state["uid"] = uid or ""
        self.state["email"] = email or ""
        self.state["name"] = name or self.state.get("name","")
        self._save()

    def set_id_token(self, token):
        self.config.auth_token = token or ""

    def _identity(self):
        return {"install_id": self.install_id,
                "uid": self.state.get("uid", ""),
                "email": self.state.get("email", ""),
                "name": self.state.get("name", "")}

    # ---- outbound queue ----
    def _enqueue(self, method, path, data):
        self.state["outbox"].append({"method": method, "path": path, "data": data})
        self._save()

    def track_event(self, name, **props):
        d = self._identity(); d.update({"name": name, "props": props, "ts": self._now()})
        self._enqueue("POST", "events", d)

    def track_feature(self, feature, action):
        # action: viewed | opened | dismissed
        self.track_event(f"feature_{action}", feature=feature)

    def bump(self, counter, n=1):
        self.state["counters"][counter] = self.state["counters"].get(counter, 0) + n
        self._save()

    def register_install(self, app_version="4.0.0"):
        d = self._identity()
        d.update({"os": f"{platform.system()} {platform.release()}",
                  "app_version": app_version, "first_seen": self.state["first_seen"],
                  "last_seen": self._now(), "counters": self.state["counters"]})
        self._enqueue("PATCH", f"installs/{self.install_id}", d)

    def heartbeat(self, app_version="4.0.0"):
        self._enqueue("PATCH", f"installs/{self.install_id}",
                      {"last_seen": self._now(), "app_version": app_version,
                       "uid": self.state.get("uid", ""), "email": self.state.get("email", ""),
                       "counters": self.state["counters"]})

    def acknowledge(self, announcement_id, app_version="4.0.0"):
        d = self._identity()
        d.update({"announcement_id": announcement_id, "app_version": app_version,
                  "ts": self._now()})
        self._enqueue("POST", "acknowledgements", d)

    def log_export(self, kind):
        """Record "<user> exported <kind> at <time>" to the backend."""
        d = self._identity()
        d.update({"type": kind, "ts": self._now()})
        self._enqueue("POST", "export_logs", d)

    def is_blocked(self) -> bool:
        """True if the admin has blocked this user (via the NextJS portal)."""
        if not self.enabled:
            return False
        uid = self.state.get("uid") or self.install_id
        try:
            v = self.client.get(f"blocks/{uid}")
            if isinstance(v, dict):
                return bool(v.get("blocked", True))
            return bool(v)
        except Exception:
            return False

    def send_chat(self, text):
        uid = self.state.get("uid") or self.install_id
        d = self._identity(); d.update({"from": "user", "text": text, "ts": self._now()})
        self._enqueue("POST", f"support_chats/{uid}/messages", d)

    def fetch_chat(self):
        if not self.enabled:
            return []
        uid = self.state.get("uid") or self.install_id
        try:
            raw = self.client.get(f"support_chats/{uid}/messages") or {}
        except Exception:
            return []
        msgs = [{"id": k, **v} for k, v in (raw.items() if isinstance(raw, dict) else [])]
        msgs.sort(key=lambda m: str(m.get("ts", "")))
        return msgs

    def submit_feedback(self, rating, comment="", app_version="4.0.0"):
        d = self._identity()
        d.update({"rating": rating, "comment": comment,
                  "app_version": app_version, "ts": self._now()})
        self._enqueue("POST", "feedback", d)

    def submit_support_ticket(self, subject, message, contact=""):
        d = self._identity()
        d.update({"subject": subject, "message": message, "contact": contact,
                  "status": "open", "ts": self._now()})
        self._enqueue("POST", "support_tickets", d)

    def flush(self) -> int:
        if not self.enabled or requests is None:
            return 0
        sent, remaining = 0, []
        for it in self.state["outbox"]:
            try:
                getattr(self.client, it["method"].lower())(it["path"], it["data"])
                sent += 1
            except Exception:
                remaining.append(it)
        self.state["outbox"] = remaining
        self._save()
        return sent

    # ---- inbound broadcasts ----
    def fetch_broadcasts(self) -> List[Dict]:
        if not self.enabled:
            return self.state["cached_broadcasts"]
        try:
            raw = self.client.get("broadcasts") or {}
        except Exception:
            return self.state["cached_broadcasts"]
        items = []
        for pid, val in (raw.items() if isinstance(raw, dict) else []):
            if not isinstance(val, dict) or val.get("active") is False:
                continue
            items.append({"id": pid, "type": val.get("type", "announcement"),
                          "title": val.get("title", "(untitled)"),
                          "body": val.get("body", ""), "version": val.get("version", ""),
                          "level": val.get("level", "info"), "ts": val.get("ts", 0)})
        items.sort(key=lambda x: x.get("ts", 0), reverse=True)
        self.state["cached_broadcasts"] = items
        self._save()
        return items

    def unseen(self, items):
        seen = set(self.state["seen_broadcasts"])
        return [i for i in items if i["id"] not in seen]

    def mark_seen(self, items):
        ids = set(self.state["seen_broadcasts"]); ids.update(i["id"] for i in items)
        self.state["seen_broadcasts"] = list(ids); self._save()


def make_worker(cloud: CloudSync, app_version="4.0.0"):
    try:
        from PyQt6.QtCore import QThread, pyqtSignal
    except Exception:
        return None

    class CloudSyncWorker(QThread):
        broadcasts_updated = pyqtSignal(list)
        new_broadcast = pyqtSignal(dict)
        blocked = pyqtSignal()

        def __init__(self):
            super().__init__(); self._running = True

        def run(self):
            while self._running:
                try:
                    cloud.flush()
                    if cloud.is_blocked():
                        self.blocked.emit()
                    items = cloud.fetch_broadcasts()
                    self.broadcasts_updated.emit(items)
                    for it in cloud.unseen(items):
                        self.new_broadcast.emit(it)
                    cloud.mark_seen(items)
                except Exception:
                    pass
                for _ in range(max(1, cloud.config.poll_interval)):
                    if not self._running:
                        break
                    self.msleep(1000)

        def stop(self):
            self._running = False; self.quit(); self.wait(2000)

    return CloudSyncWorker()


if __name__ == "__main__":
    import tempfile, app_backend
    app_backend.FIREBASE_DB_URL = "https://demo.firebaseio.com"
    app_backend.FIREBASE_API_KEY = "k"
    d = tempfile.mkdtemp()
    cs = CloudSync(d)
    cs.config.database_url = "https://demo.firebaseio.com"; cs.config.enabled = True
    cs.bind_user("uid9", "sachin@x.com"); cs.set_id_token("IDTOKEN")
    backend = {"events": [], "feedback": [], "acknowledgements": [], "installs": {}}
    def fake(method, path, data=None, timeout=10):
        key = path.strip("/").split("/")[0]
        if method == "POST": backend.setdefault(key, []).append(data); return {"name": "x"}
        if method == "PATCH": backend["installs"][path.split("/")[-1]] = data; return data
        return None
    cs.client._request = fake
    cs.register_install("4.0.0"); cs.bump("logins"); cs.track_event("export", fmt="PDF")
    cs.acknowledge("ann1", "4.0.0"); cs.submit_feedback(5, "great")
    assert cs.flush() == 4
    assert backend["acknowledgements"][0]["email"] == "sachin@x.com"
    assert backend["events"][0]["uid"] == "uid9"
    assert backend["installs"]["%s" % cs.install_id]["email"] == "sachin@x.com"
    print("auth url has token:", cs.client._url("events").endswith("auth=IDTOKEN"))
    print("ALL CLOUD (auth-bound) TESTS PASSED")
