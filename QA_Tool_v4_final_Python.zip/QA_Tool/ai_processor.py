"""
AI Processor - Handles Groq API integration for screenshot analysis
"""

import os
import base64
import json
import re
import time
from typing import Optional, Dict
import requests
from pathlib import Path


class AIProcessor:
    """Process screenshots using Groq API with active models"""
   
    # 🔑 YOUR API KEY
    GROQ_API_KEY = "xxxx"  # Your actual API key
   
    # Working models
    VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"
    TEXT_MODEL = "llama-3.3-70b-versatile"
    
    # Rate limiting settings
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds
    BATCH_DELAY = 1  # delay between API calls in batch
    
    def __init__(self, api_key: str = None):
        # Use hardcoded key
        if self.GROQ_API_KEY and self.GROQ_API_KEY != "gsk_xxxxx" and len(self.GROQ_API_KEY) > 10:
            self.api_key = self.GROQ_API_KEY
        else:
            self.api_key = api_key or os.environ.get("GROQ_API_KEY", "")
        
        self.api_url = "https://api.groq.com/openai/v1/chat/completions"
        
        # Try to load from config file as fallback
        if not self.api_key or self.api_key == "gsk_xxxxx":
            self.api_key = self.load_api_key_from_config()
        
        self.fallback_mode = not self.api_key or self.api_key == "gsk_xxxxx"
        
        if self.fallback_mode:
            print("⚠️ No valid Groq API key found. Running in fallback mode.")
        else:
            print("✅ Groq API key loaded successfully!")
            masked_key = self.api_key[:8] + "..." + self.api_key[-4:] if len(self.api_key) > 12 else "***"
            print(f"   Using API key: {masked_key}")
            print(f"   Vision Model: {self.VISION_MODEL}")
            print(f"   Text Model: {self.TEXT_MODEL}")
    
    def load_api_key_from_config(self) -> str:
        """Load API key from config file (backup method)"""
        config_path = Path("api_config.json")
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    return config.get("groq_api_key", "")
            except:
                pass
        return ""
    
    SYSTEM_HELP = (
        "You are the in-app help assistant for the 'AI QA Documentation Assistant', a "
        "Windows desktop tool for QA testers. It captures full/region screenshots, "
        "auto-describes them with AI, lets users annotate (pen, highlighter, rectangle, "
        "circle, arrow, text, blur), tracks test steps, and exports professional reports "
        "(HTML, PDF, Word, Excel, Markdown and an Enterprise DOCX). It also has a Dashboard, "
        "Notification Center, Global Search, Screenshot Comparison, a Defect Assistant, themes, "
        "OneDrive export and login. Answer concisely and practically with short numbered steps "
        "when explaining how to do something. Only answer about this tool and QA documentation."
    )

    def chat(self, question, history=None):
        """Groq-powered Q&A about the tool (with an offline FAQ fallback)."""
        history = history or []
        if self.fallback_mode:
            return self._help_fallback(question)
        try:
            import requests
            msgs = [{"role": "system", "content": self.SYSTEM_HELP}]
            for h in history[-6:]:
                msgs.append({"role": h.get("role", "user"), "content": h.get("content", "")})
            msgs.append({"role": "user", "content": question})
            payload = {"model": self.TEXT_MODEL, "messages": msgs,
                       "temperature": 0.3, "max_tokens": 500}
            headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
            r = requests.post(self.api_url, headers=headers, json=payload, timeout=30)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"].strip()
        except Exception:
            return self._help_fallback(question)

    def _help_fallback(self, q):
        ql = (q or "").lower()
        faq = [
            (("export", "report", "docx", "pdf", "word"),
             "To export: open the EXPORT section in the sidebar, pick a format (HTML, PDF, Word, "
             "Excel, Markdown or Enterprise DOCX), then click Export Session."),
            (("screenshot", "capture", "snip"),
             "Use the CAPTURE buttons: Full Screenshot grabs the whole screen; Snip Area lets you "
             "drag a region. Each capture becomes a test step and is auto-described by AI."),
            (("highlight", "annotate", "draw", "edit", "editor"),
             "After a snip the Screenshot Editor opens. Pick Pen, Highlighter, Rectangle, Circle, "
             "Arrow or Text. Your last tool and colours are remembered for next time."),
            (("compare", "difference", "regression"),
             "Open Tools -> Compare Screenshots, choose a BEFORE and AFTER image, and the tool "
             "highlights what changed."),
            (("defect", "bug"),
             "Select a step, then Tools -> Defect Assistant to auto-generate a defect with "
             "severity, priority and steps to reproduce."),
            (("theme", "dark", "colour", "color"),
             "Go to Settings -> Appearance to switch themes (Light, Dark, Corporate Blue, Healthcare)."),
            (("session", "start", "begin"),
             "Click Start New Session in the sidebar, capture screenshots and notes, then End Session."),
            (("tour", "how", "use", "start using", "guide"),
             "Quick tour: 1) Start New Session  2) Full Screenshot or Snip Area to capture  "
             "3) annotate in the editor  4) review AI notes  5) Export Session as a report."),
        ]
        for keys, ans in faq:
            if any(k in ql for k in keys):
                return ans
        return ("I can help with capturing, annotating, comparing screenshots, generating defects "
                "and exporting reports. Try: 'How do I export a Word report?'  For anything else, "
                "use Live Support to reach the admin.")

    def analyze_screenshot(self, image_path: str, custom_prompt: str = None, retry_count: int = 0) -> Optional[Dict]:
        """
        Analyze screenshot and generate QA description with retry logic
        """
        
        if self.fallback_mode:
            return self._get_fallback_analysis(image_path)
        
        try:
            # Encode image to base64
            with open(image_path, "rb") as f:
                image_data = base64.b64encode(f.read()).decode()
            
            # Get image dimensions
            try:
                from PIL import Image
                img = Image.open(image_path)
                width, height = img.size
                dimensions_info = f"({width}x{height} pixels)"
            except:
                dimensions_info = ""
            
            # Simplified prompt
            if custom_prompt is None:
                prompt = f"""Analyze this UI screenshot {dimensions_info} for QA testing.

Provide ONLY a JSON response with these 4 fields:
- description: What action or state is shown? (one sentence)
- expected_behavior: What should happen? (one sentence)
- actual_observation: What is actually visible? (one sentence)
- bug_hint: Any issues found? If none, say "No obvious issues"

Example: {{"description": "User clicks login button", "expected_behavior": "User should be logged in", "actual_observation": "Login page shown", "bug_hint": "No obvious issues"}}

Now analyze this screenshot and respond with ONLY the JSON object:"""
            else:
                prompt = custom_prompt
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": self.VISION_MODEL,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/png;base64,{image_data}"
                                }
                            }
                        ]
                    }
                ],
                "temperature": 0.2,
                "max_tokens": 300
            }
            
            print(f"🤖 Analyzing screenshot...")
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=30)
            
            # Handle rate limiting with retry
            if response.status_code == 429:
                if retry_count < self.MAX_RETRIES:
                    wait_time = self.RETRY_DELAY * (retry_count + 1)
                    print(f"⚠️ Rate limit hit. Waiting {wait_time} seconds before retry {retry_count + 1}/{self.MAX_RETRIES}...")
                    time.sleep(wait_time)
                    return self.analyze_screenshot(image_path, custom_prompt, retry_count + 1)
                else:
                    print(f"❌ Rate limit exceeded after {self.MAX_RETRIES} retries")
                    return self._get_fallback_analysis(image_path)
            
            if response.status_code == 200:
                result = response.json()
                content = result["choices"][0]["message"]["content"]
                
                analysis = self._extract_json_from_response(content)
                if analysis:
                    print(f"✅ Analysis complete!")
                    return analysis
                else:
                    return self._get_fallback_analysis(image_path)
            else:
                print(f"❌ API Error: {response.status_code}")
                return self._get_fallback_analysis(image_path)
                
        except Exception as e:
            print(f"❌ Error: {e}")
            return self._get_fallback_analysis(image_path)
    
    def analyze_screenshot_with_highlights(self, image_path: str, highlight_regions: list = None, custom_prompt: str = None, retry_count: int = 0) -> Optional[Dict]:
        """
        Analyze screenshot with focus on highlighted regions
        Args:
            image_path: Path to screenshot
            highlight_regions: List of (x, y, width, height) tuples for highlighted areas
            custom_prompt: Optional custom prompt
            retry_count: Retry counter for rate limiting
        """
        
        if self.fallback_mode:
            return self._get_fallback_analysis_with_highlights(image_path, highlight_regions)
        
        if not highlight_regions:
            # No highlights, use regular analysis
            return self.analyze_screenshot(image_path, custom_prompt, retry_count)
        
        try:
            # Encode image to base64
            with open(image_path, "rb") as f:
                image_data = base64.b64encode(f.read()).decode()
            
            # Get image dimensions
            try:
                from PIL import Image
                img = Image.open(image_path)
                width, height = img.size
                dimensions_info = f"({width}x{height} pixels)"
            except:
                dimensions_info = ""
            
            # Build prompt that FOCUSES on highlighted regions
            if custom_prompt is None:
                prompt = self._build_highlight_focused_prompt(highlight_regions, dimensions_info)
            else:
                prompt = custom_prompt
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": self.VISION_MODEL,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/png;base64,{image_data}"
                                }
                            }
                        ]
                    }
                ],
                "temperature": 0.2,
                "max_tokens": 500  # Increased for more detailed highlight analysis
            }
            
            print(f"🤖 Analyzing screenshot with {len(highlight_regions)} highlighted region(s)...")
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=30)
            
            # Handle rate limiting with retry
            if response.status_code == 429:
                if retry_count < self.MAX_RETRIES:
                    wait_time = self.RETRY_DELAY * (retry_count + 1)
                    print(f"⚠️ Rate limit hit. Waiting {wait_time} seconds before retry {retry_count + 1}/{self.MAX_RETRIES}...")
                    time.sleep(wait_time)
                    return self.analyze_screenshot_with_highlights(image_path, highlight_regions, custom_prompt, retry_count + 1)
                else:
                    print(f"❌ Rate limit exceeded after {self.MAX_RETRIES} retries")
                    return self._get_fallback_analysis_with_highlights(image_path, highlight_regions)
            
            if response.status_code == 200:
                result = response.json()
                content = result["choices"][0]["message"]["content"]
                
                analysis = self._extract_json_from_response(content)
                if analysis:
                    # Add highlight-specific metadata
                    analysis['highlight_regions_analyzed'] = len(highlight_regions)
                    analysis['focus_area'] = 'highlighted content'
                    print(f"✅ Highlight-focused analysis complete!")
                    return analysis
                else:
                    return self._get_fallback_analysis_with_highlights(image_path, highlight_regions)
            else:
                print(f"❌ API Error: {response.status_code}")
                return self._get_fallback_analysis_with_highlights(image_path, highlight_regions)
                
        except Exception as e:
            print(f"❌ Error in highlight analysis: {e}")
            return self._get_fallback_analysis_with_highlights(image_path, highlight_regions)
    
    def _build_highlight_focused_prompt(self, highlight_regions: list, dimensions_info: str) -> str:
        """
        Build a prompt that specifically asks AI to focus on highlighted regions
        """
        regions_desc = []
        for i, (x, y, w, h) in enumerate(highlight_regions, 1):
            regions_desc.append(f"Region {i}: at position ({x}, {y}) with size {w}×{h} pixels")
        
        regions_text = "\n".join(regions_desc)
        
        prompt = f"""IMPORTANT: This screenshot contains HIGHLIGHTED REGIONS that the user specifically wants you to focus on.

Screenshot dimensions: {dimensions_info}

Highlighted regions to focus on:
{regions_text}

Your task: Analyze ONLY the highlighted regions in this UI screenshot for QA testing. Pay special attention to what is being emphasized.

Provide a JSON response with these 6 fields:
- description: What action or state is shown in the HIGHLIGHTED areas? (focus on highlighted content)
- expected_behavior: What should happen based on what's highlighted? (one sentence)
- actual_observation: What is actually visible in the highlighted regions? (be specific)
- bug_hint: Any issues found in the highlighted areas? If none, say "No issues detected in highlighted regions"
- highlight_summary: Summary of what the user is trying to draw attention to (one sentence)
- priority: Rate the importance of highlighted issues as Critical/High/Medium/Low (if no issues, say "None")

Example response:
{{
    "description": "Login button is highlighted - user attempting to authenticate",
    "expected_behavior": "User should be redirected to dashboard after successful login",
    "actual_observation": "Error message 'Invalid credentials' appears below the login form",
    "bug_hint": "Error message styling doesn't match design specs - red text too small",
    "highlight_summary": "User highlighting authentication flow issue",
    "priority": "High"
}}

Now analyze this screenshot and respond with ONLY the JSON object, focusing specifically on what's highlighted:"""

        return prompt
    
    def _get_fallback_analysis_with_highlights(self, image_path: str, highlight_regions: list = None) -> Dict:
        """
        Fallback analysis that acknowledges highlighted regions
        """
        import hashlib
        
        # Generate consistent hash for the image
        with open(image_path, "rb") as f:
            img_hash = hashlib.md5(f.read()).hexdigest()[:8]
        
        # Get basic image info
        try:
            from PIL import Image
            img = Image.open(image_path)
            dimensions = f"{img.width}x{img.height}"
        except:
            dimensions = "unknown"
        
        highlight_count = len(highlight_regions) if highlight_regions else 0
        
        if highlight_count > 0:
            return {
                "description": f"User highlighted {highlight_count} area(s) in this screenshot ({dimensions})",
                "expected_behavior": "Application should behave as expected in the highlighted areas",
                "actual_observation": f"Screenshot shows current state with {highlight_count} highlighted regions for attention",
                "bug_hint": "Review the highlighted areas for potential edge cases or unexpected behavior",
                "highlight_summary": f"User marked {highlight_count} region(s) for attention in this test step",
                "priority": "Medium"
            }
        else:
            return self._get_fallback_analysis(image_path)
    
    def batch_analyze(self, image_paths: list, progress_callback=None, delay: float = 1.5) -> list:
        """
        Analyze multiple screenshots with delays between calls to avoid rate limits
        
        Args:
            image_paths: List of image paths to analyze
            progress_callback: Optional callback function(step, total)
            delay: Delay in seconds between API calls (default 1.5)
        """
        results = []
        total = len(image_paths)
        
        print(f"\n🤖 Batch analyzing {total} screenshots...")
        print(f"   Delay between calls: {delay} seconds (to avoid rate limits)")
        
        for i, path in enumerate(image_paths, 1):
            if progress_callback:
                progress_callback(i, total)
            
            print(f"\n   Processing {i}/{total}: {os.path.basename(path)}")
            
            # Add delay between calls (except for first)
            if i > 1:
                time.sleep(delay)
            
            result = self.analyze_screenshot(path)
            if result:
                results.append(result)
            else:
                results.append(self._get_fallback_analysis(path))
        
        print(f"\n✅ Batch analysis complete! {len(results)}/{total} successful")
        return results
    
    def batch_analyze_with_highlights(self, image_paths_with_highlights: list, progress_callback=None, delay: float = 1.5) -> list:
        """
        Batch analyze multiple screenshots with their respective highlight regions
        
        Args:
            image_paths_with_highlights: List of tuples (image_path, highlight_regions)
            progress_callback: Optional callback function(step, total)
            delay: Delay in seconds between API calls
        """
        results = []
        total = len(image_paths_with_highlights)
        
        print(f"\n🤖 Batch analyzing {total} screenshots with highlights...")
        print(f"   Delay between calls: {delay} seconds (to avoid rate limits)")
        
        for i, (path, highlights) in enumerate(image_paths_with_highlights, 1):
            if progress_callback:
                progress_callback(i, total)
            
            highlight_count = len(highlights) if highlights else 0
            print(f"\n   Processing {i}/{total}: {os.path.basename(path)} ({highlight_count} highlight(s))")
            
            # Add delay between calls (except for first)
            if i > 1:
                time.sleep(delay)
            
            if highlight_count > 0:
                result = self.analyze_screenshot_with_highlights(path, highlights)
            else:
                result = self.analyze_screenshot(path)
            
            if result:
                results.append(result)
            else:
                results.append(self._get_fallback_analysis_with_highlights(path, highlights))
        
        print(f"\n✅ Batch analysis complete! {len(results)}/{total} successful")
        return results
    
    def _extract_json_from_response(self, content: str) -> Optional[Dict]:
        """Extract JSON from various response formats"""
        try:
            # Try direct parse first
            return json.loads(content)
        except:
            pass
        
        # Try to find JSON in markdown code blocks
        json_pattern = r'```(?:json)?\s*(\{.*?\})\s*```'
        matches = re.findall(json_pattern, content, re.DOTALL)
        for match in matches:
            try:
                return json.loads(match)
            except:
                continue
        
        # Try to find any JSON object
        json_pattern = r'\{[^{}]*"description"[^{}]*\}'
        matches = re.findall(json_pattern, content, re.DOTALL)
        for match in matches:
            try:
                return json.loads(match)
            except:
                continue
        
        return None
    
    def _make_api_call(self, prompt: str, is_vision: bool = False, image_path: str = None, retry_count: int = 0) -> Optional[str]:
        """Make API call to Groq for text generation with retry logic"""
        if self.fallback_mode:
            return None
        
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            messages = []
            
            if is_vision and image_path:
                # Vision API call
                with open(image_path, "rb") as f:
                    image_data = base64.b64encode(f.read()).decode()
                
                messages = [{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{image_data}"
                            }
                        }
                    ]
                }]
                model = self.VISION_MODEL
            else:
                # Text-only API call
                messages = [{"role": "user", "content": prompt}]
                model = self.TEXT_MODEL
            
            payload = {
                "model": model,
                "messages": messages,
                "temperature": 0.3,
                "max_tokens": 1000
            }
            
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=30)
            
            # Handle rate limiting
            if response.status_code == 429:
                if retry_count < self.MAX_RETRIES:
                    wait_time = self.RETRY_DELAY * (retry_count + 1)
                    print(f"⚠️ Rate limit hit. Waiting {wait_time}s before retry...")
                    time.sleep(wait_time)
                    return self._make_api_call(prompt, is_vision, image_path, retry_count + 1)
                else:
                    print(f"❌ Rate limit exceeded")
                    return None
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                print(f"API call failed: {response.status_code}")
                return None
            
        except Exception as e:
            print(f"API call failed: {e}")
            return None
    
    def _get_fallback_analysis(self, image_path: str) -> Dict:
        """Fallback analysis when API is unavailable"""
        import hashlib
        
        # Generate consistent but fake analysis based on image hash
        with open(image_path, "rb") as f:
            img_hash = hashlib.md5(f.read()).hexdigest()[:8]
        
        # Try to get basic image info
        try:
            from PIL import Image
            img = Image.open(image_path)
            dimensions = f"{img.width}x{img.height}"
        except:
            dimensions = "unknown"
        
        return {
            "description": f"User interaction captured in screenshot {img_hash} ({dimensions})",
            "expected_behavior": "Application should respond appropriately to user action",
            "actual_observation": f"Screenshot shows current application state at the moment of capture",
            "bug_hint": "Review this step for potential edge cases or unexpected behavior"
        }
    
    def test_api_connection(self) -> bool:
        """Test if API key is working"""
        if not self.api_key or self.api_key == "gsk_xxxxx":
            print("❌ No valid API key configured")
            return False
        
        print(f"Testing API connection...")
        
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": self.TEXT_MODEL,
                "messages": [
                    {"role": "user", "content": "Say 'API works'"}
                ],
                "max_tokens": 20
            }
            
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=10)
            
            if response.status_code == 200:
                print("✅ API connection successful!")
                return True
            else:
                print(f"❌ API connection failed with status {response.status_code}")
                return False
            
        except Exception as e:
            print(f"❌ Connection error: {str(e)}")
            return False