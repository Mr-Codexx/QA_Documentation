"""
Notification Manager — Advanced toast + sound notifications
Levels: success, warning, error, info  (optional sounds)

Clean-UI rebuild:
  * card surface with soft drop shadow + accent left-border
  * fade + slide entrance / exit animations
  * thin progress bar that depletes over the toast's lifetime
  * hover to pause auto-dismiss
  * position configurable via NotificationManager(corner=..., margin=, gap=, width=)

Public API is unchanged (drop-in): NotificationManager.notify(...),
.history_sink, ._reposition(), ._remove(), ._play_sound().
"""

import os
import sys
import threading

from PyQt6.QtWidgets import (QWidget, QLabel, QHBoxLayout, QVBoxLayout,
                             QPushButton, QFrame, QGraphicsDropShadowEffect)
from PyQt6.QtCore import (Qt, QTimer, QPropertyAnimation, QEasingCurve,
                          QPoint, QParallelAnimationGroup)
from PyQt6.QtGui import QColor

# level -> (accent, soft tint, icon)
THEME = {
    "success": ("#10b981", "#0c2f26", "✓"),
    "warning": ("#f59e0b", "#33260a", "!"),
    "error":   ("#ef4444", "#331317", "✕"),
    "info":    ("#22d3ee", "#0c2a31", "i"),
    "progress":("#a78bfa", "#241f3a", "⏳"),
    "action":  ("#38bdf8", "#0c2530", "⚡"),
}

SURFACE = "#15172b"     # card background
TEXT_PRIMARY = "#f1f5f9"
TEXT_SECOND = "#9aa6c0"
SHADOW_MARGIN = 18      # space reserved around the card for its drop shadow


class ToastNotification(QWidget):
    """A single, self-contained toast popup."""

    def __init__(self, parent, title, message, level="info",
                 duration=3500, width=360):
        super().__init__(parent)
        accent, tint, icon = THEME.get(level, THEME["info"])
        self._accent = accent
        self._duration = max(800, int(duration))
        self._dismissed = False

        self.setWindowFlags(Qt.WindowType.FramelessWindowHint |
                            Qt.WindowType.Tool |
                            Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFixedWidth(width)

        # outer transparent layout leaves room for the shadow
        outer = QVBoxLayout(self)
        outer.setContentsMargins(SHADOW_MARGIN, SHADOW_MARGIN,
                                 SHADOW_MARGIN, SHADOW_MARGIN)

        # ── card ────────────────────────────────────────────────
        card = QFrame()
        card.setObjectName("card")
        card.setStyleSheet(f"""
            QFrame#card {{
                background: {SURFACE};
                border: 1px solid {accent}40;
                border-left: 4px solid {accent};
                border-radius: 12px;
            }}
        """)
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(34)
        shadow.setXOffset(0)
        shadow.setYOffset(8)
        shadow.setColor(QColor(0, 0, 0, 150))
        card.setGraphicsEffect(shadow)
        outer.addWidget(card)

        cl = QVBoxLayout(card)
        cl.setContentsMargins(14, 12, 12, 0)
        cl.setSpacing(3)

        # title row: icon badge + title + close
        row = QHBoxLayout()
        row.setSpacing(10)

        badge = QLabel(icon)
        badge.setFixedSize(24, 24)
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setStyleSheet(f"""
            background: {tint};
            color: {accent};
            border-radius: 12px;
            font-size: 13px;
            font-weight: 700;
        """)
        row.addWidget(badge)

        title_lbl = QLabel(title)
        title_lbl.setStyleSheet(
            f"color: {TEXT_PRIMARY}; font-size: 13px; font-weight: 600;")
        row.addWidget(title_lbl, 1)

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(20, 20)
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.setStyleSheet("""
            QPushButton { background: transparent; border: none;
                          color: #64708c; font-size: 12px; border-radius: 10px; }
            QPushButton:hover { background: #ffffff14; color: #e5e7eb; }
        """)
        close_btn.clicked.connect(self._dismiss)
        row.addWidget(close_btn, 0, Qt.AlignmentFlag.AlignTop)
        cl.addLayout(row)

        if message:
            msg_lbl = QLabel(message)
            msg_lbl.setStyleSheet(
                f"color: {TEXT_SECOND}; font-size: 11px; padding-left: 34px;")
            msg_lbl.setWordWrap(True)
            cl.addWidget(msg_lbl)

        cl.addSpacing(8)

        # ── progress track ──────────────────────────────────────
        track = QFrame()
        track.setFixedHeight(3)
        track.setStyleSheet("background: transparent;")
        tl = QHBoxLayout(track)
        tl.setContentsMargins(0, 0, 0, 0)
        self._bar = QFrame(track)
        self._bar.setStyleSheet(
            f"background: {accent}; border-bottom-left-radius: 10px;")
        self._bar.setFixedHeight(3)
        tl.addWidget(self._bar)
        cl.addWidget(track)

        self.adjustSize()

        # progress-bar depletion (animate maximumWidth full -> 0)
        full_w = width - 2 * SHADOW_MARGIN - 4
        self._bar.setMaximumWidth(full_w)
        self._bar_anim = QPropertyAnimation(self._bar, b"maximumWidth", self)
        self._bar_anim.setStartValue(full_w)
        self._bar_anim.setEndValue(0)
        self._bar_anim.setDuration(self._duration)
        self._bar_anim.setEasingCurve(QEasingCurve.Type.Linear)

        # auto-dismiss
        self._dismiss_timer = QTimer(self)
        self._dismiss_timer.setSingleShot(True)
        self._dismiss_timer.timeout.connect(self._dismiss)

    # ── lifecycle ───────────────────────────────────────────────
    def show_animated(self, x, y, slide_dy=24):
        """Fade + slide into final position (x, y)."""
        self.setWindowOpacity(0.0)
        self.move(x, y + slide_dy)
        self.show()

        slide = QPropertyAnimation(self, b"pos", self)
        slide.setDuration(280)
        slide.setStartValue(QPoint(x, y + slide_dy))
        slide.setEndValue(QPoint(x, y))
        slide.setEasingCurve(QEasingCurve.Type.OutCubic)

        fade = QPropertyAnimation(self, b"windowOpacity", self)
        fade.setDuration(280)
        fade.setStartValue(0.0)
        fade.setEndValue(1.0)

        self._enter = QParallelAnimationGroup(self)
        self._enter.addAnimation(slide)
        self._enter.addAnimation(fade)
        self._enter.start()

        self._bar_anim.start()
        self._dismiss_timer.start(self._duration)

    def enterEvent(self, e):
        # hover pauses the countdown
        self._dismiss_timer.stop()
        if self._bar_anim.state() == QPropertyAnimation.State.Running:
            self._bar_anim.pause()
        super().enterEvent(e)

    def leaveEvent(self, e):
        if self._bar_anim.state() == QPropertyAnimation.State.Paused:
            self._bar_anim.resume()
            remaining = self._bar_anim.duration() - self._bar_anim.currentTime()
            self._dismiss_timer.start(max(400, remaining))
        super().leaveEvent(e)

    def _dismiss(self):
        if self._dismissed:
            return
        self._dismissed = True
        self._dismiss_timer.stop()
        self._bar_anim.stop()

        fade = QPropertyAnimation(self, b"windowOpacity", self)
        fade.setDuration(200)
        fade.setStartValue(self.windowOpacity())
        fade.setEndValue(0.0)
        fade.setEasingCurve(QEasingCurve.Type.InCubic)
        fade.finished.connect(self._finalize)
        fade.start()
        self._exit = fade

    def _finalize(self):
        self.hide()
        self.deleteLater()


class NotificationManager:
    """Manages a stack of toast notifications."""

    # corner -> (is_right, is_bottom)
    _CORNERS = {
        "bottom-right": (True, True),
        "bottom-left":  (False, True),
        "top-right":    (True, False),
        "top-left":     (False, False),
    }

    def __init__(self, parent_window, corner="bottom-right",
                 margin=18, gap=10, width=360):
        self.parent = parent_window
        self._active: list[ToastNotification] = []
        self.history_sink = None            # v4.0: NotificationCenter store
        # ── position config (change these to move the toasts) ──
        self.corner = corner if corner in self._CORNERS else "bottom-right"
        self.margin = margin
        self.gap = gap
        self.width = width

    def notify(self, title: str, message: str = "", level: str = "info",
               duration: int = 3500, sound: bool = True):
        """Show a toast notification with optional sound."""
        if getattr(self, "history_sink", None) is not None:
            try:
                self.history_sink.add(title, message, level)
            except Exception:
                pass
        if sound:
            self._play_sound(level)

        toast = ToastNotification(None, title, message, level,
                                  duration, self.width)
        toast.destroyed.connect(lambda *_: self._remove(toast))
        self._active.append(toast)
        self._reposition()

    def _reposition(self):
        """Lay out the active toasts in the configured corner."""
        from PyQt6.QtGui import QGuiApplication
        screen = QGuiApplication.primaryScreen().availableGeometry()
        is_right, is_bottom = self._CORNERS[self.corner]

        x = (screen.right() - self.width - self.margin) if is_right \
            else (screen.left() + self.margin)

        if is_bottom:
            y = screen.bottom() - self.margin
            for toast in reversed(self._active):
                toast.adjustSize()
                y -= toast.height()
                toast.show_animated(x, y, slide_dy=24)
                y -= self.gap
        else:
            y = screen.top() + self.margin
            for toast in self._active:
                toast.adjustSize()
                toast.show_animated(x, y, slide_dy=-24)
                y += toast.height() + self.gap

    def _remove(self, toast):
        if toast in self._active:
            self._active.remove(toast)

    def _play_sound(self, level: str):
        """Play a sound based on level using platform APIs (never blocks/crashes)."""
        try:
            if sys.platform == "win32":
                import winsound
                sounds = {
                    "success": winsound.MB_OK,
                    "warning": winsound.MB_ICONEXCLAMATION,
                    "error":   winsound.MB_ICONHAND,
                    "info":    winsound.MB_ICONASTERISK,
                }
                mb = sounds.get(level, winsound.MB_OK)
                threading.Thread(target=lambda: winsound.MessageBeep(mb),
                                 daemon=True).start()
            elif sys.platform == "darwin":
                sounds_map = {"success": "Glass", "warning": "Sosumi",
                              "error": "Basso", "info": "Ping"}
                s = sounds_map.get(level, "Ping")
                threading.Thread(
                    target=lambda: os.system(f"afplay /System/Library/Sounds/{s}.aiff"),
                    daemon=True).start()
            else:
                threading.Thread(
                    target=lambda: os.system(
                        "paplay /usr/share/sounds/freedesktop/stereo/message.oga 2>/dev/null || "
                        "aplay /usr/share/sounds/sound-icons/glass-breaking-2.wav 2>/dev/null"),
                    daemon=True).start()
        except Exception:
            pass  # sound is optional — never crash for it
