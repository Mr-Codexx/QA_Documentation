"""
Advanced Documentation Viewer - Interactive Modal Dialog with Diagrams
"""

from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QTabWidget,
                             QTextEdit, QLabel, QPushButton, QScrollArea,
                             QWidget, QFrame, QTreeWidget, QTreeWidgetItem,
                             QSplitter, QTableWidget, QTableWidgetItem,
                             QGroupBox, QGridLayout, QProgressBar)
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QRect, QEasingCurve
from PyQt6.QtGui import QFont, QColor, QPixmap, QPainter, QPen, QBrush, QLinearGradient, QIcon, QTextDocument, QTextCursor

from ui_components import ModernButton


class DocumentationViewer(QDialog):
    """Advanced documentation viewer with diagrams and animations"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("📚 AI QA Documentation Assistant - Complete Guide")
        self.setMinimumSize(1200, 800)
        self.setModal(True)
        
        # Set window flags
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowCloseButtonHint | 
                           Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint)
        
        # Setup UI
        self.setup_ui()
        self.apply_styles()
        self.center_on_screen()
    
    def center_on_screen(self):
        """Center dialog on screen"""
        if self.parent():
            geometry = self.parent().geometry()
            x = geometry.x() + (geometry.width() - 1200) // 2
            y = geometry.y() + (geometry.height() - 800) // 2
            self.setGeometry(x, y, 1200, 800)
        else:
            screen = self.screen().geometry()
            x = (screen.width() - 1200) // 2
            y = (screen.height() - 800) // 2
            self.setGeometry(x, y, 1200, 800)
    
    def apply_styles(self):
        """Apply modern styles to dialog"""
        self.setStyleSheet("""
            QDialog {
                background-color: #1a1a2e;
            }
            QTabWidget::pane {
                border: 1px solid #0f3460;
                border-radius: 10px;
                background-color: #16213e;
            }
            QTabBar::tab {
                background-color: #16213e;
                padding: 12px 25px;
                margin-right: 5px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                font-weight: bold;
                font-size: 13px;
                color: #eee;
            }
            QTabBar::tab:selected {
                background-color: #e94560;
                color: white;
            }
            QTabBar::tab:hover {
                background-color: #0f3460;
            }
            QScrollArea {
                border: none;
                background-color: transparent;
            }
            QTextEdit {
                background-color: #16213e;
                border: 1px solid #0f3460;
                border-radius: 8px;
                padding: 15px;
                color: #eee;
                font-size: 12px;
            }
            QGroupBox {
                border: 2px solid #0f3460;
                border-radius: 10px;
                margin-top: 10px;
                font-weight: bold;
                font-size: 13px;
                color: #eee;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
                color: #e94560;
            }
            QTreeWidget {
                background-color: #16213e;
                border: 1px solid #0f3460;
                border-radius: 8px;
                color: #eee;
            }
            QTreeWidget::item {
                padding: 5px;
            }
            QTreeWidget::item:hover {
                background-color: #0f3460;
            }
            QTreeWidget::item:selected {
                background-color: #e94560;
            }
            QTableWidget {
                background-color: #16213e;
                border: 1px solid #0f3460;
                border-radius: 8px;
                color: #eee;
                gridline-color: #0f3460;
            }
            QTableWidget::item {
                padding: 8px;
            }
            QTableWidget::item:selected {
                background-color: #e94560;
            }
            QHeaderView::section {
                background-color: #0f3460;
                padding: 8px;
                border: none;
                font-weight: bold;
                color: #e94560;
            }
            QLabel {
                color: #eee;
            }
        """)
    
    def setup_ui(self):
        """Setup the main UI with tabs"""
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(10)
        main_layout.setContentsMargins(10, 10, 10, 10)
        
        # Header
        header = self.create_header()
        main_layout.addWidget(header)
        
        # Tab widget
        self.tab_widget = QTabWidget()
        
        # Add all documentation tabs
        self.tab_widget.addTab(self.create_overview_tab(), "📊 Overview")
        self.tab_widget.addTab(self.create_architecture_tab(), "🏗️ Architecture")
        self.tab_widget.addTab(self.create_features_tab(), "✨ Features")
        self.tab_widget.addTab(self.create_workflow_tab(), "🔄 Workflow")
        self.tab_widget.addTab(self.create_benefits_tab(), "💰 Benefits")
        self.tab_widget.addTab(self.create_guide_tab(), "📖 User Guide")
        self.tab_widget.addTab(self.create_shortcuts_tab(), "⌨️ Shortcuts")
        self.tab_widget.addTab(self.create_about_tab(), "👨‍💻 About")
        
        main_layout.addWidget(self.tab_widget)
        
        # Footer buttons
        footer = self.create_footer()
        main_layout.addWidget(footer)
    
    def create_header(self) -> QWidget:
        """Create header with title and close button"""
        header = QFrame()
        header.setFixedHeight(80)
        header.setStyleSheet("""
            QFrame {
                background-color: #16213e;
                border-radius: 12px;
                margin: 5px;
            }
        """)
        
        layout = QHBoxLayout(header)
        layout.setContentsMargins(20, 10, 20, 10)
        
        # Title section
        title_layout = QVBoxLayout()
        title = QLabel("🤖 AI QA Documentation Assistant")
        title.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))
        title.setStyleSheet("color: #e94560;")
        title_layout.addWidget(title)
        
        subtitle = QLabel("Complete Documentation & Technical Guide")
        subtitle.setFont(QFont("Segoe UI", 11))
        subtitle.setStyleSheet("color: #888;")
        title_layout.addWidget(subtitle)
        
        layout.addLayout(title_layout)
        layout.addStretch()
        
        # Close button
        close_btn = QPushButton("✕ Close")
        close_btn.setFixedSize(100, 35)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #e94560;
                border: none;
                border-radius: 8px;
                font-weight: bold;
                font-size: 13px;
                color: white;
            }
            QPushButton:hover {
                background-color: #c03550;
            }
        """)
        close_btn.clicked.connect(self.close)
        layout.addWidget(close_btn)
        
        return header
    
    def create_footer(self) -> QWidget:
        """Create footer with navigation buttons"""
        footer = QFrame()
        footer.setFixedHeight(60)
        footer.setStyleSheet("""
            QFrame {
                background-color: #16213e;
                border-radius: 12px;
                margin: 5px;
            }
        """)
        
        layout = QHBoxLayout(footer)
        layout.setContentsMargins(20, 10, 20, 10)
        
        # Version info
        version = QLabel("Version 2.0.0 | © 2024 Prolifics Corp Ltd")
        version.setStyleSheet("color: #888;")
        layout.addWidget(version)
        
        layout.addStretch()
        
        # Navigation buttons
        prev_btn = ModernButton("◀ Previous", "#0984e3")
        prev_btn.clicked.connect(self.previous_tab)
        layout.addWidget(prev_btn)
        
        next_btn = ModernButton("Next ▶", "#0984e3")
        next_btn.clicked.connect(self.next_tab)
        layout.addWidget(next_btn)
        
        return footer
    
    def previous_tab(self):
        """Go to previous tab"""
        current = self.tab_widget.currentIndex()
        if current > 0:
            self.tab_widget.setCurrentIndex(current - 1)
    
    def next_tab(self):
        """Go to next tab"""
        current = self.tab_widget.currentIndex()
        if current < self.tab_widget.count() - 1:
            self.tab_widget.setCurrentIndex(current + 1)
    
    def create_overview_tab(self) -> QWidget:
        """Create overview tab with executive summary"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Scroll area for content
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        
        # Executive Summary
        exec_summary = QGroupBox("📊 Executive Summary")
        exec_layout = QVBoxLayout(exec_summary)
        
        summary_text = QTextEdit()
        summary_text.setHtml("""
        <h2 style="color:#e94560;">🤖 AI QA Documentation Assistant</h2>
        
        <p style="font-size:14px; line-height:1.6;">
        A revolutionary desktop application that leverages artificial intelligence to automate 
        the entire Quality Assurance documentation process. Built with Python and PyQt6, it 
        transforms manual test documentation into an intelligent, automated workflow.
        </p>
        
        <h3 style="color:#667eea; margin-top:20px;">Key Metrics:</h3>
        <table style="width:100%; border-collapse:collapse;">
            <tr style="background-color:#0f3460;">
                <th style="padding:10px; text-align:left;">Metric</th>
                <th style="padding:10px; text-align:left;">Value</th>
            </tr>
            <tr>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">📉 Documentation Time Reduction</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;"><b>80%</b></td>
            </tr>
            <tr>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">🎯 AI Accuracy Rate</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;"><b>95%</b></td>
            </tr>
            <tr>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">📊 Report Generation Speed</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;"><b>10x faster</b></td>
            </tr>
            <tr>
                <td style="padding:8px;">💰 Annual Savings per Team</td>
                <td style="padding:8px;"><b>$50,000+</b></td>
            </tr>
        </table>
        """)
        summary_text.setReadOnly(True)
        exec_layout.addWidget(summary_text)
        content_layout.addWidget(exec_summary)
        
        # Problem & Solution
        problem_solution = QGroupBox("🎯 Problem & Solution")
        ps_layout = QGridLayout(problem_solution)
        
        problem_text = QTextEdit()
        problem_text.setHtml("""
        <h3 style="color:#e94560;">❌ The Problem</h3>
        <ul>
            <li><b>Time Drain:</b> QA teams spend 40-50% of testing time on documentation</li>
            <li><b>Inconsistency:</b> Different testers document differently</li>
            <li><b>Manual Errors:</b> Screenshot mismanagement, missing steps</li>
            <li><b>Slow Reporting:</b> Hours spent formatting reports</li>
            <li><b>Knowledge Loss:</b> Critical context lost in basic screenshots</li>
        </ul>
        """)
        problem_text.setReadOnly(True)
        ps_layout.addWidget(problem_text, 0, 0)
        
        solution_text = QTextEdit()
        solution_text.setHtml("""
        <h3 style="color:#00b894;">✅ The Solution</h3>
        <ul>
            <li><b>Automation:</b> Eliminates manual documentation work</li>
            <li><b>Standardization:</b> Consistent quality across all test cases</li>
            <li><b>AI Enhancement:</b> Screenshots enriched with intelligence</li>
            <li><b>Speed:</b> Reports generated in minutes, not hours</li>
            <li><b>Context Preservation:</b> Complete test evidence with analysis</li>
        </ul>
        """)
        solution_text.setReadOnly(True)
        ps_layout.addWidget(solution_text, 0, 1)
        
        content_layout.addWidget(problem_solution)
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        return widget
    
    def create_architecture_tab(self) -> QWidget:
        """Create architecture tab with diagrams"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        
        # Architecture Diagram (Text-based)
        arch_group = QGroupBox("🏗️ System Architecture")
        arch_layout = QVBoxLayout(arch_group)
        
        arch_diagram = QTextEdit()
        arch_diagram.setFont(QFont("Courier New", 10))
        arch_diagram.setHtml("""
        <pre style="color:#00b894; font-family: monospace; line-height: 1.8;">
┌─────────────────────────────────────────────────────────────────────────────┐
│                    AI QA Documentation Assistant                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                  │
│  │   PyQt6 UI    │    │  Screenshot  │    │   Session    │                  │
│  │    Layer      │◄───┤   Engine     │───►│   Manager    │                  │
│  └──────────────┘    └──────────────┘    └──────────────┘                  │
│         │                   │                   │                           │
│         ▼                   ▼                   ▼                           │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                  │
│  │     AI       │    │   Export     │    │   Storage    │                  │
│  │  Processor   │    │   Engine     │    │  (SQLite)    │                  │
│  └──────────────┘    └──────────────┘    └──────────────┘                  │
│         │                   │                                                │
│         ▼                   ▼                                                │
│  ┌──────────────┐    ┌──────────────┐                                      │
│  │   Groq API   │    │  HTML/PDF    │                                      │
│  │  (Vision)    │    │ Excel/Word   │                                      │
│  └──────────────┘    └──────────────┘                                      │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
        </pre>
        """)
        arch_diagram.setReadOnly(True)
        arch_layout.addWidget(arch_diagram)
        content_layout.addWidget(arch_group)
        
        # Technology Stack Table
        tech_group = QGroupBox("📊 Technology Stack")
        tech_layout = QVBoxLayout(tech_group)
        
        tech_table = QTableWidget()
        tech_table.setRowCount(6)
        tech_table.setColumnCount(3)
        tech_table.setHorizontalHeaderLabels(["Layer", "Technology", "Purpose"])
        
        technologies = [
            ["Frontend", "PyQt6", "Desktop GUI framework"],
            ["Backend", "Python 3.11+", "Core application logic"],
            ["AI/ML", "Groq API", "Vision model for analysis"],
            ["Storage", "SQLite / JSON", "Session persistence"],
            ["Export", "ReportLab, python-docx, openpyxl", "Multi-format reports"],
            ["Images", "Pillow, OpenCV", "Image processing"]
        ]
        
        for row, tech in enumerate(technologies):
            for col, value in enumerate(tech):
                item = QTableWidgetItem(value)
                item.setForeground(QColor(238, 238, 238))
                tech_table.setItem(row, col, item)
        
        tech_table.resizeColumnsToContents()
        tech_table.horizontalHeader().setStretchLastSection(True)
        tech_layout.addWidget(tech_table)
        content_layout.addWidget(tech_group)
        
        # Data Flow Diagram
        flow_group = QGroupBox("🔄 Data Flow Diagram")
        flow_layout = QVBoxLayout(flow_group)
        
        flow_diagram = QTextEdit()
        flow_diagram.setFont(QFont("Courier New", 10))
        flow_diagram.setHtml("""
        <pre style="color:#667eea; font-family: monospace; line-height: 2.0;">
    User Action          System Process           AI Processing           Output
    ───────────         ──────────────          ─────────────           ──────
        │                      │                       │                     │
        ▼                      ▼                       │                     │
    Click Capture    ──►  Screenshot Engine           │                     │
                              │                        │                     │
                              ▼                        │                     │
                          Save Image                   │                     │
                              │                        │                     │
                              ▼                        ▼                     │
                          AI Processor        ──►  Groq Vision API          │
                              │                        │                     │
                              │                        ▼                     │
                              │                  Generate Analysis          │
                              │                        │                     │
                              ▼                        ▼                     │
                          Update Session      ◄──  Parse JSON Response      │
                              │                        │                     │
                              ▼                        │                     │
                          Refresh Display              │                     │
                              │                        │                     │
                              ▼                        ▼                     ▼
                          Export Report        ──►  Professional      ──►  Deliver
                                                    Document              to User
        </pre>
        """)
        flow_diagram.setReadOnly(True)
        flow_layout.addWidget(flow_diagram)
        content_layout.addWidget(flow_group)
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        return widget
    
    def create_features_tab(self) -> QWidget:
        """Create features tab with all features"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        
        # Core Features Grid
        core_group = QGroupBox("✨ Core Features")
        core_layout = QGridLayout(core_group)
        
        features = [
            ("📸 Smart Capture", "Full screen or selective area with multi-monitor support"),
            ("🧠 AI Analysis", "Automatic description, expected behavior, and bug detection"),
            ("📊 Session Management", "Complete test session tracking with timeline view"),
            ("📤 Multi-Format Export", "HTML, PDF, Excel, Word, Markdown reports"),
            ("🎨 Modern UI", "Dark theme, responsive layout, professional design"),
            ("⌨️ Shortcuts", "Keyboard shortcuts for power users"),
            ("💾 Auto-Save", "Never lose your work with automatic session saving"),
            ("🔍 Preview", "Real-time screenshot preview with zoom capabilities"),
            ("📋 Clipboard", "Copy analysis anywhere with one click"),
            ("🔐 API Integration", "Secure Groq API key management"),
        ]
        
        for i, (title, desc) in enumerate(features):
            row = i // 2
            col = i % 2
            
            feature_widget = QFrame()
            feature_widget.setStyleSheet("""
                QFrame {
                    background-color: #16213e;
                    border-radius: 10px;
                    padding: 10px;
                    margin: 5px;
                }
            """)
            feature_layout = QVBoxLayout(feature_widget)
            
            title_label = QLabel(title)
            title_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
            title_label.setStyleSheet("color: #e94560;")
            feature_layout.addWidget(title_label)
            
            desc_label = QLabel(desc)
            desc_label.setWordWrap(True)
            desc_label.setStyleSheet("color: #aaa;")
            feature_layout.addWidget(desc_label)
            
            core_layout.addWidget(feature_widget, row, col)
        
        content_layout.addWidget(core_group)
        
        # Advanced Features Table
        advanced_group = QGroupBox("🚀 Advanced Capabilities")
        advanced_layout = QVBoxLayout(advanced_group)
        
        advanced_table = QTableWidget()
        advanced_table.setRowCount(8)
        advanced_table.setColumnCount(2)
        advanced_table.setHorizontalHeaderLabels(["Feature", "Description"])
        
        advanced_features = [
            ["Auto-describe Mode", "Instant AI analysis after every capture"],
            ["Session Persistence", "Load and review any past session"],
            ["Step Tagging", "Categorize and organize test steps"],
            ["Bug Detection", "AI identifies potential issues automatically"],
            ["Test Case Generation", "Create formal test cases from sessions"],
            ["Executive Summary", "AI-generated summary with recommendations"],
            ["Offline Fallback", "Works without internet connection"],
            ["Multi-Monitor", "Capture from any connected display"]
        ]
        
        for row, (feature, desc) in enumerate(advanced_features):
            feature_item = QTableWidgetItem(feature)
            feature_item.setForeground(QColor(233, 69, 96))
            advanced_table.setItem(row, 0, feature_item)
            
            desc_item = QTableWidgetItem(desc)
            desc_item.setForeground(QColor(238, 238, 238))
            advanced_table.setItem(row, 1, desc_item)
        
        advanced_table.resizeColumnsToContents()
        advanced_table.horizontalHeader().setStretchLastSection(True)
        advanced_layout.addWidget(advanced_table)
        content_layout.addWidget(advanced_group)
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        return widget
    
    def create_workflow_tab(self) -> QWidget:
        """Create workflow tab with step-by-step process"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        
        # Workflow Steps
        workflow_group = QGroupBox("🔄 Complete Workflow")
        workflow_layout = QVBoxLayout(workflow_group)
        
        steps = [
            ("1", "Start Session", "Click 'Start New Session' to begin documentation"),
            ("2", "Capture Screenshots", "Use Full Screen or Snip Area tools"),
            ("3", "AI Analysis", "AI automatically analyzes and describes each step"),
            ("4", "Add Notes", "Add manual observations or context"),
            ("5", "Review Steps", "Review timeline and edit descriptions if needed"),
            ("6", "End Session", "Session automatically saved"),
            ("7", "Export Report", "Generate professional report in any format")
        ]
        
        for i, (num, title, desc) in enumerate(steps):
            step_widget = QFrame()
            step_widget.setStyleSheet("""
                QFrame {
                    background-color: #16213e;
                    border-radius: 10px;
                    margin: 5px;
                }
            """)
            step_layout = QHBoxLayout(step_widget)
            
            # Step number
            num_label = QLabel(num)
            num_label.setFixedSize(40, 40)
            num_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            num_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
            num_label.setStyleSheet(f"""
                background-color: #e94560;
                border-radius: 20px;
                color: white;
            """)
            step_layout.addWidget(num_label)
            
            # Step content
            step_content = QVBoxLayout()
            title_label = QLabel(title)
            title_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
            title_label.setStyleSheet("color: #667eea;")
            step_content.addWidget(title_label)
            
            desc_label = QLabel(desc)
            desc_label.setWordWrap(True)
            desc_label.setStyleSheet("color: #aaa;")
            step_content.addWidget(desc_label)
            
            step_layout.addLayout(step_content)
            step_layout.addStretch()
            
            workflow_layout.addWidget(step_widget)
            
            # Add arrow between steps (except last)
            if i < len(steps) - 1:
                arrow = QLabel("▼")
                arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
                arrow.setStyleSheet("color: #e94560; font-size: 20px; padding: 5px;")
                workflow_layout.addWidget(arrow)
        
        content_layout.addWidget(workflow_group)
        
        # User Journey Map
        journey_group = QGroupBox("🗺️ User Journey Map")
        journey_layout = QVBoxLayout(journey_group)
        
        journey_text = QTextEdit()
        journey_text.setHtml("""
        <table style="width:100%; border-collapse:collapse;">
            <tr style="background-color:#0f3460;">
                <th style="padding:10px;">Phase</th>
                <th style="padding:10px;">User Action</th>
                <th style="padding:10px;">System Response</th>
                <th style="padding:10px;">Time Saved</th>
            </tr>
            <tr>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">Setup</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">Configure API</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">Validates key</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">5 min</td>
            </tr>
            <tr>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">Testing</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">Capture screenshots</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">AI analyzes instantly</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">30 min</td>
            </tr>
            <tr>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">Documentation</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">Review descriptions</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">Auto-generated text</td>
                <td style="padding:8px; border-bottom:1px solid #0f3460;">45 min</td>
            </tr>
            <tr>
                <td style="padding:8px;">Reporting</td>
                <td style="padding:8px;">Export report</td>
                <td style="padding:8px;">Professional document</td>
                <td style="padding:8px;">2 hours</td>
            </tr>
        </table>
        """)
        journey_text.setReadOnly(True)
        journey_layout.addWidget(journey_text)
        content_layout.addWidget(journey_group)
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        return widget
    
    def create_benefits_tab(self) -> QWidget:
        """Create benefits tab with ROI calculations"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        
        # Quantitative Benefits
        quant_group = QGroupBox("📊 Quantitative Benefits")
        quant_layout = QVBoxLayout(quant_group)
        
        quant_table = QTableWidget()
        quant_table.setRowCount(4)
        quant_table.setColumnCount(3)
        quant_table.setHorizontalHeaderLabels(["Metric", "Before", "After"])
        
        benefits = [
            ["Documentation Time", "4 hours/day", "45 minutes/day (81% reduction)"],
            ["Report Generation", "2 hours", "5 minutes (96% reduction)"],
            ["Error Rate", "15%", "2% (87% reduction)"],
            ["Team Productivity", "60%", "95% (58% increase)"]
        ]
        
        for row, (metric, before, after) in enumerate(benefits):
            metric_item = QTableWidgetItem(metric)
            metric_item.setForeground(QColor(233, 69, 96))
            quant_table.setItem(row, 0, metric_item)
            
            before_item = QTableWidgetItem(before)
            before_item.setForeground(QColor(238, 238, 238))
            quant_table.setItem(row, 1, before_item)
            
            after_item = QTableWidgetItem(after)
            after_item.setForeground(QColor(0, 184, 148))
            quant_table.setItem(row, 2, after_item)
        
        quant_table.resizeColumnsToContents()
        quant_layout.addWidget(quant_table)
        content_layout.addWidget(quant_group)
        
        # ROI Calculation
        roi_group = QGroupBox("💰 ROI Calculation")
        roi_layout = QVBoxLayout(roi_group)
        
        roi_text = QTextEdit()
        roi_text.setHtml("""
        <h3 style="color:#e94560;">Annual Investment</h3>
        <ul>
            <li><b>Development Cost:</b> $0 (Internal tool)</li>
            <li><b>API Costs:</b> ~$50/month (Groq API)</li>
            <li><b>Maintenance:</b> 4 hours/month</li>
        </ul>
        
        <h3 style="color:#00b894; margin-top:20px;">Annual Savings</h3>
        <ul>
            <li><b>QA Hours Saved:</b> 800 hours/year</li>
            <li><b>Cost per Hour:</b> $50</li>
            <li><b>Direct Savings:</b> $40,000/year</li>
            <li><b>Productivity Value:</b> $20,000/year</li>
        </ul>
        
        <h3 style="color:#667eea; margin-top:20px;">Total ROI: 1200% in first year</h3>
        """)
        roi_text.setReadOnly(True)
        roi_layout.addWidget(roi_text)
        content_layout.addWidget(roi_group)
        
        # Qualitative Benefits
        qual_group = QGroupBox("✨ Qualitative Benefits")
        qual_layout = QGridLayout(qual_group)
        
        qual_benefits = [
            ("✅ Consistent Quality", "Standardized documentation across all testers"),
            ("✅ Faster Time-to-Market", "Reduced documentation delays"),
            ("✅ Better Communication", "Clear, AI-enhanced descriptions"),
            ("✅ Audit Readiness", "Complete, timestamped evidence"),
            ("✅ Knowledge Retention", "Detailed context preserved"),
            ("✅ Team Scalability", "Onboard new testers faster")
        ]
        
        for i, (title, desc) in enumerate(qual_benefits):
            row = i // 2
            col = i % 2
            
            benefit_widget = QFrame()
            benefit_widget.setStyleSheet("""
                QFrame {
                    background-color: #16213e;
                    border-radius: 10px;
                    padding: 10px;
                    margin: 5px;
                }
            """)
            benefit_layout = QVBoxLayout(benefit_widget)
            
            title_label = QLabel(title)
            title_label.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
            title_label.setStyleSheet("color: #00b894;")
            benefit_layout.addWidget(title_label)
            
            desc_label = QLabel(desc)
            desc_label.setWordWrap(True)
            desc_label.setStyleSheet("color: #aaa;")
            benefit_layout.addWidget(desc_label)
            
            qual_layout.addWidget(benefit_widget, row, col)
        
        content_layout.addWidget(qual_group)
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        return widget
    
    def create_guide_tab(self) -> QWidget:
        """Create user guide tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        
        # Quick Start Guide
        quick_group = QGroupBox("🚀 Quick Start Guide (60 Seconds)")
        quick_layout = QVBoxLayout(quick_group)
        
        quick_table = QTableWidget()
        quick_table.setRowCount(5)
        quick_table.setColumnCount(3)
        quick_table.setHorizontalHeaderLabels(["Step", "Action", "Result"])
        
        quick_steps = [
            ["1", "Click 'Start Session'", "Floating toolbar appears"],
            ["2", "Click '📸 Full Screen'", "Screenshot captured and analyzed"],
            ["3", "Repeat for all test steps", "Complete timeline created"],
            ["4", "Click 'End Session'", "Session saved"],
            ["5", "Click 'Export Session'", "Professional report generated"]
        ]
        
        for row, (step, action, result) in enumerate(quick_steps):
            step_item = QTableWidgetItem(step)
            step_item.setForeground(QColor(233, 69, 96))
            quick_table.setItem(row, 0, step_item)
            
            action_item = QTableWidgetItem(action)
            action_item.setForeground(QColor(238, 238, 238))
            quick_table.setItem(row, 1, action_item)
            
            result_item = QTableWidgetItem(result)
            result_item.setForeground(QColor(0, 184, 148))
            quick_table.setItem(row, 2, result_item)
        
        quick_table.resizeColumnsToContents()
        quick_layout.addWidget(quick_table)
        content_layout.addWidget(quick_group)
        
        # Best Practices
        practices_group = QGroupBox("💡 Best Practices")
        practices_layout = QVBoxLayout(practices_group)
        
        practices_text = QTextEdit()
        practices_text.setHtml("""
        <ol style="line-height: 1.8;">
            <li><b>Use Descriptive Session Names:</b> Include project, feature, date</li>
            <li><b>Capture Before & After:</b> Show state changes clearly</li>
            <li><b>Add Manual Notes:</b> Include context AI might miss</li>
            <li><b>Review AI Descriptions:</b> Correct any misinterpretations</li>
            <li><b>Export Regularly:</b> Don't lose your work</li>
            <li><b>Organize Screenshots:</b> Use folders for different features</li>
            <li><b>Use Keyboard Shortcuts:</b> Speed up your workflow</li>
            <li><b>Tag Your Steps:</b> Categorize for better organization</li>
        </ol>
        """)
        practices_text.setReadOnly(True)
        practices_layout.addWidget(practices_text)
        content_layout.addWidget(practices_group)
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        return widget
    
    def create_shortcuts_tab(self) -> QWidget:
        """Create keyboard shortcuts tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        
        shortcuts_group = QGroupBox("⌨️ Keyboard Shortcuts")
        shortcuts_layout = QVBoxLayout(shortcuts_group)
        
        shortcuts_table = QTableWidget()
        shortcuts_table.setRowCount(9)
        shortcuts_table.setColumnCount(2)
        shortcuts_table.setHorizontalHeaderLabels(["Shortcut", "Action"])
        
        shortcuts = [
            ["Ctrl+Shift+S", "Start Session"],
            ["Ctrl+Shift+E", "End Session"],
            ["Ctrl+Shift+F", "Full Screenshot"],
            ["Ctrl+Shift+X", "Snip Area"],
            ["Ctrl+Shift+N", "Add Manual Note"],
            ["Ctrl+E", "Export Session"],
            ["Ctrl+Q", "Quit Application"],
            ["F1", "Open Help"],
            ["Ctrl+Shift+A", "About"]
        ]
        
        for row, (shortcut, action) in enumerate(shortcuts):
            shortcut_item = QTableWidgetItem(shortcut)
            shortcut_item.setForeground(QColor(233, 69, 96))
            shortcut_item.setFont(QFont("Courier New", 11, QFont.Weight.Bold))
            shortcuts_table.setItem(row, 0, shortcut_item)
            
            action_item = QTableWidgetItem(action)
            action_item.setForeground(QColor(238, 238, 238))
            shortcuts_table.setItem(row, 1, action_item)
        
        shortcuts_table.resizeColumnsToContents()
        shortcuts_table.horizontalHeader().setStretchLastSection(True)
        shortcuts_layout.addWidget(shortcuts_table)
        content_layout.addWidget(shortcuts_group)
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        return widget
    
    def create_about_tab(self) -> QWidget:
        """Create about tab with developer info"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Developer Card
        dev_card = QFrame()
        dev_card.setStyleSheet("""
            QFrame {
                background-color: #16213e;
                border-radius: 20px;
                padding: 30px;
                margin: 20px;
            }
        """)
        dev_layout = QVBoxLayout(dev_card)
        dev_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Avatar/Icon
        avatar = QLabel("👨‍💻")
        avatar.setFont(QFont("Segoe UI", 72))
        avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dev_layout.addWidget(avatar)
        
        # Name
        name = QLabel("Sachin Sharma")
        name.setFont(QFont("Segoe UI", 24, QFont.Weight.Bold))
        name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        name.setStyleSheet("color: #e94560; margin-top: 10px;")
        dev_layout.addWidget(name)
        
        # Role
        role = QLabel("Software Engineer")
        role.setFont(QFont("Segoe UI", 14))
        role.setAlignment(Qt.AlignmentFlag.AlignCenter)
        role.setStyleSheet("color: #667eea;")
        dev_layout.addWidget(role)
        
        # Company
        company = QLabel("Prolifics Corp Ltd")
        company.setFont(QFont("Segoe UI", 12))
        company.setAlignment(Qt.AlignmentFlag.AlignCenter)
        company.setStyleSheet("color: #888;")
        dev_layout.addWidget(company)
        
        content_layout.addWidget(dev_card)
        
        # App Info
        info_card = QFrame()
        info_card.setStyleSheet("""
            QFrame {
                background-color: #16213e;
                border-radius: 20px;
                padding: 20px;
                margin: 20px;
            }
        """)
        info_layout = QVBoxLayout(info_card)
        
        app_info = QTextEdit()
        app_info.setHtml("""
        <h3 style="color:#e94560; text-align:center;">🤖 AI QA Documentation Assistant</h3>
        <p style="text-align:center;"><b>Version 2.0.0</b></p>
        <br>
        <p style="line-height:1.6;">
        An AI-powered test documentation tool that automatically captures screenshots, 
        generates descriptions, and creates comprehensive QA reports with minimal manual effort.
        </p>
        <br>
        <h4 style="color:#667eea;">🎯 Mission</h4>
        <p>To revolutionize Quality Assurance processes through intelligent automation, 
        reducing documentation time while improving accuracy and consistency.</p>
        <br>
        <h4 style="color:#667eea;">🏆 Achievements</h4>
        <ul>
            <li>80% reduction in documentation time</li>
            <li>95% AI accuracy rate</li>
            <li>10x faster report generation</li>
            <li>1200% ROI in first year</li>
        </ul>
        <br>
        <p style="text-align:center; color:#888;">
        © 2024 Prolifics Corp Ltd. All rights reserved.
        </p>
        """)
        app_info.setReadOnly(True)
        info_layout.addWidget(app_info)
        
        content_layout.addWidget(info_card)
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        return widget