# #!/usr/bin/env python3
# """
# Test your Groq API key with the correct models
# """

# import sys
# from ai_processor import AIProcessor

# def test():
#     print("\n" + "="*50)
#     print("🔑 Testing Groq API Integration")
#     print("="*50 + "\n")
    
#     print("Initializing AI Processor...")
#     ai = AIProcessor()
    
#     print("\n" + "-"*50)
#     print("API Key Status:")
#     print("-"*50)
    
#     if not ai.fallback_mode:
#         print("✅ API key loaded successfully!")
#         print(f"   Key preview: {ai.api_key[:8]}...{ai.api_key[-4:]}")
#         print(f"   Vision Model: {ai.VISION_MODEL}")
#         print(f"   Text Model: {ai.TEXT_MODEL}")
        
#         print("\n" + "-"*50)
#         print("Testing API Connection:")
#         print("-"*50)
        
#         if ai.test_api_connection():
#             print("\n" + "="*50)
#             print("🎉 SUCCESS! Your AI integration is ready to use!")
#             print("="*50)
#             print("\nYou can now:")
#             print("  • Capture screenshots with AI analysis")
#             print("  • Generate automatic QA documentation")
#             print("  • Export reports with AI-generated descriptions")
#         else:
#             print("\n" + "="*50)
#             print("❌ API Connection Failed")
#             print("="*50)
#             print("\nTroubleshooting steps:")
#             print("1. Verify your API key is correct at https://console.groq.com")
#             print("2. Check if you have API credits available")
#             print("3. Ensure your internet connection is working")
#             print("4. Try again in a few minutes if rate limited")
#     else:
#         print("❌ No valid API key found in ai_processor.py")
#         print("\nTo fix this:")
#         print("1. Open ai_processor.py")
#         print("2. Find the line: GROQ_API_KEY = 'gsk_Er1rMejW'")
#         print("3. Replace with your actual Groq API key")
#         print("4. Save the file and run this test again")
#         print("\nGet your API key from: https://console.groq.com")

# if __name__ == "__main__":
#     test()
#     input("\nPress Enter to exit...")

"""
Application entry point.

    python -m app.main
    # or
    python app/main.py
"""
from __future__ import annotations

import signal
import sys
from pathlib import Path

# Make `app.*` imports work when run as a script
_THIS = Path(__file__).resolve()
if str(_THIS.parent.parent) not in sys.path:
    sys.path.insert(0, str(_THIS.parent.parent))

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import QApplication

from app.ui.main_window import MainWindow
from app.ui.theme import DARK_QSS
from app.utils.config import get_config
from app.utils.logger import get_logger, setup_logging


def main() -> int:
    setup_logging()
    logger = get_logger(__name__)
    cfg = get_config()

    # Respect hi-DPI on Windows/macOS/Linux consistently
    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("JIRA Intelligence")
    app.setOrganizationName("JIRA Intelligence")
    app.setStyleSheet(DARK_QSS)

    # Allow Ctrl+C to kill the app cleanly during dev
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    logger.info(
        "Starting %s · provider=%s · model=%s",
        cfg.app_title,
        cfg.ai_provider,
        cfg.anthropic_model,
    )

    window = MainWindow()
    window.show()

    return app.exec()


if __name__ == "__main__":
    sys.exit(main())