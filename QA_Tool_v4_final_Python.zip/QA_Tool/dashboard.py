"""
Session Dashboard - v4.0

Aggregates metrics across all sessions for a professional overview:
sessions created, screenshots captured, defects identified, AI analyses,
reports generated, plus a daily activity trend.

The aggregation layer (`DashboardStats`) is Qt-free and unit-testable.
A `DashboardWidget` (PyQt6) is provided behind a guarded import so the data
layer can be used/tested without a display.

Public API
----------
    stats = DashboardStats(storage_path="sessions", reports_path="exports")
    data = stats.compute()             # -> dict of metrics + trend
"""

from __future__ import annotations

import json
import os
from collections import Counter
from datetime import datetime
from typing import Dict


class DashboardStats:
    def __init__(self, storage_path: str = "sessions", reports_path: str = "exports"):
        self.storage_path = storage_path
        self.reports_path = reports_path

    def compute(self) -> Dict:
        sessions = 0
        screenshots = 0
        defects = 0
        ai_analyses = 0
        steps_total = 0
        per_day = Counter()
        recent = []

        if os.path.isdir(self.storage_path):
            for fn in os.listdir(self.storage_path):
                if not fn.endswith(".json"):
                    continue
                try:
                    with open(os.path.join(self.storage_path, fn), "r", encoding="utf-8") as f:
                        data = json.load(f)
                except Exception:
                    continue
                sessions += 1
                steps = data.get("steps", [])
                steps_total += len(steps)
                day = (data.get("start_time", "") or "")[:10]
                if day:
                    per_day[day] += 1
                for s in steps:
                    if s.get("image_path"):
                        screenshots += 1
                    hint = (s.get("bug_hint") or "").lower()
                    if hint and "no obvious" not in hint and "no issue" not in hint:
                        defects += 1
                    if s.get("ai_summary") or s.get("description"):
                        ai_analyses += 1
                recent.append({
                    "session_id": data.get("session_id", ""),
                    "name": data.get("session_name", ""),
                    "steps": len(steps),
                    "start_time": data.get("start_time", ""),
                })

        reports = 0
        if os.path.isdir(self.reports_path):
            for root, _, files in os.walk(self.reports_path):
                reports += sum(
                    1 for f in files
                    if f.lower().endswith((".docx", ".pdf", ".xlsx", ".html", ".md"))
                )

        recent.sort(key=lambda r: r["start_time"], reverse=True)
        trend = [{"date": d, "count": per_day[d]} for d in sorted(per_day)][-14:]

        return {
            "sessions_created": sessions,
            "screenshots_captured": screenshots,
            "defects_identified": defects,
            "ai_analyses_performed": ai_analyses,
            "reports_generated": reports,
            "steps_total": steps_total,
            "avg_steps_per_session": round(steps_total / sessions, 1) if sessions else 0,
            "trend": trend,
            "recent_sessions": recent[:8],
            "generated_at": datetime.now().isoformat(timespec="seconds"),
        }


# --------------------------------------------------------------------------
# Optional Qt widget (only imported/created when PyQt6 is available)
# --------------------------------------------------------------------------
def build_widget(stats_data: Dict):
    """Return a QWidget dashboard, or None if PyQt6 is unavailable."""
    try:
        from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                     QFrame, QGridLayout)
        from PyQt6.QtCore import Qt
    except Exception:
        return None

    def card(value, label, color):
        f = QFrame()
        f.setStyleSheet(
            f"QFrame{{background:#ffffff;border:1px solid #e6e8ec;"
            f"border-radius:14px;}}")
        lay = QVBoxLayout(f)
        lay.setContentsMargins(18, 16, 18, 16)
        v = QLabel(str(value)); v.setStyleSheet(f"font-size:30px;font-weight:700;color:{color};")
        l = QLabel(label); l.setStyleSheet("font-size:12px;color:#6b7280;")
        lay.addWidget(v); lay.addWidget(l)
        return f

    w = QWidget()
    root = QVBoxLayout(w)
    title = QLabel("Dashboard")
    title.setStyleSheet("font-size:20px;font-weight:700;color:#111827;")
    root.addWidget(title)

    grid = QGridLayout()
    cards = [
        (stats_data["sessions_created"], "Sessions Created", "#2563eb"),
        (stats_data["screenshots_captured"], "Screenshots Captured", "#0891b2"),
        (stats_data["defects_identified"], "Defects Identified", "#dc2626"),
        (stats_data["ai_analyses_performed"], "AI Analyses", "#7c3aed"),
        (stats_data["reports_generated"], "Reports Generated", "#059669"),
        (stats_data["avg_steps_per_session"], "Avg Steps / Session", "#d97706"),
    ]
    for i, (val, lbl, col) in enumerate(cards):
        grid.addWidget(card(val, lbl, col), i // 3, i % 3)
    root.addLayout(grid)
    root.addStretch(1)
    return w


if __name__ == "__main__":
    stats = DashboardStats("/tmp/sess", "/tmp/noexports")
    import pprint
    pprint.pprint(stats.compute())
