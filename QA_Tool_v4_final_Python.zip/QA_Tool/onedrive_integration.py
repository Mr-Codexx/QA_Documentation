"""
OneDrive Integration (Safe Mode) - v4.0

Detects OneDrive Personal / OneDrive for Business / synced SharePoint folders
WITHOUT Microsoft Graph, Azure app registration, OAuth, or admin permissions.

It relies purely on the locally-installed OneDrive Sync Client: we detect the
synced folders on disk and save exports straight into them. The sync client
handles uploading to the cloud.

Public API
----------
    sm = StorageManager()                 # loads/saves settings.json
    sm.detect_all()                       # -> list[StorageLocation]
    sm.set_destination("onedrive", path)  # choose where exports go
    sm.resolve_export_dir()               # -> absolute path to write into

This module has NO Qt dependency and is safe to import anywhere.
"""

from __future__ import annotations

import json
import os
import platform
from dataclasses import dataclass, asdict
from typing import List, Optional


@dataclass
class StorageLocation:
    kind: str          # "local" | "onedrive" | "onedrive_business" | "sharepoint" | "custom"
    label: str         # human friendly name
    path: str          # absolute path on disk
    available: bool     # path currently exists

    def to_dict(self):
        return asdict(self)


def _exists(p: Optional[str]) -> bool:
    return bool(p) and os.path.isdir(p)


class OneDriveDetector:
    """Locates OneDrive + SharePoint synced folders from the local filesystem."""

    def detect(self) -> List[StorageLocation]:
        system = platform.system()
        if system == "Windows":
            return self._detect_windows()
        if system == "Darwin":
            return self._detect_mac()
        return self._detect_linux()

    # ---- Windows -------------------------------------------------------
    def _detect_windows(self) -> List[StorageLocation]:
        found: List[StorageLocation] = []

        # 1) Environment variables set by the OneDrive client
        env_map = {
            "OneDrive": ("onedrive", "OneDrive"),
            "OneDriveConsumer": ("onedrive", "OneDrive (Personal)"),
            "OneDriveCommercial": ("onedrive_business", "OneDrive for Business"),
        }
        seen = set()
        for env_key, (kind, label) in env_map.items():
            p = os.environ.get(env_key)
            if p and p not in seen and _exists(p):
                found.append(StorageLocation(kind, label, p, True))
                seen.add(p)

        # 2) Registry (authoritative for business/SharePoint mounts)
        found.extend(self._detect_windows_registry(seen))

        # 3) Heuristic scan of the user profile for "OneDrive*" dirs
        userprofile = os.environ.get("USERPROFILE", os.path.expanduser("~"))
        try:
            for name in os.listdir(userprofile):
                if name.lower().startswith("onedrive"):
                    p = os.path.join(userprofile, name)
                    if _exists(p) and p not in seen:
                        label = "OneDrive for Business" if "-" in name else "OneDrive"
                        kind = "onedrive_business" if "-" in name else "onedrive"
                        found.append(StorageLocation(kind, label, p, True))
                        seen.add(p)
        except OSError:
            pass

        return found

    def _detect_windows_registry(self, seen: set) -> List[StorageLocation]:
        out: List[StorageLocation] = []
        try:
            import winreg  # type: ignore
        except Exception:
            return out

        # Personal/Business mount points
        for sub in (r"Software\Microsoft\OneDrive\Accounts\Personal",
                    r"Software\Microsoft\OneDrive\Accounts\Business1"):
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, sub) as k:
                    folder, _ = winreg.QueryValueEx(k, "UserFolder")
                    if _exists(folder) and folder not in seen:
                        biz = "Business" in sub
                        out.append(StorageLocation(
                            "onedrive_business" if biz else "onedrive",
                            "OneDrive for Business" if biz else "OneDrive (Personal)",
                            folder, True))
                        seen.add(folder)
            except OSError:
                continue

        # SharePoint libraries synced via "Mounted" key under Business accounts
        try:
            base = r"Software\Microsoft\OneDrive\Accounts"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, base) as accounts:
                i = 0
                while True:
                    try:
                        acct = winreg.EnumKey(accounts, i)
                        i += 1
                    except OSError:
                        break
                    try:
                        with winreg.OpenKey(accounts, acct + r"\Tenants") as tenants:
                            j = 0
                            while True:
                                try:
                                    tname = winreg.EnumKey(tenants, j)
                                    j += 1
                                except OSError:
                                    break
                                with winreg.OpenKey(tenants, tname) as t:
                                    v = 0
                                    while True:
                                        try:
                                            name, val, _ = winreg.EnumValue(t, v)
                                            v += 1
                                        except OSError:
                                            break
                                        if _exists(val) and val not in seen:
                                            out.append(StorageLocation(
                                                "sharepoint", f"SharePoint: {name}", val, True))
                                            seen.add(val)
                    except OSError:
                        continue
        except OSError:
            pass
        return out

    # ---- macOS ---------------------------------------------------------
    def _detect_mac(self) -> List[StorageLocation]:
        out: List[StorageLocation] = []
        home = os.path.expanduser("~")
        try:
            for name in os.listdir(home):
                low = name.lower()
                if low.startswith("onedrive") or low.startswith("library/cloudstorage"):
                    p = os.path.join(home, name)
                    if _exists(p):
                        out.append(StorageLocation("onedrive", name, p, True))
        except OSError:
            pass
        # macOS modern path: ~/Library/CloudStorage/OneDrive-*
        cloud = os.path.join(home, "Library", "CloudStorage")
        if _exists(cloud):
            try:
                for name in os.listdir(cloud):
                    p = os.path.join(cloud, name)
                    if not _exists(p):
                        continue
                    if name.startswith("OneDrive-"):
                        out.append(StorageLocation("onedrive_business", name.replace("OneDrive-", "OneDrive: "), p, True))
                    elif name.startswith("SharePoint-"):
                        out.append(StorageLocation("sharepoint", name.replace("SharePoint-", "SharePoint: "), p, True))
            except OSError:
                pass
        return out

    # ---- Linux (best effort) ------------------------------------------
    def _detect_linux(self) -> List[StorageLocation]:
        out: List[StorageLocation] = []
        home = os.path.expanduser("~")
        for cand in ("OneDrive", "onedrive", os.path.join(".config", "onedrive")):
            p = os.path.join(home, cand)
            if _exists(p):
                out.append(StorageLocation("onedrive", cand, p, True))
        return out


class StorageManager:
    """Chooses and persists the export destination."""

    SETTINGS_FILE = "storage_settings.json"

    def __init__(self, base_path: str = "."):
        self.base_path = base_path
        self.settings_path = os.path.join(base_path, self.SETTINGS_FILE)
        self.detector = OneDriveDetector()
        self.settings = {
            "destination_kind": "local",
            "destination_path": os.path.join(base_path, "exports"),
            "subfolder": "QA-Reports",
        }
        self._load()

    def _load(self):
        if os.path.exists(self.settings_path):
            try:
                with open(self.settings_path, "r", encoding="utf-8") as f:
                    self.settings.update(json.load(f))
            except Exception:
                pass

    def save(self):
        try:
            with open(self.settings_path, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=2)
            return True
        except Exception:
            return False

    def detect_all(self) -> List[StorageLocation]:
        """Local + cloud + custom, in display order."""
        locs = [StorageLocation("local", "Local Storage",
                                os.path.join(self.base_path, "exports"), True)]
        locs.extend(self.detector.detect())
        custom = self.settings.get("custom_path")
        if _exists(custom):
            locs.append(StorageLocation("custom", "Custom Folder", custom, True))
        return locs

    def set_destination(self, kind: str, path: str):
        self.settings["destination_kind"] = kind
        self.settings["destination_path"] = path
        if kind == "custom":
            self.settings["custom_path"] = path
        self.save()

    def resolve_export_dir(self) -> str:
        """Absolute directory to write exports into (created if missing)."""
        root = self.settings.get("destination_path") or os.path.join(self.base_path, "exports")
        sub = self.settings.get("subfolder", "")
        target = os.path.join(root, sub) if sub else root
        try:
            os.makedirs(target, exist_ok=True)
        except OSError:
            target = os.path.join(self.base_path, "exports")
            os.makedirs(target, exist_ok=True)
        return target


if __name__ == "__main__":
    sm = StorageManager(".")
    print("Detected storage locations:")
    for loc in sm.detect_all():
        flag = "OK" if loc.available else "--"
        print(f"  [{flag}] {loc.kind:18} {loc.label:28} {loc.path}")
    print("Export dir resolves to:", sm.resolve_export_dir())
