"""
Premium dialogs — advanced auth (sign in / register / forgot password) and
center-screen modals (announcement / update / feature / feedback / thank-you).
Dark, smooth, professional. No backend details are ever shown to the user.
"""

from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                             QLineEdit, QPushButton, QCheckBox, QTextEdit,
                             QFrame, QStackedWidget, QWidget, QListWidget,
                             QGraphicsDropShadowEffect, QButtonGroup)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer
from PyQt6.QtGui import QColor, QPixmap
import os, sys, threading

BG_DEEP = "#0a0b16"
CARD = "#15172b"
ACCENT = "#6c63ff"
TEXT = "#f1f5f9"
MUTED = "#94a3b8"
BORDER = "#262a44"
FIELD = "#0e1020"

_INPUT = f"""
QLineEdit {{ background:{FIELD}; border:1px solid {BORDER}; border-radius:10px;
            padding:12px 13px; color:{TEXT}; font-size:13px; }}
QLineEdit:focus {{ border:1px solid {ACCENT}; }}
QLineEdit::placeholder {{ color:#5b6280; }}
"""
_PRIMARY = f"""
QPushButton {{ background:{ACCENT}; color:white; border:none; border-radius:10px;
              padding:12px 16px; font-size:13px; font-weight:700; }}
QPushButton:hover {{ background:#5a52e0; }}
QPushButton:pressed {{ background:#4e46cc; }}
QPushButton:disabled {{ background:#2a2c44; color:#6b7194; }}
"""
_GHOST = f"""
QPushButton {{ background:transparent; color:{TEXT}; border:1px solid {BORDER};
              border-radius:10px; padding:12px 16px; font-size:13px; font-weight:600; }}
QPushButton:hover {{ background:#1c1f38; border-color:{ACCENT}; }}
"""
_LINK = (f"QPushButton{{background:transparent;border:none;color:{ACCENT};"
         f"font-size:12px;}}QPushButton:hover{{text-decoration:underline;}}")


def _play_alert(level="info"):
    """Play a short, non-blocking system sound for a modal."""
    def run():
        try:
            if sys.platform == "win32":
                import winsound
                m = {"info": winsound.MB_ICONASTERISK, "success": winsound.MB_OK,
                     "warning": winsound.MB_ICONEXCLAMATION, "error": winsound.MB_ICONHAND}
                winsound.MessageBeep(m.get(level, winsound.MB_OK))
            elif sys.platform == "darwin":
                snd = {"info": "Ping", "success": "Glass", "warning": "Sosumi", "error": "Basso"}
                os.system(f"afplay /System/Library/Sounds/{snd.get(level,'Ping')}.aiff")
            else:
                os.system("paplay /usr/share/sounds/freedesktop/stereo/message.oga 2>/dev/null || true")
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()


class _Base(QDialog):
    def __init__(self, parent=None, width=440):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setModal(True)
        wrap = QVBoxLayout(self); wrap.setContentsMargins(26, 26, 26, 26)
        self.card = QFrame(); self.card.setObjectName("card")
        self.card.setStyleSheet(f"QFrame#card{{background:{CARD};border:1px solid {BORDER};border-radius:20px;}}")
        sh = QGraphicsDropShadowEffect(self); sh.setBlurRadius(70); sh.setXOffset(0)
        sh.setYOffset(20); sh.setColor(QColor(0, 0, 0, 210)); self.card.setGraphicsEffect(sh)
        wrap.addWidget(self.card)
        self.body = QVBoxLayout(self.card); self.body.setContentsMargins(32, 30, 32, 28); self.body.setSpacing(12)
        self.setFixedWidth(width + 52)
        self.setStyleSheet('QLabel{background:transparent;}')
        self._alert = None

    def _icon_badge(self, emoji, color):
        lab = QLabel(emoji); lab.setFixedSize(48, 48)
        lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lab.setStyleSheet(f"background:{color}22;border:1px solid {color}55;border-radius:24px;font-size:22px;")
        return lab

    def _header(self, emoji, color, title):
        row = QHBoxLayout(); row.setSpacing(12)
        row.addWidget(self._icon_badge(emoji, color))
        t = QLabel(title); t.setWordWrap(True)
        t.setStyleSheet(f"color:{TEXT};font-size:19px;font-weight:800;background:transparent;")
        row.addWidget(t, 1); self.body.addLayout(row)

    def showEvent(self, e):
        super().showEvent(e)
        scr = self.screen().availableGeometry() if self.screen() else None
        if scr:
            self.move(scr.center().x() - self.width() // 2, scr.center().y() - self.height() // 2)
        self.setWindowOpacity(0.0)
        self._f = QPropertyAnimation(self, b"windowOpacity", self)
        self._f.setDuration(220); self._f.setStartValue(0.0); self._f.setEndValue(1.0)
        self._f.setEasingCurve(QEasingCurve.Type.OutCubic); self._f.start()
        if self._alert: _play_alert(self._alert)

    def _title(self, t, size=21):
        l = QLabel(t); l.setStyleSheet(f"color:{TEXT};font-size:{size}px;font-weight:800;background:transparent;")
        l.setWordWrap(True); return l

    def _sub(self, t, color=MUTED, size=12):
        l = QLabel(t); l.setStyleSheet(f"color:{color};font-size:{size}px;background:transparent;"); l.setWordWrap(True); return l

    def _field_label(self, t):
        return self._sub(t, color="#aeb6cc", size=11)


def _pw_row(line_edit):
    """password field + eye toggle, returns the layout."""
    row = QHBoxLayout(); row.setSpacing(8)
    line_edit.setStyleSheet(_INPUT); line_edit.setEchoMode(QLineEdit.EchoMode.Password)
    row.addWidget(line_edit, 1)
    eye = QPushButton("👁"); eye.setCheckable(True); eye.setFixedWidth(46)
    eye.setStyleSheet(_GHOST); eye.setCursor(Qt.CursorShape.PointingHandCursor)
    eye.toggled.connect(lambda on: line_edit.setEchoMode(
        QLineEdit.EchoMode.Normal if on else QLineEdit.EchoMode.Password))
    row.addWidget(eye)
    return row


class AuthDialog(_Base):
    """Two-panel sign in / create account. Left brand panel stays the same in both
    modes; the right form changes. New accounts run a step-by-step onboarding."""

    ONB = [
        {"key": "full_name", "q": "What's your full name?", "type": "text", "ph": "e.g. Sachin Sharma"},
        {"key": "referrer",  "q": "Who suggested this app to you?", "type": "text", "ph": "Colleague, blog, search…"},
        {"key": "role",      "q": "What best describes your role?", "type": "choice",
         "opts": ["QA Engineer", "Developer", "Manager", "Other"]},
        {"key": "team_size", "q": "How big is your team?", "type": "choice",
         "opts": ["Just me", "2–10", "11–50", "50+"]},
        {"key": "use_case",  "q": "What will you mainly use it for?", "type": "choice",
         "opts": ["Bug reporting", "Test documentation", "UAT sign-off", "Other"]},
    ]

    def __init__(self, auth, icon_path=None, parent=None):
        super().__init__(parent, width=748)
        self.auth = auth
        self.icon_path = icon_path
        self._onb_idx = 0
        self._onb_answers = {}
        self.card.setMinimumHeight(508)
        self.body.setContentsMargins(0, 0, 0, 0)
        self.body.setSpacing(0)

        rowwrap = QHBoxLayout(); rowwrap.setContentsMargins(0, 0, 0, 0); rowwrap.setSpacing(0)
        rowwrap.addWidget(self._build_left())
        self.stack = QStackedWidget()
        self.stack.addWidget(self._login_form())     # 0
        self.stack.addWidget(self._register_form())  # 1
        self.stack.addWidget(self._onboarding_page()) # 2
        right = QWidget(); rv = QVBoxLayout(right); rv.setContentsMargins(34, 30, 34, 30)
        rv.addWidget(self.stack)
        right.setStyleSheet("background:transparent;")
        rowwrap.addWidget(right, 1)
        self.body.addLayout(rowwrap)

    # ---------- left brand panel (same in both modes) ----------
    def _build_left(self):
        panel = QFrame(); panel.setFixedWidth(300)
        panel.setStyleSheet(
            "QFrame{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,"
            "stop:0 #6c63ff, stop:0.55 #5a52e0, stop:1 #221c5a);"
            "border-top-left-radius:20px;border-bottom-left-radius:20px;} QLabel{background:transparent;}")
        v = QVBoxLayout(panel); v.setContentsMargins(30, 32, 28, 30); v.setSpacing(14)
        brand = QHBoxLayout(); brand.setSpacing(10)
        if self.icon_path:
            logo = QLabel(); pm = QPixmap(self.icon_path)
            if not pm.isNull():
                logo.setPixmap(pm.scaled(34, 34, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                brand.addWidget(logo)
        bn = QLabel("QA Assistant"); bn.setStyleSheet("color:white;font-size:17px;font-weight:800;")
        brand.addWidget(bn); brand.addStretch(); v.addLayout(brand)
        v.addSpacing(8)
        head = QLabel("Document QA\nlike a pro."); head.setStyleSheet("color:white;font-size:26px;font-weight:800;line-height:120%;")
        head.setWordWrap(True); v.addWidget(head)
        sub = QLabel("Capture, annotate and ship polished test reports in minutes.")
        sub.setStyleSheet("color:#e8e6ff;font-size:12.5px;"); sub.setWordWrap(True); v.addWidget(sub)
        v.addSpacing(10)
        for emoji, txt in [("📸", "Smart screenshot capture"), ("🤖", "AI-written test docs"),
                           ("📄", "One-click pro reports"), ("☁", "Cloud sync & admin tools")]:
            r = QHBoxLayout(); r.setSpacing(10)
            ic = QLabel(emoji); ic.setFixedSize(30, 30); ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
            ic.setStyleSheet("background:rgba(255,255,255,0.16);border-radius:15px;font-size:14px;")
            r.addWidget(ic)
            lb = QLabel(txt); lb.setStyleSheet("color:white;font-size:12.5px;font-weight:600;")
            r.addWidget(lb, 1); v.addLayout(r)
        v.addStretch()
        foot = QLabel("v4.0 · Secure sign-in"); foot.setStyleSheet("color:#cfccff;font-size:10.5px;")
        v.addWidget(foot)
        return panel

    # ---------- field with leading icon ----------
    def _iconput(self, emoji, placeholder, password=False):
        frame = QFrame(); frame.setFixedHeight(46)
        frame.setStyleSheet(f"QFrame{{background:{FIELD};border:1px solid {BORDER};border-radius:11px;}}")
        h = QHBoxLayout(frame); h.setContentsMargins(12, 0, 8, 0); h.setSpacing(8)
        ic = QLabel(emoji); ic.setStyleSheet("background:transparent;font-size:13px;color:#8b93b3;"); h.addWidget(ic)
        le = QLineEdit(); le.setPlaceholderText(placeholder)
        le.setStyleSheet(f"QLineEdit{{background:transparent;border:none;color:{TEXT};font-size:13px;}}")
        if password:
            le.setEchoMode(QLineEdit.EchoMode.Password)
        h.addWidget(le, 1)
        eye = None
        if password:
            eye = QPushButton("👁"); eye.setCheckable(True); eye.setFixedSize(28, 28)
            eye.setCursor(Qt.CursorShape.PointingHandCursor)
            eye.setStyleSheet("QPushButton{background:transparent;border:none;color:#8b93b3;font-size:13px;}QPushButton:hover{color:#fff;}")
            eye.toggled.connect(lambda on: le.setEchoMode(QLineEdit.EchoMode.Normal if on else QLineEdit.EchoMode.Password))
            h.addWidget(eye)
        return frame, le, eye

    def _link(self, text, cb):
        b = QPushButton(text); b.setCursor(Qt.CursorShape.PointingHandCursor); b.setStyleSheet(_LINK); b.clicked.connect(cb)
        return b

    # ---------- login form ----------
    def _login_form(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(10)
        v.addWidget(self._title("Welcome back 👋", size=22))
        v.addWidget(self._sub("Log in to your account", size=12.5))
        v.addSpacing(4)
        fr, self.l_email, _ = self._iconput("✉", "What's your e-mail?"); v.addWidget(fr)
        fr2, self.l_pw, _ = self._iconput("🔒", "Enter your password", password=True)
        self.l_pw.returnPressed.connect(self._do_login); v.addWidget(fr2)
        opts = QHBoxLayout()
        self.remember = QCheckBox("Remember me"); self.remember.setChecked(True)
        self.remember.setStyleSheet(f"color:{MUTED};font-size:12px;background:transparent;")
        opts.addWidget(self.remember); opts.addStretch()
        opts.addWidget(self._link("Forgot password?", self._forgot)); v.addLayout(opts)
        self.l_err = self._sub("", color="#ef4444"); v.addWidget(self.l_err)
        self.login_btn = QPushButton("Continue"); self.login_btn.setStyleSheet(_PRIMARY)
        self.login_btn.setCursor(Qt.CursorShape.PointingHandCursor); self.login_btn.clicked.connect(self._do_login)
        v.addWidget(self.login_btn)
        bottom = QHBoxLayout(); bottom.addStretch()
        bottom.addWidget(self._sub("Don't have an account?", size=12))
        bottom.addWidget(self._link("Sign up", lambda: self._switch(1))); bottom.addStretch()
        v.addLayout(bottom); v.addStretch()
        return w

    # ---------- register form ----------
    def _register_form(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(10)
        v.addWidget(self._title("Create your account 🚀", size=22))
        v.addWidget(self._sub("Start documenting in minutes", size=12.5))
        v.addSpacing(2)
        fr0, self.r_name, _ = self._iconput("👤", "Your full name"); v.addWidget(fr0)
        fr1, self.r_email, _ = self._iconput("✉", "What's your e-mail?"); v.addWidget(fr1)
        fr2, self.r_pw, _ = self._iconput("🔒", "Create a password", password=True); v.addWidget(fr2)
        fr3, self.r_pw2, _ = self._iconput("🔒", "Confirm password", password=True)
        self.r_pw2.returnPressed.connect(self._do_register); v.addWidget(fr3)
        self.r_err = self._sub("", color="#ef4444"); v.addWidget(self.r_err)
        self.reg_btn = QPushButton("Create account"); self.reg_btn.setStyleSheet(_PRIMARY)
        self.reg_btn.setCursor(Qt.CursorShape.PointingHandCursor); self.reg_btn.clicked.connect(self._do_register)
        v.addWidget(self.reg_btn)
        bottom = QHBoxLayout(); bottom.addStretch()
        bottom.addWidget(self._sub("Already have an account?", size=12))
        bottom.addWidget(self._link("Sign in", lambda: self._switch(0))); bottom.addStretch()
        v.addLayout(bottom); v.addStretch()
        return w

    def _switch(self, idx):
        self.l_err.setText(""); self.r_err.setText("")
        self.stack.setCurrentIndex(idx)

    # ---------- actions ----------
    def _busy(self, btn, label):
        btn.setEnabled(False); btn.setText(label)
        from PyQt6.QtWidgets import QApplication
        QApplication.processEvents()

    def _forgot(self):
        em = self.l_email.text().strip()
        if not em:
            self.l_err.setText("Enter your email above, then tap Forgot password."); return
        try:
            self.auth.send_password_reset(em)
            self.l_err.setStyleSheet("color:#10b981;font-size:12px;background:transparent;")
            self.l_err.setText("Password reset email sent. Check your inbox.")
        except Exception as e:
            self.l_err.setStyleSheet("color:#ef4444;font-size:12px;background:transparent;")
            self.l_err.setText(str(e))

    def _do_login(self):
        self.l_err.setText("")
        em, pw = self.l_email.text().strip(), self.l_pw.text()
        if not em or not pw:
            self.l_err.setText("Please enter your email and password."); return
        self._busy(self.login_btn, "Signing in…")
        try:
            self.auth.sign_in(em, pw, remember=self.remember.isChecked()); self.accept()
        except Exception as e:
            self.l_err.setText(str(e)); self.login_btn.setEnabled(True); self.login_btn.setText("Continue")

    def _do_register(self):
        self.r_err.setText("")
        name, em = self.r_name.text().strip(), self.r_email.text().strip()
        pw, pw2 = self.r_pw.text(), self.r_pw2.text()
        if not name or not em or not pw:
            self.r_err.setText("Please fill in your name, email and password."); return
        if pw != pw2:
            self.r_err.setText("Passwords do not match."); return
        self._busy(self.reg_btn, "Creating account…")
        try:
            self.auth.register(name, em, pw, remember=True)
            self._onb_answers["full_name"] = name
            self.stack.setCurrentIndex(2)   # -> onboarding
            self._onb_idx = 0; self._onb_show()
        except Exception as e:
            self.r_err.setText(str(e)); self.reg_btn.setEnabled(True); self.reg_btn.setText("Create account")

    # ---------- onboarding wizard ----------
    def _onboarding_page(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(12)
        self._onb_progress = self._sub("", color=ACCENT, size=11)
        v.addWidget(self._onb_progress)
        self._onb_q = self._title("", size=21); v.addWidget(self._onb_q)
        self._onb_holder = QWidget(); self._onb_hl = QVBoxLayout(self._onb_holder)
        self._onb_hl.setContentsMargins(0, 0, 0, 0); self._onb_hl.setSpacing(8)
        v.addWidget(self._onb_holder)
        self._onb_btn = QPushButton("Next"); self._onb_btn.setStyleSheet(_PRIMARY)
        self._onb_btn.setCursor(Qt.CursorShape.PointingHandCursor); self._onb_btn.clicked.connect(self._onb_next)
        v.addWidget(self._onb_btn)
        v.addStretch()
        return w

    def _clear_holder(self):
        while self._onb_hl.count():
            it = self._onb_hl.takeAt(0); wd = it.widget()
            if wd:
                wd.setParent(None); wd.deleteLater()

    def _onb_show(self):
        step = self.ONB[self._onb_idx]
        self._onb_progress.setText(f"STEP {self._onb_idx + 1} OF {len(self.ONB)}")
        self._onb_q.setText(step["q"])
        self._clear_holder()
        self._onb_field = None
        if step["type"] == "text":
            fr, le, _ = self._iconput("✏", step.get("ph", ""))
            pre = self._onb_answers.get(step["key"], "")
            if pre: le.setText(pre)
            self._onb_field = le; self._onb_hl.addWidget(fr)
            self._onb_btn.setVisible(True)
            self._onb_btn.setText("Finish ✓" if self._onb_idx == len(self.ONB) - 1 else "Next")
        else:
            for opt in step["opts"]:
                b = QPushButton(opt); b.setStyleSheet(_GHOST + "QPushButton{text-align:left;padding-left:14px;}")
                b.setCursor(Qt.CursorShape.PointingHandCursor)
                b.clicked.connect(lambda _, o=opt: self._onb_choose(o))
                self._onb_hl.addWidget(b)
            self._onb_btn.setVisible(False)   # choices auto-advance

    def _onb_choose(self, opt):
        self._onb_answers[self.ONB[self._onb_idx]["key"]] = opt
        self._onb_advance()

    def _onb_next(self):
        step = self.ONB[self._onb_idx]
        if step["type"] == "text" and self._onb_field is not None:
            val = self._onb_field.text().strip()
            if not val:
                self._onb_q.setText(step["q"] + "  (required)"); return
            self._onb_answers[step["key"]] = val
        self._onb_advance()

    def _onb_advance(self):
        if self._onb_idx >= len(self.ONB) - 1:
            self._onb_finish(); return
        self._onb_idx += 1; self._onb_show()

    def _onb_finish(self):
        self._onb_btn.setVisible(True); self._onb_btn.setEnabled(False); self._onb_btn.setText("Setting up…")
        from PyQt6.QtWidgets import QApplication; QApplication.processEvents()
        try:
            from cloud_sync import store_onboarding
            u = getattr(self.auth, "current_user", None)
            if u:
                data = dict(self._onb_answers); data["email"] = u.email
                store_onboarding(u.uid, getattr(self.auth, "id_token", lambda: None)(), data)
        except Exception:
            pass
        self.accept()


# back-compat alias (main.py imports LoginDialog)
LoginDialog = AuthDialog




# ── center-screen modals ────────────────────────────────────────────────
class AnnouncementModal(_Base):
    def __init__(self, item, parent=None):
        super().__init__(parent, width=460)
        self._alert = item.get("level", "info")
        self._header("📢", ACCENT, item.get("title", "Announcement"))
        if item.get("version"):
            chip = QLabel(item["version"]); chip.setStyleSheet(
                f"color:{ACCENT};background:#1d1b3a;border:1px solid {ACCENT}55;"
                f"border-radius:8px;padding:3px 10px;font-size:12px;font-weight:700;")
            r = QHBoxLayout(); r.addWidget(chip); r.addStretch(); self.body.addLayout(r)
        self.body.addWidget(self._sub(item.get("body", ""), color=TEXT, size=13))
        self.body.addSpacing(8)
        b = QPushButton("Acknowledge"); b.setStyleSheet(_PRIMARY)
        b.setCursor(Qt.CursorShape.PointingHandCursor); b.clicked.connect(self.accept)
        self.body.addWidget(b)


class UpdateModal(_Base):
    UPDATE_NOW = 1; LATER = 0
    def __init__(self, version, notes="", parent=None):
        super().__init__(parent, width=460); self.choice = self.LATER
        self._alert = "info"
        self._header("🚀", "#22d3ee", "Update Available")
        chip = QLabel(f"Version {version}"); chip.setStyleSheet(
            f"color:{ACCENT};background:#1d1b3a;border:1px solid {ACCENT}55;"
            f"border-radius:8px;padding:3px 10px;font-size:12px;font-weight:700;")
        r = QHBoxLayout(); r.addWidget(chip); r.addStretch(); self.body.addLayout(r)
        if notes:
            self.body.addWidget(self._sub("What's new:", color=MUTED))
            self.body.addWidget(self._sub(notes, color=TEXT, size=13))
        self.body.addSpacing(8)
        row = QHBoxLayout()
        later = QPushButton("Later"); later.setStyleSheet(_GHOST); later.clicked.connect(self.reject)
        now = QPushButton("Update Now"); now.setStyleSheet(_PRIMARY)
        now.clicked.connect(lambda: (setattr(self, "choice", self.UPDATE_NOW), self.accept()))
        row.addWidget(later); row.addWidget(now, 1); self.body.addLayout(row)


class FeatureModal(_Base):
    TRY = 1; CLOSE = 0
    def __init__(self, item, parent=None):
        super().__init__(parent, width=460); self.choice = self.CLOSE
        self._alert = "success"
        self._header("✨", "#a78bfa", "New Feature")
        self.body.addWidget(self._sub(item.get("title", ""), color=TEXT, size=15))
        self.body.addWidget(self._sub(item.get("body", ""), color=MUTED, size=13))
        self.body.addSpacing(8)
        row = QHBoxLayout()
        close = QPushButton("Close"); close.setStyleSheet(_GHOST); close.clicked.connect(self.reject)
        tryit = QPushButton("Try It"); tryit.setStyleSheet(_PRIMARY)
        tryit.clicked.connect(lambda: (setattr(self, "choice", self.TRY), self.accept()))
        row.addWidget(close); row.addWidget(tryit, 1); self.body.addLayout(row)


class FeedbackDialog(_Base):
    def __init__(self, parent=None):
        super().__init__(parent, width=420); self.rating = 5
        self.body.addWidget(self._title("Rate your experience", size=19))
        self.body.addWidget(self._sub("Your feedback helps us improve.", size=12))
        stars = QHBoxLayout(); stars.setSpacing(6); self._btns = []
        for n in range(1, 6):
            b = QPushButton("★"); b.setFixedSize(46, 44); b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _, k=n: self._set(k)); stars.addWidget(b); self._btns.append(b)
        stars.addStretch(); self.body.addLayout(stars)
        self.comment = QTextEdit()
        self.comment.setStyleSheet(f"QTextEdit{{background:{FIELD};border:1px solid {BORDER};"
                                   f"border-radius:10px;padding:8px;color:{TEXT};font-size:13px;}}"
                                   f"QTextEdit:focus{{border:1px solid {ACCENT};}}")
        self.comment.setPlaceholderText("Comments (optional)…"); self.comment.setFixedHeight(92)
        self.body.addWidget(self.comment)
        row = QHBoxLayout()
        skip = QPushButton("Skip"); skip.setStyleSheet(_GHOST); skip.clicked.connect(self.reject)
        sub = QPushButton("Submit"); sub.setStyleSheet(_PRIMARY); sub.clicked.connect(self.accept)
        row.addWidget(skip); row.addWidget(sub, 1); self.body.addLayout(row)
        self._set(5)

    def _set(self, n):
        self.rating = n
        for i, b in enumerate(self._btns, 1):
            b.setText("★" if i <= n else "☆")
            b.setStyleSheet(f"font-size:22px;border:none;background:transparent;"
                            f"color:{'#f0b429' if i <= n else '#3b3f5c'};")

    def result_data(self):
        return self.rating, self.comment.toPlainText().strip()


class ThankYouModal(_Base):
    def __init__(self, text="Thank you!", parent=None):
        super().__init__(parent, width=320)
        self.body.addWidget(self._title("✓  " + text, size=18))
        QTimer.singleShot(1400, self.accept)


class BlockedDialog(_Base):
    """Shown when the admin has blocked the user. Embeds live admin chat + AI help
    so the user can ask why they were blocked or request a review."""

    def __init__(self, cloud=None, ai=None, parent=None):
        super().__init__(parent, width=470)
        self._alert = "error"
        self._cloud = cloud
        self._ai = ai
        self._seen = set()

        self._header("\u26d4", "#ef4444", "Access Restricted")
        self.body.addWidget(self._sub(
            "Your access has been disabled by the administrator. You can ask why or "
            "request a review below \u2014 message an admin or the assistant.",
            color=TEXT, size=13))

        self._log = QListWidget()
        self._log.setStyleSheet(f"QListWidget{{background:{FIELD};border:1px solid {BORDER};"
                                f"border-radius:10px;color:{TEXT};font-size:12px;padding:6px;}}"
                                f"QListWidget::item{{padding:3px 2px;}}")
        self._log.setMinimumHeight(150); self._log.setWordWrap(True)
        self.body.addWidget(self._log)

        self._input = QLineEdit(); self._input.setStyleSheet(_INPUT)
        self._input.setPlaceholderText("Message the admin, or ask the assistant\u2026")
        self._input.returnPressed.connect(self._send_admin)
        self.body.addWidget(self._input)

        brow = QHBoxLayout(); brow.setSpacing(8)
        self._ask_btn = QPushButton("Ask AI"); self._ask_btn.setStyleSheet(_GHOST)
        self._ask_btn.setCursor(Qt.CursorShape.PointingHandCursor); self._ask_btn.clicked.connect(self._ask_ai)
        send = QPushButton("Send to Admin"); send.setStyleSheet(_PRIMARY)
        send.setCursor(Qt.CursorShape.PointingHandCursor); send.clicked.connect(self._send_admin)
        brow.addWidget(self._ask_btn); brow.addWidget(send, 1)
        self.body.addLayout(brow)

        close = QPushButton("Close App"); close.setStyleSheet(_GHOST)
        close.setCursor(Qt.CursorShape.PointingHandCursor); close.clicked.connect(self.accept)
        self.body.addWidget(close)

        if not self._ai:
            self._ask_btn.setEnabled(False)
        if self._cloud and getattr(self._cloud, "enabled", False):
            QTimer.singleShot(250, self._refresh)
            self._timer = QTimer(self); self._timer.timeout.connect(self._refresh); self._timer.start(6000)
        else:
            self._log.addItem("\u26a0  Live chat needs an internet connection.")

    def _refresh(self):
        if not (self._cloud and self._cloud.enabled):
            return
        try:
            msgs = self._cloud.fetch_chat()
        except Exception:
            return
        for m in msgs:
            mid = m.get("id")
            if mid in self._seen:
                continue
            self._seen.add(mid)
            who = "\U0001F9D1 You" if m.get("from") == "user" else "\U0001F6DF Admin"
            self._log.addItem(f"{who}:  {m.get('text','')}")
        self._log.scrollToBottom()

    def _send_admin(self):
        t = self._input.text().strip()
        if not t:
            return
        if not (self._cloud and self._cloud.enabled):
            self._log.addItem("\u26a0  No connection \u2014 can't reach the admin right now.")
            return
        self._input.clear()
        try:
            self._cloud.send_chat(t); self._cloud.flush(); self._refresh()
        except Exception:
            self._log.addItem("\u26a0  Could not send. Please try again.")

    def _ask_ai(self):
        t = self._input.text().strip()
        if not t or not self._ai:
            return
        self._input.clear()
        self._log.addItem(f"\U0001F9D1 You:  {t}")
        try:
            ans = self._ai.chat(t)
        except Exception:
            ans = "I'm unable to answer right now."
        self._log.addItem(f"\U0001F916 Assistant:  {ans}")
        self._log.scrollToBottom()

    def reject(self):
        self.accept()  # prevent Esc-only bypass; Close App quits


class BlockedScreen(QWidget):
    """FULL-SCREEN Access Restricted takeover. Replaces the whole UI, with live
    admin chat + AI so the user can ask why they were blocked or request a review."""

    def __init__(self, cloud=None, ai=None):
        super().__init__()
        self._cloud = cloud
        self._ai = ai
        self._seen = set()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setStyleSheet(f"background:{BG_DEEP};")

        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0)
        outer.addStretch()
        rowc = QHBoxLayout(); rowc.addStretch()

        card = QFrame(); card.setObjectName("card"); card.setFixedWidth(540)
        card.setStyleSheet(f"QFrame#card{{background:{CARD};border:1px solid {BORDER};"
                           f"border-radius:22px;}} QLabel{{background:transparent;}}")
        sh = QGraphicsDropShadowEffect(self); sh.setBlurRadius(80); sh.setYOffset(24)
        sh.setColor(QColor(0, 0, 0, 220)); card.setGraphicsEffect(sh)
        b = QVBoxLayout(card); b.setContentsMargins(36, 32, 36, 30); b.setSpacing(13)

        hb = QHBoxLayout(); hb.setSpacing(13)
        badge = QLabel("\u26d4"); badge.setFixedSize(54, 54); badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setStyleSheet("background:#ef444422;border:1px solid #ef444455;border-radius:27px;font-size:26px;")
        hb.addWidget(badge)
        ttl = QLabel("Access Restricted"); ttl.setStyleSheet(f"color:{TEXT};font-size:24px;font-weight:800;")
        hb.addWidget(ttl, 1); b.addLayout(hb)

        msg = QLabel("Your access has been disabled by the administrator. You can ask why or "
                     "request a review below \u2014 message an admin or the assistant.")
        msg.setWordWrap(True); msg.setStyleSheet(f"color:{TEXT};font-size:13px;"); b.addWidget(msg)

        self._log = QListWidget()
        self._log.setStyleSheet(f"QListWidget{{background:{FIELD};border:1px solid {BORDER};"
                                f"border-radius:12px;color:{TEXT};font-size:12px;padding:8px;}}"
                                f"QListWidget::item{{padding:3px 2px;}}")
        self._log.setMinimumHeight(200); self._log.setWordWrap(True)
        b.addWidget(self._log)

        self._input = QLineEdit(); self._input.setStyleSheet(_INPUT)
        self._input.setPlaceholderText("Message the admin, or ask the assistant\u2026")
        self._input.returnPressed.connect(self._send_admin); b.addWidget(self._input)

        brow = QHBoxLayout(); brow.setSpacing(8)
        self._ask_btn = QPushButton("Ask AI"); self._ask_btn.setStyleSheet(_GHOST)
        self._ask_btn.setCursor(Qt.CursorShape.PointingHandCursor); self._ask_btn.clicked.connect(self._ask_ai)
        send = QPushButton("Send to Admin"); send.setStyleSheet(_PRIMARY)
        send.setCursor(Qt.CursorShape.PointingHandCursor); send.clicked.connect(self._send_admin)
        brow.addWidget(self._ask_btn); brow.addWidget(send, 1); b.addLayout(brow)

        close = QPushButton("Close App"); close.setStyleSheet(_GHOST)
        close.setCursor(Qt.CursorShape.PointingHandCursor); close.clicked.connect(self._quit)
        b.addWidget(close)

        rowc.addWidget(card); rowc.addStretch(); outer.addLayout(rowc); outer.addStretch()

        if not self._ai:
            self._ask_btn.setEnabled(False)
        if self._cloud and getattr(self._cloud, "enabled", False):
            QTimer.singleShot(250, self._refresh)
            self._timer = QTimer(self); self._timer.timeout.connect(self._refresh); self._timer.start(2000)
        else:
            self._log.addItem("\u26a0  Live chat needs an internet connection.")

    def _quit(self):
        from PyQt6.QtWidgets import QApplication
        QApplication.quit()

    def _refresh(self):
        if not (self._cloud and self._cloud.enabled):
            return
        try:
            msgs = self._cloud.fetch_chat()
        except Exception:
            return
        for m in msgs:
            mid = m.get("id")
            if mid in self._seen:
                continue
            self._seen.add(mid)
            who = "\U0001F9D1 You" if m.get("from") == "user" else "\U0001F6DF Admin"
            self._log.addItem(f"{who}:  {m.get('text','')}")
        self._log.scrollToBottom()

    def _send_admin(self):
        t = self._input.text().strip()
        if not t:
            return
        if not (self._cloud and self._cloud.enabled):
            self._log.addItem("\u26a0  No connection \u2014 can't reach the admin right now."); return
        self._input.clear()
        try:
            self._cloud.send_chat(t); self._cloud.flush(); self._refresh()
        except Exception:
            self._log.addItem("\u26a0  Could not send. Please try again.")

    def _ask_ai(self):
        t = self._input.text().strip()
        if not t or not self._ai:
            return
        self._input.clear(); self._log.addItem(f"\U0001F9D1 You:  {t}")
        try:
            ans = self._ai.chat(t)
        except Exception:
            ans = "I'm unable to answer right now."
        self._log.addItem(f"\U0001F916 Assistant:  {ans}"); self._log.scrollToBottom()

    def keyPressEvent(self, e):
        pass  # swallow Esc etc. so the screen can't be dismissed
