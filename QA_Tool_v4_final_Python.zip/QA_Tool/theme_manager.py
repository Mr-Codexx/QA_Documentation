"""
Theme Manager - v4.0

Instant, app-wide theming via Qt stylesheets (QSS). Ships Light, Dark,
Corporate Blue, Healthcare and Custom themes built on a small design-token
system (modern radius, spacing, typography) inspired by Linear/Notion.

Qt-free parts (token tables, QSS generation) are unit-testable. `apply_theme`
only touches Qt when a QApplication exists.

Usage
-----
    from theme_manager import ThemeManager
    tm = ThemeManager()
    tm.apply("corporate_blue", app)        # app = QApplication.instance()
    tm.register_custom("brand", {"accent": "#FF6B00", ...})
"""

from __future__ import annotations

import json
import os
from typing import Dict


# Design tokens per theme. Colors are hex strings.
THEMES: Dict[str, Dict[str, str]] = {
    "light": {
        "bg": "#F7F8FA", "surface": "#FFFFFF", "surface_alt": "#F0F2F5",
        "border": "#E3E6EA", "text": "#1A1D21", "text_muted": "#6B7280",
        "accent": "#2563EB", "accent_hover": "#1D4ED8", "accent_text": "#FFFFFF",
        "ok": "#059669", "warn": "#D97706", "bad": "#DC2626",
    },
    "dark": {
        "bg": "#0F1115", "surface": "#171A21", "surface_alt": "#1E222B",
        "border": "#2A2F3A", "text": "#E6E8EC", "text_muted": "#9AA1AC",
        "accent": "#3B82F6", "accent_hover": "#60A5FA", "accent_text": "#FFFFFF",
        "ok": "#10B981", "warn": "#F59E0B", "bad": "#EF4444",
    },
    "corporate_blue": {
        "bg": "#EEF3F9", "surface": "#FFFFFF", "surface_alt": "#E3ECF6",
        "border": "#CBD9EA", "text": "#0F2A43", "text_muted": "#5A7184",
        "accent": "#1F4E79", "accent_hover": "#2E75B6", "accent_text": "#FFFFFF",
        "ok": "#2E7D32", "warn": "#B7791F", "bad": "#C62828",
    },
    "healthcare": {
        "bg": "#EEF6F5", "surface": "#FFFFFF", "surface_alt": "#DCEFEC",
        "border": "#C2E0DB", "text": "#0E3B36", "text_muted": "#52716C",
        "accent": "#00695C", "accent_hover": "#26A69A", "accent_text": "#FFFFFF",
        "ok": "#2E7D32", "warn": "#B7791F", "bad": "#C62828",
    },
}

# Layout tokens shared by all themes.
TOKENS = {
    "radius": "10px", "radius_sm": "6px", "pad": "8px 14px",
    "font": "'Segoe UI', 'Inter', system-ui, sans-serif", "font_size": "13px",
}


def build_qss(theme: Dict[str, str]) -> str:
    """Generate a full-app QSS stylesheet from a theme token dict."""
    t = {**theme}
    return f"""
QWidget {{
    background: {t['bg']};
    color: {t['text']};
    font-family: {TOKENS['font']};
    font-size: {TOKENS['font_size']};
}}
QFrame#card, QGroupBox {{
    background: {t['surface']};
    border: 1px solid {t['border']};
    border-radius: {TOKENS['radius']};
}}
QPushButton {{
    background: {t['accent']};
    color: {t['accent_text']};
    border: none;
    border-radius: {TOKENS['radius_sm']};
    padding: {TOKENS['pad']};
    font-weight: 600;
}}
QPushButton:hover {{ background: {t['accent_hover']}; }}
QPushButton:disabled {{ background: {t['surface_alt']}; color: {t['text_muted']}; }}
QPushButton[variant="ghost"] {{
    background: transparent; color: {t['text']};
    border: 1px solid {t['border']};
}}
QPushButton[variant="ghost"]:hover {{ background: {t['surface_alt']}; }}
QLineEdit, QTextEdit, QPlainTextEdit, QComboBox {{
    background: {t['surface']};
    border: 1px solid {t['border']};
    border-radius: {TOKENS['radius_sm']};
    padding: 6px 10px;
    selection-background-color: {t['accent']};
}}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus {{ border: 1px solid {t['accent']}; }}
QListWidget, QTreeWidget, QTableWidget {{
    background: {t['surface']};
    border: 1px solid {t['border']};
    border-radius: {TOKENS['radius']};
    outline: none;
}}
QListWidget::item {{ padding: 8px; border-radius: {TOKENS['radius_sm']}; }}
QListWidget::item:selected {{ background: {t['accent']}; color: {t['accent_text']}; }}
QTabBar::tab {{
    background: transparent; color: {t['text_muted']};
    padding: 8px 16px; border: none;
}}
QTabBar::tab:selected {{ color: {t['accent']}; border-bottom: 2px solid {t['accent']}; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {t['border']}; border-radius: 5px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {t['text_muted']}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QToolTip {{
    background: {t['surface']}; color: {t['text']};
    border: 1px solid {t['border']}; border-radius: {TOKENS['radius_sm']}; padding: 6px;
}}
QMenu {{ background: {t['surface']}; border: 1px solid {t['border']}; border-radius: {TOKENS['radius_sm']}; }}
QMenu::item:selected {{ background: {t['accent']}; color: {t['accent_text']}; }}
"""


class ThemeManager:
    def __init__(self, settings_path: str = "theme_settings.json"):
        self.settings_path = settings_path
        self.themes = {k: dict(v) for k, v in THEMES.items()}
        self.current = "light"
        self._load_custom()

    def _load_custom(self):
        if os.path.exists(self.settings_path):
            try:
                with open(self.settings_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.current = data.get("current", "light")
                for name, tokens in (data.get("custom") or {}).items():
                    base = dict(self.themes["light"]); base.update(tokens)
                    self.themes[name] = base
            except Exception:
                pass

    def available(self):
        return list(self.themes.keys())

    def register_custom(self, name: str, tokens: Dict[str, str]):
        base = dict(self.themes["light"]); base.update(tokens)
        self.themes[name] = base
        self._save()

    def qss_for(self, name: str) -> str:
        return build_qss(self.themes.get(name, self.themes["light"]))

    def apply(self, name: str, app=None) -> str:
        """Apply theme to the running QApplication (if any). Returns the QSS."""
        qss = self.qss_for(name)
        self.current = name
        self._save()
        if app is None:
            try:
                from PyQt6.QtWidgets import QApplication
                app = QApplication.instance()
            except Exception:
                app = None
        if app is not None:
            app.setStyleSheet(qss)
        return qss

    def _save(self):
        try:
            custom = {k: v for k, v in self.themes.items() if k not in THEMES}
            with open(self.settings_path, "w", encoding="utf-8") as f:
                json.dump({"current": self.current, "custom": custom}, f, indent=2)
        except Exception:
            pass


if __name__ == "__main__":
    tm = ThemeManager(settings_path="/tmp/theme_settings.json")
    print("themes:", tm.available())
    for name in tm.available():
        qss = tm.qss_for(name)
        assert "QPushButton" in qss and tm.themes[name]["accent"] in qss
        print(f"  {name:16} QSS {len(qss)} chars  accent={tm.themes[name]['accent']}")
    tm.register_custom("brand_orange", {"accent": "#FF6B00", "accent_hover": "#E55F00"})
    assert "#FF6B00" in tm.qss_for("brand_orange")
    print("custom theme registered OK")
