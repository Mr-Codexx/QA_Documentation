"""
Export Engine v3.0 — GOD LEVEL
Cinematic HTML reports, advanced PDF/Excel/Word/Markdown with AI enhancement
"""

import os
import time
import json
import base64
from datetime import datetime
from typing import Dict, List, Optional
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape, A4
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image,
                                 Table, TableStyle, PageBreak, HRFlowable)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from openpyxl import Workbook
from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                              GradientFill)
from openpyxl.drawing.image import Image as XLImage
from openpyxl.utils import get_column_letter
import hashlib


class ExportEngine:
    """Handles export of QA sessions to various formats with AI enhancement"""

    def __init__(self, ai_processor=None):
        self.ai_processor = ai_processor
        self.cache = {}

    def set_ai_processor(self, ai_processor):
        self.ai_processor = ai_processor

    def export_session(self, session, filepath: str, format_type: str) -> bool:
        try:
            if self.ai_processor and not self.ai_processor.fallback_mode:
                self._enhance_session_with_ai(session)

            # Ensure report data exists even without a live AI key (fixes HTML/Word/etc. export)
            if not hasattr(session, "test_cases") or session.test_cases is None:
                session.test_cases = self._generate_basic_test_cases(session)
            if not hasattr(session, "summary") or session.summary is None:
                session.summary = self._generate_basic_summary(session)

            dispatch = {
                "HTML Report":   self._export_html,
                "PDF Document":  self._export_pdf,
                "Excel Sheet":   self._export_excel,
                "Word Document": self._export_word,
                "Markdown":      self._export_markdown,                "Enterprise DOCX": self._export_enterprise_docx,
            }
            fn = dispatch.get(format_type)
            if fn:
                fn(session, filepath)
                return True
            return False
        except Exception as e:
            print(f"Export error: {e}")
            import traceback; traceback.print_exc()
            return False

    # ─────────────────────────────────────────────────────────────────────────
    # HELPERS
    # ─────────────────────────────────────────────────────────────────────────

    def _export_enterprise_docx(self, session, filepath: str):
        """v4.0 consulting-grade DOCX (cover, TOC, evidence table, AI, gallery)."""
        from enterprise_docx import EnterpriseDocxExporter, ReportMeta
        meta_src = getattr(session, "metadata", {}) or {}
        meta = ReportMeta(
            project=getattr(session, "session_name", "QA Session"),
            module=meta_src.get("module", ""),
            tester=meta_src.get("tester", ""),
            environment=meta_src.get("environment", ""),
        )
        EnterpriseDocxExporter(theme="corporate_blue").export(session, filepath, meta=meta)

    def _image_to_base64(self, image_path: str) -> str:
        try:
            with open(image_path, "rb") as f:
                data = base64.b64encode(f.read()).decode("utf-8")
            ext = os.path.splitext(image_path)[1].lower()
            mime = {"jpg": "image/jpeg", ".jpeg": "image/jpeg",
                    ".png": "image/png", ".gif": "image/gif"}.get(ext, "image/png")
            return f"data:{mime};base64,{data}"
        except Exception as e:
            print(f"base64 error: {e}")
            return ""

    def _enhance_session_with_ai(self, session):
        print("\n🤖 Enhancing session with AI analysis...")
        images_to_analyze, step_indices = [], []

        for i, step in enumerate(session.steps):
            if step.image_path and os.path.exists(step.image_path):
                ck = self._get_cache_key(step.image_path)
                if ck in self.cache:
                    cached = self.cache[ck]
                    step.description        = cached.get("description", step.description)
                    step.expected_behavior  = cached.get("expected_behavior", step.expected_behavior)
                    step.actual_observation = cached.get("actual_observation", step.actual_observation)
                    step.bug_hint           = cached.get("bug_hint", step.bug_hint)
                else:
                    images_to_analyze.append(step.image_path)
                    step_indices.append(i)

        if images_to_analyze:
            analyses = self._batch_analyze_with_retry(images_to_analyze, delay=2.0)
            for idx, (step_idx, analysis) in enumerate(zip(step_indices, analyses)):
                if analysis:
                    step = session.steps[step_idx]
                    step.description        = analysis.get("description", step.description)
                    step.expected_behavior  = analysis.get("expected_behavior", step.expected_behavior)
                    step.actual_observation = analysis.get("actual_observation", step.actual_observation)
                    step.bug_hint           = analysis.get("bug_hint", step.bug_hint)
                    ck = self._get_cache_key(images_to_analyze[idx])
                    self.cache[ck] = analysis

        session.test_cases = self._generate_test_cases(session)
        session.summary    = self._generate_executive_summary(session)
        print("✅ AI enhancement complete!\n")

    def _get_cache_key(self, image_path: str) -> str:
        with open(image_path, "rb") as f:
            return hashlib.md5(f.read()).hexdigest()

    def _batch_analyze_with_retry(self, image_paths: list, delay: float = 2.0) -> list:
        results = []
        for i, path in enumerate(image_paths, 1):
            print(f"   Processing {i}/{len(image_paths)}: {os.path.basename(path)}")
            if i > 1:
                time.sleep(delay)
            analysis = self.ai_processor.analyze_screenshot(path)
            results.append(analysis if analysis else self._get_fallback_analysis(path))
        return results

    def _generate_test_cases(self, session) -> List[Dict]:
        if not self.ai_processor or self.ai_processor.fallback_mode:
            return self._generate_basic_test_cases(session)
        try:
            steps_summary = [f"Step {i}: {s.description[:100]}"
                             for i, s in enumerate(session.steps[:15], 1)]
            prompt = f"""You are a QA Test Case Generator. Generate 3-5 formal test cases:
Test Session: {session.session_name}
Steps: {chr(10).join(steps_summary)}

JSON format:
{{"test_cases": [{{"id":"TC001","title":"...","preconditions":[],"test_steps":[],"expected_results":[],"priority":"High","test_data":"..."}}]}}"""
            response = self.ai_processor._make_api_call(prompt, is_vision=False)
            if response:
                import re
                m = re.search(r'\{.*"test_cases".*\}', response, re.DOTALL)
                if m:
                    return json.loads(m.group()).get("test_cases", [])
        except Exception as e:
            print(f"AI test case gen failed: {e}")
        return self._generate_basic_test_cases(session)

    def _generate_basic_test_cases(self, session) -> List[Dict]:
        categories = {}
        for step in session.steps:
            d = (step.description or "").lower()
            if any(x in d for x in ["login", "sign in", "auth"]):
                cat = "Authentication"
            elif any(x in d for x in ["click", "button", "menu"]):
                cat = "UI Interactions"
            elif any(x in d for x in ["form", "input", "field"]):
                cat = "Form Validation"
            elif any(x in d for x in ["create", "save", "submit"]):
                cat = "Data Creation"
            elif any(x in d for x in ["view", "display", "show"]):
                cat = "Data Viewing"
            else:
                cat = "General Functionality"
            categories.setdefault(cat, []).append(step)

        pmap = {"Authentication": "High", "Data Creation": "High",
                "Form Validation": "Medium", "UI Interactions": "Medium",
                "Data Viewing": "Low", "General Functionality": "Medium"}
        return [
            {
                "id": f"TC{i:03d}",
                "title": f"Verify {cat} functionality",
                "preconditions": ["System is accessible", "User has required permissions"],
                "test_steps": [f"{j}. {s.description[:80]}" for j, s in enumerate(steps, 1)],
                "expected_results": [f"Step {j} completes without errors" for j in range(1, len(steps)+1)],
                "priority": pmap.get(cat, "Medium"),
                "test_data": "Per test environment config"
            }
            for i, (cat, steps) in enumerate(categories.items(), 1)
        ]

    def _generate_executive_summary(self, session) -> Dict:
        if not self.ai_processor or self.ai_processor.fallback_mode:
            return self._generate_basic_summary(session)
        try:
            bugs = [s for s in session.steps if s.bug_hint and "No obvious" not in (s.bug_hint or "")]
            prompt = f"""Executive summary for QA session:
Session: {session.session_name}, Steps: {len(session.steps)}, Issues: {len(bugs)}
JSON: {{"overall_status":"Pass/Fail/Warning","summary":"...","key_findings":[],"recommendations":[],"risk_assessment":"..."}}"""
            resp = self.ai_processor._make_api_call(prompt, is_vision=False)
            if resp:
                import re
                m = re.search(r'\{.*"overall_status".*\}', resp, re.DOTALL)
                if m:
                    return json.loads(m.group())
        except Exception:
            pass
        return self._generate_basic_summary(session)

    def _generate_basic_summary(self, session) -> Dict:
        bugs = len([s for s in session.steps
                    if s.bug_hint and "No obvious" not in (s.bug_hint or "")])
        return {
            "overall_status": "Needs Review" if bugs > 0 else "Pass",
            "summary": f"Session '{session.session_name}' completed with {len(session.steps)} steps. {bugs} issues identified.",
            "key_findings": [f"Step {i+1}: {s.description[:60]}" for i, s in enumerate(session.steps[:3])],
            "recommendations": (["Review identified issues", "Retest failed scenarios"] if bugs
                                 else ["Continue with next test cycle"]),
            "risk_assessment": "Medium risk — issues require attention" if bugs else "Low risk — all steps passed"
        }

    def _get_fallback_analysis(self, image_path: str) -> Dict:
        with open(image_path, "rb") as f:
            h = hashlib.md5(f.read()).hexdigest()[:8]
        return {
            "description": f"Screenshot captured (ID: {h})",
            "expected_behavior": "Verify expected behavior manually",
            "actual_observation": "Review screenshot for actual state",
            "bug_hint": "Manual review required"
        }

    # ─────────────────────────────────────────────────────────────────────────
    #  HTML EXPORT
    # ─────────────────────────────────────────────────────────────────────────

    def _export_html(self, session, filepath: str):
        """Cinematic, fully responsive HTML report with dark/light mode toggle."""
        steps     = session.steps
        bug_steps = [s for s in steps if s.bug_hint and
                     s.bug_hint not in ("No obvious issues", "No obvious issues detected", "")]
        tc        = session.test_cases
        summary   = session.summary
        status    = summary.get("overall_status", "N/A")
        gen_time  = datetime.now().strftime("%d %B %Y · %H:%M:%S")

        status_color = {
            "Pass": "#10b981", "Fail": "#ef4444",
            "Needs Review": "#f59e0b", "Warning": "#f59e0b"
        }.get(status, "#6c63ff")

        # ── Stat cards ──────────────────────────────────────────────
        def stat_card(icon, value, label, color):
            return f"""
        <div class="stat-card">
          <div class="stat-icon" style="background:{color}22;color:{color}">{icon}</div>
          <div class="stat-body">
            <div class="stat-value" style="color:{color}">{value}</div>
            <div class="stat-label">{label}</div>
          </div>
        </div>"""

        stats_html = (
            stat_card("📋", len(steps), "Total Steps", "#6c63ff") +
            stat_card("📂", len(tc), "Test Cases", "#0ea5e9") +
            stat_card("⚠", len(bug_steps), "Issues Found", "#f59e0b") +
            stat_card("📊", status, "Status", status_color)
        )

        # ── Test Cases HTML ──────────────────────────────────────────
        def priority_badge(p):
            c = {"High": "#ef4444", "Medium": "#f59e0b", "Low": "#10b981"}.get(p, "#6c63ff")
            return f'<span class="badge" style="background:{c}22;color:{c};border-color:{c}44">{p}</span>'

        tc_cards_html = ""
        for i, t in enumerate(tc, 1):
            tc_cards_html += f"""
        <div class="tc-card" id="tc-{t['id']}">
          <div class="tc-header">
            <span class="tc-num">TC-{i:02d}</span>
            <span class="tc-title">{t['title']}</span>
            {priority_badge(t['priority'])}
          </div>
          <div class="tc-grid">
            <div class="tc-col">
              <div class="tc-section-label">Preconditions</div>
              <ul class="tc-list">{''.join(f'<li>{p}</li>' for p in t['preconditions'])}</ul>
            </div>
            <div class="tc-col">
              <div class="tc-section-label">Test Steps</div>
              <ol class="tc-list tc-steps">{''.join(f'<li>{s}</li>' for s in t['test_steps'])}</ol>
            </div>
            <div class="tc-col">
              <div class="tc-section-label">Expected Results</div>
              <ul class="tc-list tc-expected">{''.join(f'<li>{r}</li>' for r in t['expected_results'])}</ul>
            </div>
          </div>
          <div class="tc-footer">
            <span class="tc-data-label">Test Data:</span>
            <span class="tc-data-val">{t['test_data']}</span>
          </div>
        </div>"""

        # ── Step cards HTML ──────────────────────────────────────────
        step_cards_html = ""
        for i, step in enumerate(steps, 1):
            has_bug = bool(step.bug_hint and step.bug_hint not in
                           ("No obvious issues", "No obvious issues detected", ""))

            img_html = ""
            if step.image_path and os.path.exists(step.image_path):
                b64 = self._image_to_base64(step.image_path)
                if b64:
                    img_html = f"""
            <div class="step-img-wrap">
              <img src="{b64}" alt="Step {i}" class="step-img" loading="lazy"
                   onclick="openLightbox(this.src, 'Step {i}: {step.description[:50].replace("'", "").replace('"', '')}')">
              <div class="step-img-overlay">🔍 Click to zoom</div>
            </div>"""
            elif step.capture_type == "manual_note":
                img_html = '<div class="note-icon">📝</div>'

            bug_html = ""
            if has_bug:
                bug_html = f"""
            <div class="bug-banner">
              <span class="bug-icon">🐛</span>
              <div>
                <div class="bug-title">Potential Issue Detected</div>
                <div class="bug-body">{step.bug_hint}</div>
              </div>
            </div>"""

            type_icon = {"full_screen": "📷", "snip": "✂", "manual_note": "📝"}.get(step.capture_type, "📸")
            type_label = step.capture_type.replace("_", " ").title()
            step_border = "#ef444466" if has_bug else "#6c63ff44"
            step_glow = "rgba(239,68,68,0.05)" if has_bug else "transparent"

            step_cards_html += f"""
        <div class="step-card" id="step-{i}" style="border-color:{step_border};background:linear-gradient(180deg,{step_glow},transparent 80px)">
          <div class="step-header">
            <div class="step-num-badge">
              <span class="step-num">{i:02d}</span>
            </div>
            <div class="step-meta">
              <span class="step-type-icon">{type_icon}</span>
              <span class="step-type">{type_label}</span>
              <span class="step-time">🕐 {step.timestamp.strftime('%H:%M:%S')}</span>
            </div>
            {f'<span class="bug-pill">⚠ Bug Hint</span>' if has_bug else ''}
          </div>

          <div class="step-body">
            <div class="step-info">
              <div class="info-block">
                <div class="info-label">Description</div>
                <div class="info-val">{step.description or '—'}</div>
              </div>
              <div class="info-row">
                <div class="info-block half">
                  <div class="info-label expected-lbl">Expected</div>
                  <div class="info-val">{step.expected_behavior or '—'}</div>
                </div>
                <div class="info-block half">
                  <div class="info-label actual-lbl">Actual</div>
                  <div class="info-val">{step.actual_observation or '—'}</div>
                </div>
              </div>
              {bug_html}
            </div>
            {img_html}
          </div>
        </div>"""

        # ── TOC sidebar ─────────────────────────────────────────────
        toc_items = "".join(
            f'<a class="toc-link" href="#step-{i}" title="{s.description[:60]}">'
            f'<span class="toc-num">{i}</span></a>'
            for i, s in enumerate(steps, 1)
        )

        # ── Key findings/recommendations ────────────────────────────
        findings_html = "".join(
            f'<li class="finding-item"><span class="finding-dot"></span>{f}</li>'
            for f in summary.get("key_findings", [])
        )
        recs_html = "".join(
            f'<li class="rec-item"><span class="rec-dot">→</span>{r}</li>'
            for r in summary.get("recommendations", [])
        )

        html = f"""<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>QA Report — {session.session_name}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&family=Sora:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
/* ── RESET + VARIABLES ─────────────────────────── */
*,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
:root{{
  --bg0:#04040c;--bg1:#080814;--bg2:#0d0d1f;--bg3:#12122a;--bg4:#1a1a38;
  --border:#1e1e38;--border2:#2a2a5a;
  --txt1:#e8e8ff;--txt2:#8888bb;--txt3:#4a4a77;
  --accent:#6c63ff;--accent2:#a78bfa;--accent3:#38bdf8;
  --green:#10b981;--amber:#f59e0b;--red:#ef4444;--pink:#f472b6;
  --radius:14px;--radius-sm:8px;--radius-xs:5px;
  --shadow:0 0 0 1px var(--border),0 8px 32px rgba(0,0,0,.5);
  --glow:0 0 24px rgba(108,99,255,.15);
  --mono:'JetBrains Mono',monospace;
  --sans:'Sora',system-ui,sans-serif;
  transition:background .3s,color .3s;
}}
[data-theme="light"]{{
  --bg0:#f4f4ff;--bg1:#ffffff;--bg2:#f8f8ff;--bg3:#eeeefc;--bg4:#e4e4f0;
  --border:#ddddf0;--border2:#c8c8e8;
  --txt1:#1a1a2e;--txt2:#555577;--txt3:#9999bb;
  --shadow:0 0 0 1px var(--border),0 4px 20px rgba(0,0,0,.08);
  --glow:0 0 24px rgba(108,99,255,.08);
}}

/* ── BASE ─────────────────────────────────────── */
html{{scroll-behavior:smooth;font-size:15px}}
body{{
  background:var(--bg0);color:var(--txt1);
  font-family:var(--sans);line-height:1.6;
  min-height:100vh;
}}

/* ── LAYOUT ───────────────────────────────────── */
.layout{{display:grid;grid-template-columns:72px 1fr;min-height:100vh}}
.sidebar{{
  position:fixed;top:0;left:0;width:72px;height:100vh;
  background:var(--bg1);border-right:1px solid var(--border);
  display:flex;flex-direction:column;align-items:center;
  padding:20px 0;gap:6px;z-index:100;
  overflow-y:auto;
}}
.sidebar-logo{{
  font-size:22px;margin-bottom:16px;
  width:44px;height:44px;display:flex;align-items:center;justify-content:center;
  background:var(--accent);border-radius:12px;color:#fff;font-weight:700;
}}
.toc-link{{
  width:38px;height:28px;display:flex;align-items:center;justify-content:center;
  border-radius:6px;text-decoration:none;transition:.15s;
}}
.toc-link:hover{{background:var(--bg4)}}
.toc-num{{font-family:var(--mono);font-size:10px;color:var(--txt3)}}
.toc-link:hover .toc-num{{color:var(--accent)}}

.main{{
  grid-column:2;
  min-height:100vh;
}}

/* ── HERO ─────────────────────────────────────── */
.hero{{
  background:var(--bg1);
  border-bottom:1px solid var(--border);
  padding:48px 56px 36px;
  position:relative;overflow:hidden;
}}
.hero::before{{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse 80% 60% at 70% -10%,rgba(108,99,255,.18),transparent 70%);
  pointer-events:none;
}}
.hero-eyebrow{{
  font-family:var(--mono);font-size:11px;
  color:var(--accent);letter-spacing:3px;text-transform:uppercase;
  margin-bottom:12px;
}}
.hero-title{{
  font-size:2.8rem;font-weight:700;line-height:1.1;
  background:linear-gradient(135deg,var(--txt1) 0%,var(--accent2) 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  margin-bottom:10px;
}}
.hero-session{{
  font-family:var(--mono);font-size:14px;color:var(--txt2);
  margin-bottom:24px;
}}
.hero-meta{{display:flex;gap:20px;flex-wrap:wrap;align-items:center}}
.meta-chip{{
  display:inline-flex;align-items:center;gap:7px;
  background:var(--bg3);border:1px solid var(--border2);
  border-radius:50px;padding:5px 14px;font-size:12px;color:var(--txt2);
}}
.status-chip{{
  display:inline-flex;align-items:center;gap:7px;
  border-radius:50px;padding:6px 16px;font-size:13px;font-weight:600;
  background:{status_color}22;color:{status_color};
  border:1px solid {status_color}44;
}}
.theme-toggle{{
  position:absolute;top:24px;right:24px;
  background:var(--bg3);border:1px solid var(--border2);
  border-radius:50px;padding:8px 16px;cursor:pointer;
  font-size:13px;color:var(--txt2);transition:.2s;display:flex;gap:8px;align-items:center;
}}
.theme-toggle:hover{{color:var(--txt1);border-color:var(--accent);}}

/* ── SECTION WRAPPER ─────────────────────────── */
.section{{padding:40px 56px;}}
.section+.section{{border-top:1px solid var(--border);}}
.section-eyebrow{{
  font-family:var(--mono);font-size:10px;letter-spacing:3px;
  text-transform:uppercase;color:var(--txt3);margin-bottom:8px;
}}
.section-title{{
  font-size:1.4rem;font-weight:700;color:var(--txt1);margin-bottom:28px;
  display:flex;align-items:center;gap:10px;
}}
.section-title::after{{
  content:'';flex:1;height:1px;background:var(--border);
}}

/* ── STATS GRID ─────────────────────────────── */
.stats-grid{{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
  gap:16px;margin-bottom:32px;
}}
.stat-card{{
  background:var(--bg2);border:1px solid var(--border);
  border-radius:var(--radius);padding:20px;
  display:flex;align-items:center;gap:16px;
  transition:transform .2s,box-shadow .2s;
}}
.stat-card:hover{{transform:translateY(-2px);box-shadow:var(--glow)}}
.stat-icon{{
  width:44px;height:44px;border-radius:12px;
  display:flex;align-items:center;justify-content:center;
  font-size:20px;flex-shrink:0;
}}
.stat-value{{font-size:1.6rem;font-weight:700;line-height:1}}
.stat-label{{font-size:12px;color:var(--txt2);margin-top:4px}}

/* ── EXECUTIVE SUMMARY ──────────────────────── */
.exec-grid{{display:grid;grid-template-columns:1fr 1fr;gap:24px;}}
.exec-block{{
  background:var(--bg2);border:1px solid var(--border);
  border-radius:var(--radius);padding:24px;
}}
.exec-block-title{{
  font-size:11px;font-weight:600;color:var(--txt3);
  letter-spacing:2px;text-transform:uppercase;margin-bottom:14px;
}}
.exec-summary{{
  font-size:14px;line-height:1.7;color:var(--txt2);
}}
.finding-item{{
  display:flex;align-items:flex-start;gap:10px;
  padding:8px 0;border-bottom:1px solid var(--border);
  font-size:13px;color:var(--txt2);
}}
.finding-item:last-child{{border-bottom:none}}
.finding-dot{{
  width:6px;height:6px;border-radius:50%;
  background:var(--accent);flex-shrink:0;margin-top:7px;
}}
.rec-item{{
  display:flex;align-items:flex-start;gap:10px;
  padding:8px 0;font-size:13px;color:var(--txt2);
}}
.rec-dot{{
  color:var(--green);font-family:var(--mono);font-size:14px;flex-shrink:0;
}}
.risk-band{{
  display:flex;align-items:center;gap:12px;
  background:var(--amber)11;border:1px solid var(--amber)44;
  border-radius:var(--radius-sm);padding:14px 20px;margin-top:16px;
  font-size:13px;color:var(--amber);
}}

/* ── TEST CASE CARDS ────────────────────────── */
.tc-card{{
  background:var(--bg2);border:1px solid var(--border);
  border-radius:var(--radius);margin-bottom:16px;
  overflow:hidden;transition:.2s;
}}
.tc-card:hover{{border-color:var(--border2);box-shadow:var(--shadow)}}
.tc-header{{
  display:flex;align-items:center;gap:12px;
  padding:16px 20px;background:var(--bg3);
  border-bottom:1px solid var(--border);flex-wrap:wrap;
}}
.tc-num{{
  font-family:var(--mono);font-size:11px;
  background:var(--accent)22;color:var(--accent);
  border:1px solid var(--accent)44;border-radius:6px;
  padding:3px 9px;
}}
.tc-title{{font-weight:600;font-size:14px;flex:1}}
.badge{{
  font-size:11px;font-weight:600;border-radius:50px;
  padding:3px 10px;border:1px solid;
}}
.tc-grid{{
  display:grid;grid-template-columns:1fr 1fr 1fr;
  gap:0;
}}
.tc-col{{
  padding:18px 20px;border-right:1px solid var(--border);
}}
.tc-col:last-child{{border-right:none}}
.tc-section-label{{
  font-size:10px;font-weight:600;color:var(--txt3);
  letter-spacing:2px;text-transform:uppercase;margin-bottom:10px;
}}
.tc-list{{padding-left:18px;}}
.tc-list li{{font-size:12.5px;color:var(--txt2);padding:3px 0;line-height:1.5}}
.tc-steps li{{color:var(--txt1)}}
.tc-expected li::marker{{color:var(--green)}}
.tc-footer{{
  padding:12px 20px;background:var(--bg3);
  border-top:1px solid var(--border);
  font-size:12px;color:var(--txt2);display:flex;gap:8px;
}}
.tc-data-label{{color:var(--txt3);font-weight:600;text-transform:uppercase;font-size:10px;letter-spacing:1px;line-height:2}}
.tc-data-val{{color:var(--txt2)}}

/* ── STEP CARDS ─────────────────────────────── */
.steps-list{{display:flex;flex-direction:column;gap:20px;}}
.step-card{{
  background:var(--bg1);border:1px solid var(--border);
  border-radius:var(--radius);overflow:hidden;
  transition:.2s;
}}
.step-card:hover{{border-color:var(--border2);box-shadow:var(--shadow)}}
.step-header{{
  display:flex;align-items:center;gap:12px;
  padding:14px 20px;background:var(--bg2);
  border-bottom:1px solid var(--border);flex-wrap:wrap;
}}
.step-num-badge{{
  width:36px;height:36px;border-radius:10px;
  background:var(--accent)22;border:1px solid var(--accent)44;
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
}}
.step-num{{
  font-family:var(--mono);font-size:13px;
  font-weight:700;color:var(--accent);
}}
.step-meta{{
  display:flex;align-items:center;gap:10px;flex:1;flex-wrap:wrap;
}}
.step-type-icon{{font-size:14px;}}
.step-type{{
  font-size:12px;color:var(--txt2);
  font-family:var(--mono);text-transform:uppercase;letter-spacing:1px;
}}
.step-time{{font-family:var(--mono);font-size:11px;color:var(--txt3)}}
.bug-pill{{
  font-size:11px;font-weight:600;
  background:var(--amber)22;color:var(--amber);
  border:1px solid var(--amber)44;border-radius:50px;padding:3px 10px;
}}

.step-body{{
  display:grid;grid-template-columns:1fr auto;
  gap:0;
}}
.step-info{{padding:20px;}}
.info-block{{margin-bottom:16px;}}
.info-block:last-child{{margin-bottom:0;}}
.info-row{{display:grid;grid-template-columns:1fr 1fr;gap:16px;}}
.info-label{{
  font-size:10px;font-weight:600;letter-spacing:2px;text-transform:uppercase;
  color:var(--txt3);margin-bottom:6px;
}}
.expected-lbl{{color:var(--green)!important;opacity:.7}}
.actual-lbl{{color:var(--accent3)!important;opacity:.7}}
.info-val{{font-size:13px;color:var(--txt2);line-height:1.6;}}
.bug-banner{{
  display:flex;align-items:flex-start;gap:12px;
  background:var(--amber)11;border:1px solid var(--amber)33;
  border-radius:var(--radius-sm);padding:14px 16px;margin-top:12px;
}}
.bug-icon{{font-size:18px;flex-shrink:0}}
.bug-title{{font-size:12px;font-weight:600;color:var(--amber);margin-bottom:4px}}
.bug-body{{font-size:13px;color:var(--txt2);line-height:1.5}}
.note-icon{{
  padding:32px;font-size:48px;
  display:flex;align-items:center;justify-content:center;
  border-left:1px solid var(--border);
  color:var(--txt3);
}}

/* ── STEP IMAGE ─────────────────────────────── */
.step-img-wrap{{
  position:relative;cursor:pointer;border-left:1px solid var(--border);
  min-width:280px;max-width:380px;overflow:hidden;
  display:flex;align-items:center;justify-content:center;
  background:var(--bg0);
}}
.step-img{{
  width:100%;height:100%;object-fit:contain;
  display:block;transition:transform .3s;
  max-height:320px;
}}
.step-img-wrap:hover .step-img{{transform:scale(1.03);}}
.step-img-overlay{{
  position:absolute;bottom:0;left:0;right:0;
  background:linear-gradient(0deg,rgba(0,0,0,.7),transparent);
  color:white;font-size:11px;text-align:center;padding:20px 8px 8px;
  opacity:0;transition:opacity .2s;
}}
.step-img-wrap:hover .step-img-overlay{{opacity:1;}}

/* ── LIGHTBOX ───────────────────────────────── */
.lightbox{{
  display:none;position:fixed;inset:0;z-index:9999;
  background:rgba(0,0,0,.92);
  align-items:center;justify-content:center;flex-direction:column;gap:12px;
}}
.lightbox.open{{display:flex;}}
.lightbox-img{{
  max-width:90vw;max-height:85vh;border-radius:var(--radius);
  box-shadow:0 0 80px rgba(0,0,0,.8);
}}
.lightbox-caption{{
  font-family:var(--mono);font-size:12px;color:rgba(255,255,255,.5);
}}
.lightbox-close{{
  position:absolute;top:20px;right:24px;
  background:rgba(255,255,255,.1);border:none;color:white;
  font-size:24px;cursor:pointer;border-radius:8px;
  width:44px;height:44px;
  display:flex;align-items:center;justify-content:center;
  transition:.2s;
}}
.lightbox-close:hover{{background:rgba(255,255,255,.2);}}

/* ── FOOTER ─────────────────────────────────── */
.footer{{
  background:var(--bg1);border-top:1px solid var(--border);
  padding:32px 56px;
  display:grid;grid-template-columns:1fr auto;gap:24px;align-items:center;
}}
.footer-brand{{
  font-size:13px;color:var(--txt3);line-height:1.8;
}}
.footer-brand strong{{color:var(--txt2)}}
.footer-tag{{
  font-family:var(--mono);font-size:11px;
  background:var(--accent)11;color:var(--accent);
  border:1px solid var(--accent)33;border-radius:50px;
  padding:6px 16px;
}}

/* ── PRINT ───────────────────────────────────── */
@media print{{
  .sidebar,.theme-toggle,.lightbox{{display:none!important}}
  .layout{{display:block}}
  .main{{padding-left:0}}
  .step-img-wrap{{max-width:240px}}
  .tc-grid{{grid-template-columns:1fr}}
  .tc-col{{border-right:none;border-bottom:1px solid var(--border)}}
  body{{background:white;color:black}}
  .step-card,.tc-card{{break-inside:avoid}}
}}

/* ── RESPONSIVE ─────────────────────────────── */
@media(max-width:900px){{
  .layout{{grid-template-columns:1fr}}
  .sidebar{{display:none}}
  .section{{padding:28px 20px}}
  .hero{{padding:32px 20px}}
  .hero-title{{font-size:1.8rem}}
  .tc-grid{{grid-template-columns:1fr}}
  .tc-col{{border-right:none;border-bottom:1px solid var(--border)}}
  .exec-grid{{grid-template-columns:1fr}}
  .step-body{{grid-template-columns:1fr}}
  .step-img-wrap{{border-left:none;border-top:1px solid var(--border);max-width:100%}}
  .info-row{{grid-template-columns:1fr}}
  .footer{{grid-template-columns:1fr}}
}}

/* ── ANIMATIONS ─────────────────────────────── */
@keyframes fadeUp{{from{{opacity:0;transform:translateY(16px)}}to{{opacity:1;transform:none}}}}
.step-card,.tc-card,.stat-card{{animation:fadeUp .4s ease both}}
.step-card:nth-child(n){{animation-delay:calc(n * 0.03s)}}
</style>
</head>
<body>

<!-- LIGHTBOX -->
<div class="lightbox" id="lightbox" onclick="closeLightbox()">
  <button class="lightbox-close" onclick="closeLightbox()">✕</button>
  <img src="" alt="" class="lightbox-img" id="lightboxImg" onclick="event.stopPropagation()">
  <div class="lightbox-caption" id="lightboxCaption"></div>
</div>

<div class="layout">

<!-- SIDEBAR / TOC -->
<nav class="sidebar" aria-label="Step navigation">
  <div class="sidebar-logo">QA</div>
  {toc_items}
</nav>

<!-- MAIN CONTENT -->
<main class="main">

  <!-- HERO -->
  <header class="hero">
    <button class="theme-toggle" onclick="toggleTheme()" id="themeBtn">
      🌙 Dark mode
    </button>
    <div class="hero-eyebrow">AI-Powered QA Documentation Report</div>
    <h1 class="hero-title">Test Report</h1>
    <div class="hero-session">📁 {session.session_name}</div>
    <div class="hero-meta">
      <span class="meta-chip">📅 {session.start_time.strftime('%d %b %Y')}</span>
      <span class="meta-chip">⏱ {session.start_time.strftime('%H:%M')}</span>
      <span class="meta-chip">📸 {len(steps)} steps</span>
      <span class="meta-chip">📂 {len(tc)} test cases</span>
      <span class="status-chip">● {status}</span>
      <span class="meta-chip" style="margin-left:auto;font-family:var(--mono);font-size:11px">
        Generated {gen_time}
      </span>
    </div>
  </header>

  <!-- STATS -->
  <section class="section">
    <div class="section-eyebrow">Overview</div>
    <div class="section-title">Session Statistics</div>
    <div class="stats-grid">
      {stats_html}
    </div>
  </section>

  <!-- EXECUTIVE SUMMARY -->
  <section class="section">
    <div class="section-eyebrow">Analysis</div>
    <div class="section-title">Executive Summary</div>
    <div class="exec-grid">
      <div class="exec-block" style="grid-column:1/-1">
        <div class="exec-block-title">Summary</div>
        <div class="exec-summary">{summary.get('summary','N/A')}</div>
        <div class="risk-band">
          <span>⚡</span>
          <span>{summary.get('risk_assessment','N/A')}</span>
        </div>
      </div>
      <div class="exec-block">
        <div class="exec-block-title">Key Findings</div>
        <ul style="list-style:none">{findings_html}</ul>
      </div>
      <div class="exec-block">
        <div class="exec-block-title">Recommendations</div>
        <ul style="list-style:none">{recs_html}</ul>
      </div>
    </div>
  </section>

  <!-- TEST CASES -->
  <section class="section">
    <div class="section-eyebrow">Test Plan</div>
    <div class="section-title">Generated Test Cases
      <span style="font-size:13px;font-weight:400;color:var(--txt2);letter-spacing:0">{len(tc)} cases</span>
    </div>
    {tc_cards_html}
  </section>

  <!-- STEPS -->
  <section class="section">
    <div class="section-eyebrow">Evidence</div>
    <div class="section-title">Test Execution Steps
      <span style="font-size:13px;font-weight:400;color:var(--txt2);letter-spacing:0">{len(steps)} steps</span>
    </div>
    <div class="steps-list">
      {step_cards_html}
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="footer">
    <div class="footer-brand">
      <strong>AI QA Documentation Assistant v3.0</strong><br>
      Report includes AI-generated test cases, executive analysis, and embedded screenshots.<br>
      Images embedded as Base64 — this file is fully self-contained.
    </div>
    <div class="footer-tag">AI-Enhanced Report</div>
  </footer>

</main>
</div>

<script>
function toggleTheme(){{
  var html=document.documentElement;
  var dark=html.getAttribute('data-theme')==='dark';
  html.setAttribute('data-theme',dark?'light':'dark');
  document.getElementById('themeBtn').textContent=dark?'🌙 Dark mode':'☀ Light mode';
}}
function openLightbox(src,caption){{
  document.getElementById('lightboxImg').src=src;
  document.getElementById('lightboxCaption').textContent=caption||'';
  document.getElementById('lightbox').classList.add('open');
  document.body.style.overflow='hidden';
}}
function closeLightbox(){{
  document.getElementById('lightbox').classList.remove('open');
  document.body.style.overflow='';
}}
document.addEventListener('keydown',function(e){{
  if(e.key==='Escape')closeLightbox();
}});
// Staggered animation
document.querySelectorAll('.step-card,.tc-card,.stat-card').forEach(function(el,i){{
  el.style.animationDelay=(i*0.04)+'s';
}});
// Update theme button on load
(function(){{
  document.getElementById('themeBtn').textContent='☀ Light mode';
}})();
</script>
</body>
</html>"""

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅  HTML report saved ({len(steps)} steps, {len(tc)} test cases)")

    # ─────────────────────────────────────────────────────────────────────────
    # ADVANCED PDF
    # ─────────────────────────────────────────────────────────────────────────

    def _export_pdf(self, session, filepath: str):
        doc  = SimpleDocTemplate(filepath, pagesize=A4,
                                  leftMargin=0.75*inch, rightMargin=0.75*inch,
                                  topMargin=0.8*inch, bottomMargin=0.8*inch)
        styles = getSampleStyleSheet()
        story  = []

        # Custom styles
        title_s = ParagraphStyle("T", parent=styles["Title"],
                                  fontSize=26, textColor=colors.HexColor("#6c63ff"),
                                  spaceAfter=6, leading=30)
        h1_s = ParagraphStyle("H1", parent=styles["h1"],
                               fontSize=18, textColor=colors.HexColor("#e8e8ff"),
                               backColor=colors.HexColor("#0d0d1f"),
                               spaceAfter=12, spaceBefore=20)
        h2_s = ParagraphStyle("H2", parent=styles["h2"],
                               fontSize=14, textColor=colors.HexColor("#a78bfa"),
                               spaceAfter=8, spaceBefore=14)
        body_s = ParagraphStyle("B", parent=styles["Normal"],
                                 fontSize=10, textColor=colors.HexColor("#c8c8ee"),
                                 spaceAfter=6, leading=15)
        label_s = ParagraphStyle("LB", parent=styles["Normal"],
                                  fontSize=8, textColor=colors.HexColor("#555577"),
                                  spaceBefore=6, spaceAfter=2,
                                  fontName="Helvetica-Bold")

        def divider():
            story.append(HRFlowable(width="100%", thickness=1,
                                     color=colors.HexColor("#1e1e38"), spaceAfter=12))

        # Title page
        story.append(Paragraph("AI-Powered QA Report", title_s))
        story.append(Paragraph(f"<b>{session.session_name}</b>", h2_s))
        divider()

        summary = session.summary
        story.append(Paragraph("Executive Summary", h1_s))
        status_color_hex = {"Pass": "#10b981", "Fail": "#ef4444",
                            "Needs Review": "#f59e0b"}.get(summary.get("overall_status",""), "#6c63ff")
        story.append(Paragraph(
            f"<b>Status:</b> <font color='{status_color_hex}'>{summary.get('overall_status','N/A')}</font>  "
            f"  <b>Steps:</b> {len(session.steps)}  "
            f"  <b>Test Cases:</b> {len(session.test_cases)}", body_s))
        story.append(Paragraph(summary.get("summary", ""), body_s))
        story.append(Paragraph(f"<b>Risk:</b> {summary.get('risk_assessment','')}", body_s))

        story.append(Paragraph("Key Findings:", label_s))
        for f in summary.get("key_findings", []):
            story.append(Paragraph(f"• {f}", body_s))

        story.append(PageBreak())
        story.append(Paragraph("Generated Test Cases", h1_s))
        divider()

        for tc in session.test_cases:
            story.append(Paragraph(f"{tc['id']}: {tc['title']}", h2_s))
            story.append(Paragraph(f"<b>Priority:</b> {tc['priority']}", body_s))

            # Steps table
            data = [["#", "Test Step", "Expected Result"]]
            for i, (s, r) in enumerate(zip(tc["test_steps"], tc["expected_results"]), 1):
                data.append([str(i), Paragraph(s, body_s), Paragraph(r, body_s)])

            tbl = Table(data, colWidths=[0.3*inch, 3.2*inch, 3.2*inch])
            tbl.setStyle(TableStyle([
                ("BACKGROUND",  (0,0), (-1,0), colors.HexColor("#12122a")),
                ("TEXTCOLOR",   (0,0), (-1,0), colors.HexColor("#a78bfa")),
                ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
                ("FONTSIZE",    (0,0), (-1,0), 9),
                ("ROWBACKGROUNDS", (0,1), (-1,-1),
                 [colors.HexColor("#080814"), colors.HexColor("#0d0d1f")]),
                ("TEXTCOLOR",   (0,1), (-1,-1), colors.HexColor("#c8c8ee")),
                ("FONTSIZE",    (0,1), (-1,-1), 9),
                ("GRID",        (0,0), (-1,-1), 0.5, colors.HexColor("#1e1e38")),
                ("VALIGN",      (0,0), (-1,-1), "TOP"),
                ("TOPPADDING",  (0,0), (-1,-1), 6),
                ("BOTTOMPADDING",(0,0),(-1,-1), 6),
            ]))
            story.append(tbl)
            story.append(Spacer(1, 12))

        story.append(PageBreak())
        story.append(Paragraph("Test Execution Steps", h1_s))
        divider()

        for i, step in enumerate(session.steps, 1):
            story.append(Paragraph(
                f"Step {i:02d} — {step.capture_type.replace('_',' ').title()}", h2_s))
            story.append(Paragraph(f"<b>Time:</b> {step.timestamp.strftime('%H:%M:%S')}", label_s))

            for lbl, val in [("Description", step.description),
                              ("Expected", step.expected_behavior),
                              ("Actual",   step.actual_observation)]:
                if val:
                    story.append(Paragraph(lbl, label_s))
                    story.append(Paragraph(val or "—", body_s))

            if (step.bug_hint and step.bug_hint not in
                    ("No obvious issues", "No obvious issues detected", "")):
                story.append(Paragraph("⚠ Bug Hint", label_s))
                story.append(Paragraph(step.bug_hint, body_s))

            if step.image_path and os.path.exists(step.image_path):
                try:
                    story.append(Image(step.image_path, width=5.5*inch,
                                       height=3.5*inch, kind="proportional"))
                except Exception:
                    pass
            story.append(Spacer(1, 18))

        doc.build(story)

    # ─────────────────────────────────────────────────────────────────────────
    # ADVANCED EXCEL
    # ─────────────────────────────────────────────────────────────────────────

    def _export_excel(self, session, filepath: str):
        wb = Workbook()

        BG_DEEP  = "04040C"
        BG_CARD  = "0D0D1F"
        BG_HDR   = "12122A"
        ACCENT   = "6C63FF"
        AMBER    = "F59E0B"
        GREEN    = "10B981"
        RED      = "EF4444"
        TEXT1    = "E8E8FF"
        TEXT2    = "8888BB"

        def hdr_style(cell):
            cell.font = Font(bold=True, color=TEXT1, size=10, name="Segoe UI")
            cell.fill = PatternFill("solid", fgColor=BG_HDR)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        def val_style(cell, color=TEXT2, bold=False, wrap=True, align="left"):
            cell.font = Font(color=color, size=10, bold=bold, name="Segoe UI")
            cell.fill = PatternFill("solid", fgColor=BG_CARD)
            cell.alignment = Alignment(horizontal=align, vertical="top",
                                        wrap_text=wrap)

        def thin_border():
            side = Side(border_style="thin", color="1E1E38")
            return Border(left=side, right=side, top=side, bottom=side)

        # ── Sheet 1: Summary ─────────────────────────────────────────
        ws1 = wb.active
        ws1.title = "📊 Summary"
        ws1.sheet_view.showGridLines = False
        ws1.column_dimensions["A"].width = 26
        ws1.column_dimensions["B"].width = 52

        summary_rows = [
            ("Session Name",    session.session_name,          ACCENT),
            ("Date",            session.start_time.strftime("%d %B %Y %H:%M"), TEXT2),
            ("Total Steps",     str(len(session.steps)),       ACCENT),
            ("Test Cases",      str(len(session.test_cases)),  "38BDF8"),
            ("Issues Found",    str(len([s for s in session.steps if s.bug_hint and
                                         "No obvious" not in (s.bug_hint or "")])), AMBER),
            ("Overall Status",  session.summary.get("overall_status","N/A"), GREEN),
            ("Risk",            session.summary.get("risk_assessment","N/A"), TEXT2),
            ("",                "",                            TEXT2),
            ("Executive Summary", session.summary.get("summary",""), TEXT2),
            ("",                "",                            TEXT2),
        ]
        for i, (label, value, color) in enumerate(summary_rows, 2):
            ws1[f"A{i}"] = label
            ws1[f"B{i}"] = value
            ws1[f"A{i}"].font = Font(color="555577", size=9, bold=True, name="Segoe UI")
            ws1[f"A{i}"].fill = PatternFill("solid", fgColor=BG_HDR)
            ws1[f"B{i}"].font = Font(color=color,   size=10, name="Segoe UI")
            ws1[f"B{i}"].fill = PatternFill("solid", fgColor=BG_CARD)
            ws1[f"B{i}"].alignment = Alignment(wrap_text=True, vertical="top")
            ws1.row_dimensions[i].height = 22

        # Key findings block
        row = 2 + len(summary_rows)
        ws1.cell(row, 1, "Key Findings").font = Font(color="555577", size=9, bold=True)
        ws1.cell(row, 1).fill = PatternFill("solid", fgColor=BG_HDR)
        for f in session.summary.get("key_findings", []):
            row += 1
            ws1.cell(row, 2, f"• {f}").font = Font(color=TEXT2, size=10, name="Segoe UI")
            ws1.cell(row, 2).fill = PatternFill("solid", fgColor=BG_CARD)

        # ── Sheet 2: Test Cases ───────────────────────────────────────
        ws2 = wb.create_sheet("📋 Test Cases")
        ws2.sheet_view.showGridLines = False
        headers = ["ID", "Title", "Priority", "Preconditions", "Test Steps", "Expected Results", "Test Data"]
        col_widths = [10, 36, 12, 36, 44, 44, 30]
        for ci, (h, w) in enumerate(zip(headers, col_widths), 1):
            cell = ws2.cell(1, ci, h)
            hdr_style(cell)
            ws2.column_dimensions[get_column_letter(ci)].width = w

        ws2.row_dimensions[1].height = 26
        priority_colors = {"High": RED, "Medium": AMBER, "Low": GREEN}

        for ri, tc in enumerate(session.test_cases, 2):
            row_data = [
                tc["id"], tc["title"], tc["priority"],
                "\n".join(tc["preconditions"]),
                "\n".join(tc["test_steps"]),
                "\n".join(tc["expected_results"]),
                tc["test_data"]
            ]
            for ci, val in enumerate(row_data, 1):
                cell = ws2.cell(ri, ci, val)
                color = priority_colors.get(tc["priority"], TEXT2) if ci == 3 else TEXT2
                val_style(cell, color=color, bold=(ci==3))
            ws2.row_dimensions[ri].height = max(40, min(len(tc["test_steps"]) * 14, 100))

        # ── Sheet 3: Test Steps ──────────────────────────────────────
        ws3 = wb.create_sheet("📸 Test Steps")
        ws3.sheet_view.showGridLines = False
        step_headers = ["#", "Type", "Time", "Description", "Expected", "Actual", "Bug Hint"]
        step_widths  = [6,  18,   12,    50,            40,         40,         44]
        for ci, (h, w) in enumerate(zip(step_headers, step_widths), 1):
            cell = ws3.cell(1, ci, h)
            hdr_style(cell)
            ws3.column_dimensions[get_column_letter(ci)].width = w
        ws3.row_dimensions[1].height = 26

        for ri, step in enumerate(session.steps, 2):
            has_bug = bool(step.bug_hint and step.bug_hint not in
                           ("No obvious issues", "No obvious issues detected", ""))
            row_data = [
                ri - 1,
                step.capture_type.replace("_", " ").title(),
                step.timestamp.strftime("%H:%M:%S"),
                step.description or "",
                step.expected_behavior or "",
                step.actual_observation or "",
                step.bug_hint if has_bug else ""
            ]
            for ci, val in enumerate(row_data, 1):
                cell = ws3.cell(ri, ci, val)
                color = AMBER if (has_bug and ci == 7) else TEXT2
                val_style(cell, color=color, bold=(ci==1), align=("center" if ci <= 3 else "left"))
            if has_bug:
                for ci in range(1, 8):
                    ws3.cell(ri, ci).fill = PatternFill("solid", fgColor="1a1500")
            ws3.row_dimensions[ri].height = 20

        # ── Sheet 4: Bug Report ───────────────────────────────────────
        ws4 = wb.create_sheet("🐛 Bug Report")
        ws4.sheet_view.showGridLines = False
        bug_headers = ["Step #", "Description", "Bug / Issue", "Severity"]
        bug_widths  = [10, 52, 52, 16]
        for ci, (h, w) in enumerate(zip(bug_headers, bug_widths), 1):
            cell = ws4.cell(1, ci, h)
            cell.font = Font(bold=True, color=TEXT1, size=10)
            cell.fill = PatternFill("solid", fgColor="2a0a0a")
            cell.alignment = Alignment(horizontal="center")
            ws4.column_dimensions[get_column_letter(ci)].width = w

        bug_steps = [(i+1, s) for i, s in enumerate(session.steps)
                     if s.bug_hint and s.bug_hint not in
                     ("No obvious issues", "No obvious issues detected", "")]
        if not bug_steps:
            ws4.cell(2, 1, "✅ No bugs found in this session").font = Font(color=GREEN, size=12)
        else:
            for ri, (num, step) in enumerate(bug_steps, 2):
                ws4.cell(ri, 1, num).font = Font(color=AMBER, bold=True, size=10)
                ws4.cell(ri, 2, step.description).font = Font(color=TEXT2, size=10)
                ws4.cell(ri, 3, step.bug_hint).font = Font(color=AMBER, size=10)
                ws4.cell(ri, 4, "High").font = Font(color=RED, bold=True, size=10)
                for ci in range(1, 5):
                    ws4.cell(ri, ci).fill = PatternFill("solid", fgColor="140800")
                    ws4.cell(ri, ci).alignment = Alignment(wrap_text=True, vertical="top")
                ws4.row_dimensions[ri].height = 28

        # Apply borders to all sheets
        for ws in [ws1, ws2, ws3, ws4]:
            ws.sheet_properties.tabColor = ACCENT
            for row in ws.iter_rows():
                for cell in row:
                    if cell.value is not None or cell.fill.fgColor.rgb not in ("00000000", "FFFFFFFF"):
                        cell.border = thin_border()

        wb.save(filepath)
        print(f"✅ Excel saved: 4 sheets, {len(session.steps)} steps")

    # ─────────────────────────────────────────────────────────────────────────
    # ADVANCED WORD
    # ─────────────────────────────────────────────────────────────────────────

    def _export_word(self, session, filepath: str):
        doc = Document()

        # Title
        title = doc.add_heading("AI-Powered QA Documentation Report", 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER

        doc.add_heading(f"Session: {session.session_name}", 1)
        doc.add_paragraph(f"Date: {session.start_time.strftime('%d %B %Y %H:%M')}")
        doc.add_paragraph(f"Total Steps: {len(session.steps)}")
        doc.add_paragraph(f"Test Cases: {len(session.test_cases)}")
        doc.add_paragraph()

        # Executive Summary
        doc.add_heading("Executive Summary", 2)
        s = session.summary
        doc.add_paragraph(f"Status: {s.get('overall_status','N/A')}")
        doc.add_paragraph(f"Summary: {s.get('summary','N/A')}")
        doc.add_paragraph(f"Risk: {s.get('risk_assessment','N/A')}")

        doc.add_heading("Key Findings:", 3)
        for f in s.get("key_findings", []):
            doc.add_paragraph(f"• {f}", style="List Bullet")

        doc.add_heading("Recommendations:", 3)
        for r in s.get("recommendations", []):
            doc.add_paragraph(f"• {r}", style="List Bullet")

        doc.add_page_break()

        # Test Cases
        doc.add_heading("Generated Test Cases", 1)
        for tc in session.test_cases:
            doc.add_heading(f"{tc['id']}: {tc['title']}", 2)
            doc.add_paragraph(f"Priority: {tc['priority']}")

            doc.add_heading("Preconditions:", 3)
            for p in tc["preconditions"]:
                doc.add_paragraph(f"• {p}", style="List Bullet")

            doc.add_heading("Test Steps:", 3)
            for step in tc["test_steps"]:
                doc.add_paragraph(step, style="List Number")

            doc.add_heading("Expected Results:", 3)
            for r in tc["expected_results"]:
                doc.add_paragraph(f"• {r}", style="List Bullet")

            doc.add_paragraph(f"Test Data: {tc['test_data']}")
            doc.add_paragraph()

        doc.add_page_break()

        # Steps
        doc.add_heading("Test Execution Steps", 1)
        for i, step in enumerate(session.steps, 1):
            doc.add_heading(f"Step {i:02d}: {step.capture_type.replace('_',' ').title()}", 2)
            doc.add_paragraph(f"Time: {step.timestamp.strftime('%H:%M:%S')}")

            for lbl, val in [("Description", step.description),
                              ("Expected",    step.expected_behavior),
                              ("Actual",      step.actual_observation)]:
                p = doc.add_paragraph()
                p.add_run(f"{lbl}: ").bold = True
                p.add_run(val or "—")

            if (step.bug_hint and step.bug_hint not in
                    ("No obvious issues", "No obvious issues detected", "")):
                p = doc.add_paragraph()
                r = p.add_run("⚠ Bug Hint: ")
                r.bold = True
                p.add_run(step.bug_hint)

            if step.image_path and os.path.exists(step.image_path):
                try:
                    doc.add_picture(step.image_path, width=Inches(5))
                except Exception:
                    doc.add_paragraph("[Screenshot could not be embedded]")
            doc.add_page_break()

        doc.save(filepath)

    # ─────────────────────────────────────────────────────────────────────────
    # MARKDOWN
    # ─────────────────────────────────────────────────────────────────────────

    def _export_markdown(self, session, filepath: str):
        s = session.summary
        lines = [
            f"# AI-Powered QA Report — {session.session_name}",
            "",
            f"> **Status:** {s.get('overall_status','N/A')}  |  "
            f"**Steps:** {len(session.steps)}  |  "
            f"**Test Cases:** {len(session.test_cases)}  |  "
            f"**Generated:** {datetime.now().strftime('%d %b %Y %H:%M')}",
            "",
            "---",
            "",
            "## Executive Summary",
            "",
            s.get("summary", ""),
            "",
            f"**Risk Assessment:** {s.get('risk_assessment','')}",
            "",
            "### Key Findings",
            *[f"- {f}" for f in s.get("key_findings", [])],
            "",
            "### Recommendations",
            *[f"- {r}" for r in s.get("recommendations", [])],
            "",
            "---",
            "",
            "## Generated Test Cases",
            "",
        ]

        for tc in session.test_cases:
            lines += [
                f"### {tc['id']}: {tc['title']}",
                f"**Priority:** `{tc['priority']}`",
                "",
                "**Preconditions:**",
                *[f"- {p}" for p in tc["preconditions"]],
                "",
                "**Test Steps:**",
                *[f"{i}. {stp}" for i, stp in enumerate(tc["test_steps"], 1)],
                "",
                "**Expected Results:**",
                *[f"- {r}" for r in tc["expected_results"]],
                "",
                f"**Test Data:** {tc['test_data']}",
                "",
                "---",
                "",
            ]

        lines += ["## Test Execution Steps", ""]

        for i, step in enumerate(session.steps, 1):
            has_bug = bool(step.bug_hint and step.bug_hint not in
                           ("No obvious issues", "No obvious issues detected", ""))
            icon = {"full_screen": "📷", "snip": "✂", "manual_note": "📝"}.get(step.capture_type, "📸")
            lines += [
                f"### Step {i:02d} {icon} — {step.capture_type.replace('_',' ').title()}",
                f"`{step.timestamp.strftime('%H:%M:%S')}`",
                "",
                f"**Description:** {step.description or '—'}",
                "",
                f"**Expected:** {step.expected_behavior or '—'}",
                "",
                f"**Actual:** {step.actual_observation or '—'}",
                "",
            ]
            if has_bug:
                lines += [f"> ⚠ **Bug Hint:** {step.bug_hint}", ""]
            if step.image_path and os.path.exists(step.image_path):
                lines += [f"![Step {i}]({step.image_path})", ""]
            lines += ["---", ""]

        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        print(f"✅ Markdown saved: {len(session.steps)} steps")