# Authentication & Backend — Developer Guide (v4.0)

**End users never see any of this.** There is no Firebase/URL/token UI anywhere in
the app. All backend wiring lives in code you control and ship.

## 1. One-time developer setup

Edit **`app_backend.py`** (the only place backend config lives):
```python
FIREBASE_API_KEY = "AIza..."        # Firebase → Project settings → Web API Key
FIREBASE_DB_URL  = "https://<project>-default-rtdb.firebaseio.com"
ALLOW_OFFLINE_DEV = False           # set False for production (forces login)
```
In the Firebase console: **Authentication → Sign-in method → Email/Password →
Enable**, then create user accounts (or let the future admin portal create them).

While `FIREBASE_API_KEY`/`FIREBASE_DB_URL` are blank **and** `ALLOW_OFFLINE_DEV`
is `True`, the app runs without login so you can develop. In a real build, fill
both and set `ALLOW_OFFLINE_DEV = False` → login is then mandatory.

## 2. Login flow
Launch → silent session restore (refresh token) → if none, the **Login** modal
(email + password, show/hide, Remember me, Forgot password) → main app. Passwords
are never stored; only the Firebase refresh token is persisted (when Remember me
is on) in `.qa_session`. Logout is in the header (⎋) and Help → About.

## 3. Broadcasts → in-app modals (admin writes, tool reads)
`/broadcasts/<pushId>`:
```json
{ "type": "announcement" | "feature" | "update" | "notification",
  "title": "...", "body": "...",
  "version": "v4.1.0",          // shown on announcement/update
  "level": "info|success|warning|error",   // used for 'notification' toasts
  "ts": 1717000000, "active": true }
```
- **announcement** → center modal with **Acknowledge** → "Thank you".
- **feature** → modal with **Try It / Close** (tracks viewed/opened/dismissed).
- **update** → modal with **Update Now / Later** + release notes.
- **notification** → toast only.
Each broadcast is acted on once per install (seen-ids tracked locally).

## 4. What the tool writes back (admin reads), all bound to the signed-in user
```
/installs/<id>          {uid, email, os, app_version, first_seen, last_seen,
                         counters:{logins, sessions, screenshots, ai_analyses,
                                   exports, docx_exports, pdf_exports}}
/events/<pushId>        {uid, email, install_id, name, props, ts}
                        names: session_start, screenshot_capture, ai_analysis,
                               export, update_now, feature_viewed/opened/dismissed, error
/acknowledgements/<id>  {uid, email, announcement_id, app_version, ts}
/feedback/<pushId>      {uid, email, rating, comment, app_version, ts}
/support_tickets/<id>   {uid, email, subject, message, contact, status, ts}
```
No screenshots, session contents, or file paths are ever uploaded — usage metrics
only. All writes are offline-queued and flushed when online, authenticated with the
user's Firebase id token (`?auth=<idToken>`).

## 5. Suggested security rules
```json
{ "rules": {
  "broadcasts":      { ".read": "auth != null", ".write": false },
  "installs":        { "$id": { ".read": false, ".write": "auth != null" } },
  "events":          { ".read": false, ".write": "auth != null" },
  "acknowledgements":{ ".read": false, ".write": "auth != null" },
  "feedback":        { ".read": false, ".write": "auth != null" },
  "support_tickets": { ".read": false, ".write": "auth != null" }
}}
```
Your future NextJS admin portal uses the Firebase Admin SDK (bypasses these rules)
to write `/broadcasts` and read analytics/feedback/tickets/acknowledgements.

## 6. Register, display name, export logging (v4 update)
- **Create Account** uses Firebase REST `signUp` then `accounts:update` to set the
  display name (no Admin SDK). The login screen has a Sign In / Create Account
  toggle + Forgot password, with validation (email format, password length, match).
- The **splash screen greets the user**: "Welcome back, <first name> 👋".
- Display name flows into telemetry: `/installs/<id>.name` and every event/feedback/
  acknowledgement/export carries `name` + `email` + `uid`.
- **Export logging** — every export writes:
  ```
  /export_logs/<pushId> = { uid, email, name, type, ts }
  ```
  i.e. "<user> exported <PDF|Word|Enterprise DOCX|HTML|Excel|Markdown> at <ts>".
  Add `export_logs` to your security rules the same way as `events`.

## 7. Blocking, live chat, AI help (v4 update)
- **Block a user:** admin toggles Block in the portal → writes `/blocks/<uid>`.
  The desktop app checks this on startup and every poll; a blocked user sees an
  "Access Restricted" screen and the app closes. Unblock removes the node.
- **Live support chat:** Help → Live Support writes to
  `/support_chats/<uid>/messages` ({from:"user"|"admin", text, ts}); the admin
  replies from the portal's Live Chat page. Add the `blocks` and `support_chats`
  rules from `database.rules.json`.
- **AI help assistant:** Help → AI Assistant answers tool questions via Groq
  (`TEXT_MODEL`), with an offline FAQ fallback. A "Tour" button gives a quick walkthrough.
