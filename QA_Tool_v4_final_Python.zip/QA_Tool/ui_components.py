"""
UI Components - Custom widgets and styling
"""

from PyQt6.QtWidgets import (QPushButton, QFrame, QLabel, QVBoxLayout, 
                             QHBoxLayout, QWidget, QGraphicsOpacityEffect)
from PyQt6.QtCore import Qt, QPropertyAnimation, QRect, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QPainter, QPainterPath, QLinearGradient


class ModernButton(QPushButton):
    """Modern styled button with hover effects"""
    
    def __init__(self, text: str, color: str = "#e94560", parent=None):
        super().__init__(text, parent)
        self.default_color = color
        self.hover_color = self._adjust_brightness(color, 1.2)
        self.press_color = self._adjust_brightness(color, 0.8)
        
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {self.default_color};
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background-color: {self.hover_color};
            }}
            QPushButton:pressed {{
                background-color: {self.press_color};
            }}
            QPushButton:disabled {{
                background-color: #555;
                color: #888;
            }}
        """)
    
    def _adjust_brightness(self, hex_color: str, factor: float) -> str:
        """Adjust color brightness"""
        hex_color = hex_color.lstrip('#')
        r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
        r = min(255, int(r * factor))
        g = min(255, int(g * factor))
        b = min(255, int(b * factor))
        return f"#{r:02x}{g:02x}{b:02x}"


class ModernCard(QFrame):
    """Card widget with shadow and rounded corners"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setStyleSheet("""
            ModernCard {
                background-color: #16213e;
                border-radius: 12px;
                margin: 5px;
            }
        """)
        
        # Add shadow effect
        self.setGraphicsEffect(self._create_shadow())
        
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(15, 15, 15, 15)
    
    def _create_shadow(self):
        """Create drop shadow effect"""
        from PyQt6.QtWidgets import QGraphicsDropShadowEffect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setColor(QColor(0, 0, 0, 80))
        shadow.setOffset(0, 5)
        return shadow
    
    def set_title(self, title: str):
        """Set card title"""
        title_label = QLabel(title)
        title_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #e94560;")
        self.layout.insertWidget(0, title_label)
        self.layout.insertSpacing(1, 10)


class ToastNotification(QWidget):
    """Toast notification popup"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | 
                           Qt.WindowType.ToolTip)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        self.setStyleSheet("""
            QWidget {
                background-color: #333;
                border-radius: 8px;
            }
            QLabel {
                color: white;
                padding: 10px 20px;
                font-size: 13px;
            }
        """)
        
        layout = QHBoxLayout(self)
        self.icon_label = QLabel()
        self.text_label = QLabel()
        layout.addWidget(self.icon_label)
        layout.addWidget(self.text_label)
        
        self.opacity_effect = QGraphicsOpacityEffect()
        self.setGraphicsEffect(self.opacity_effect)
        
        self.animation = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.animation.setDuration(300)
        
        self.timer = QTimer()
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.hide_animation)
    
    @classmethod
    def show_toast(cls, parent, title: str, message: str, duration: int = 3000):
        """Show toast notification - FIXED method name"""
        toast = cls(parent)
        
        # Set icon based on title
        if "✅" in title or "Complete" in title:
            toast.icon_label.setText("✅ ")
        elif "⚠️" in title or "Error" in title:
            toast.icon_label.setText("⚠️ ")
        elif "📸" in title:
            toast.icon_label.setText("📸 ")
        else:
            toast.icon_label.setText("ℹ️ ")
        
        toast.text_label.setText(f"{title}: {message}")
        
        # Calculate size before showing
        toast.adjustSize()
        
        # Position at bottom right
        if parent:
            parent_rect = parent.geometry()
            x = parent_rect.x() + parent_rect.width() - toast.width() - 20
            y = parent_rect.y() + parent_rect.height() - toast.height() - 50
            toast.setGeometry(x, y, toast.width(), toast.height())
        
        toast.show_animation()
        toast.timer.start(duration)
    
    def show_animation(self):
        """Show with fade in animation"""
        self.show()
        self.animation.setStartValue(0)
        self.animation.setEndValue(1)
        self.animation.start()
    
    def hide_animation(self):
        """Hide with fade out animation"""
        self.animation.setStartValue(1)
        self.animation.setEndValue(0)
        self.animation.finished.connect(self.close)
        self.animation.start()


class AnimatedWidget(QWidget):
    """Widget with animation support"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.animation = None
    
    def fade_in(self, duration: int = 300):
        """Fade in animation"""
        effect = QGraphicsOpacityEffect()
        self.setGraphicsEffect(effect)
        self.animation = QPropertyAnimation(effect, b"opacity")
        self.animation.setDuration(duration)
        self.animation.setStartValue(0)
        self.animation.setEndValue(1)
        self.animation.start()
    
    def fade_out(self, duration: int = 300):
        """Fade out animation"""
        effect = self.graphicsEffect()
        if effect:
            self.animation = QPropertyAnimation(effect, b"opacity")
            self.animation.setDuration(duration)
            self.animation.setStartValue(1)
            self.animation.setEndValue(0)
            self.animation.finished.connect(self.hide)
            self.animation.start()


class ProgressIndicator(QWidget):
    """Circular progress indicator"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(50, 50)
        self.angle = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.rotate)
        self.is_running = False
    
    def start(self):
        """Start animation"""
        self.is_running = True
        self.show()
        self.timer.start(50)
    
    def stop(self):
        """Stop animation"""
        self.is_running = False
        self.timer.stop()
        self.hide()
    
    def rotate(self):
        """Rotate indicator"""
        self.angle = (self.angle + 10) % 360
        self.update()
    
    def paintEvent(self, event):
        """Draw progress indicator"""
        if not self.is_running:
            return
        
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Draw circle
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(233, 69, 96, 100))
        painter.drawEllipse(5, 5, 40, 40)
        
        # Draw arc
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(233, 69, 96))
        
        path = QPainterPath()
        path.arcTo(5, 5, 40, 40, self.angle, 90)
        painter.drawPath(path)