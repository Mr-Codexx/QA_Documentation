"""
Auth Service — Firebase Authentication (email + password) over REST.

No Firebase Admin SDK. Pure HTTPS REST against Google Identity Toolkit /
Secure Token. Supports: sign in, register (sign up + display name), password
reset, silent session restore (refresh-token persistence), token refresh, logout.

Security: passwords are never stored — only the refresh token (when "Remember
me" is on). All endpoints are HTTPS. Network goes through `_http()` (patchable).
"""

from __future__ import annotations

import base64
import json
import os
import re
import time
from typing import Optional

try:
    import requests
except Exception:  # pragma: no cover
    requests = None

from app_backend import FIREBASE_API_KEY

IDTK = "https://identitytoolkit.googleapis.com/v1/accounts"
SECURETOKEN = "https://securetoken.googleapis.com/v1/token"

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class AuthError(Exception):
    """User-friendly auth error."""


_FRIENDLY = {
    "EMAIL_NOT_FOUND": "No account found with that email.",
    "INVALID_PASSWORD": "Incorrect password. Please try again.",
    "INVALID_LOGIN_CREDENTIALS": "Incorrect email or password.",
    "USER_DISABLED": "This account has been disabled.",
    "INVALID_EMAIL": "That email address looks invalid.",
    "EMAIL_EXISTS": "An account with that email already exists.",
    "WEAK_PASSWORD": "Password should be at least 6 characters.",
    "OPERATION_NOT_ALLOWED": "Email/password sign-in is not enabled for this project.",
    "TOO_MANY_ATTEMPTS_TRY_LATER": "Too many attempts. Please try again later.",
    "MISSING_PASSWORD": "Please enter your password.",
}


def valid_email(s: str) -> bool:
    return bool(_EMAIL_RE.match((s or "").strip()))


class User:
    __slots__ = ("uid", "email", "display_name", "id_token", "refresh_token", "expires_at")

    def __init__(self, uid, email, display_name, id_token, refresh_token, expires_in):
        self.uid = uid
        self.email = email
        self.display_name = display_name or (email.split("@")[0] if email else "")
        self.id_token = id_token
        self.refresh_token = refresh_token
        self.expires_at = time.time() + int(expires_in or 3600)

    @property
    def first_name(self):
        return (self.display_name or "").split(" ")[0] or self.display_name


class AuthService:
    SESSION_FILE = ".qa_session"

    def __init__(self, base_path="."):
        self.base_path = base_path
        self.session_path = os.path.join(base_path, self.SESSION_FILE)
        self.api_key = FIREBASE_API_KEY
        self.current_user: Optional[User] = None

    # ---- network (patchable in tests) ----
    def _http(self, url, data, form=False, timeout=15):
        if requests is None:
            raise AuthError("Network unavailable.")
        if form:
            r = requests.post(url, data=data, timeout=timeout)
        else:
            r = requests.post(url, json=data, timeout=timeout)
        body = {}
        try:
            body = r.json()
        except Exception:
            pass
        if r.status_code >= 400:
            code = (body.get("error", {}) or {}).get("message", "").split(" ")[0]
            raise AuthError(_FRIENDLY.get(code, "Request failed. Check your connection and try again."))
        return body

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    # ---- sign in ----
    def sign_in(self, email, password, remember=True) -> User:
        if not self.configured:
            raise AuthError("Authentication is not configured for this build.")
        d = self._http(f"{IDTK}:signInWithPassword?key={self.api_key}",
                       {"email": email.strip(), "password": password, "returnSecureToken": True})
        u = User(d["localId"], d.get("email", email), d.get("displayName", ""),
                 d["idToken"], d["refreshToken"], d.get("expiresIn", 3600))
        self.current_user = u
        self._save_session(u) if remember else self._clear_session()
        return u

    # ---- register (sign up + set display name) ----
    def register(self, name, email, password, remember=True) -> User:
        if not self.configured:
            raise AuthError("Authentication is not configured for this build.")
        if not valid_email(email):
            raise AuthError("Please enter a valid email address.")
        if len(password) < 6:
            raise AuthError("Password should be at least 6 characters.")
        d = self._http(f"{IDTK}:signUp?key={self.api_key}",
                       {"email": email.strip(), "password": password, "returnSecureToken": True})
        id_token = d["idToken"]
        name = (name or "").strip()
        if name:
            try:
                self._http(f"{IDTK}:update?key={self.api_key}",
                           {"idToken": id_token, "displayName": name, "returnSecureToken": False})
            except Exception:
                pass
        u = User(d["localId"], d.get("email", email), name,
                 id_token, d["refreshToken"], d.get("expiresIn", 3600))
        self.current_user = u
        self._save_session(u) if remember else self._clear_session()
        return u

    def send_password_reset(self, email):
        if not self.configured:
            raise AuthError("Authentication is not configured for this build.")
        if not valid_email(email):
            raise AuthError("Please enter a valid email address.")
        self._http(f"{IDTK}:sendOobCode?key={self.api_key}",
                   {"requestType": "PASSWORD_RESET", "email": email.strip()})

    def logout(self):
        self.current_user = None
        self._clear_session()

    # ---- session restore / token refresh ----
    def try_restore_session(self) -> Optional[User]:
        if not self.configured:
            return None
        data = self._read_session()
        rt = data.get("refresh_token") if data else None
        if not rt:
            return None
        try:
            tok = self._http(f"{SECURETOKEN}?key={self.api_key}",
                             {"grant_type": "refresh_token", "refresh_token": rt}, form=True)
            u = User(tok["user_id"], data.get("email", ""), data.get("display_name", ""),
                     tok["id_token"], tok["refresh_token"], tok.get("expires_in", 3600))
            self.current_user = u
            self._save_session(u)
            return u
        except Exception:
            self._clear_session()
            return None

    def id_token(self) -> Optional[str]:
        u = self.current_user
        if not u:
            return None
        if time.time() > u.expires_at - 120:
            try:
                tok = self._http(f"{SECURETOKEN}?key={self.api_key}",
                                 {"grant_type": "refresh_token", "refresh_token": u.refresh_token}, form=True)
                u.id_token = tok["id_token"]; u.refresh_token = tok["refresh_token"]
                u.expires_at = time.time() + int(tok.get("expires_in", 3600))
                if os.path.exists(self.session_path):
                    self._save_session(u)
            except Exception:
                pass
        return u.id_token

    # ---- storage (refresh token only) ----
    def _save_session(self, u: User):
        try:
            blob = json.dumps({"refresh_token": u.refresh_token, "email": u.email,
                               "uid": u.uid, "display_name": u.display_name})
            open(self.session_path, "w", encoding="utf-8").write(
                base64.b64encode(blob.encode()).decode())
        except Exception:
            pass

    def _read_session(self):
        try:
            return json.loads(base64.b64decode(open(self.session_path, encoding="utf-8").read().encode()).decode())
        except Exception:
            return None

    def _clear_session(self):
        try:
            if os.path.exists(self.session_path):
                os.remove(self.session_path)
        except Exception:
            pass


if __name__ == "__main__":
    import tempfile
    d = tempfile.mkdtemp(); a = AuthService(d); a.api_key = "fake"
    store = {}
    def fake(url, data, form=False, timeout=15):
        if "signUp" in url:
            store["email"] = data["email"]
            return {"localId": "u1", "email": data["email"], "idToken": "ID", "refreshToken": "RT", "expiresIn": 3600}
        if ":update" in url:
            store["name"] = data["displayName"]; return {"displayName": data["displayName"]}
        if "signInWithPassword" in url:
            if data["password"] != "correct": raise AuthError(_FRIENDLY["INVALID_PASSWORD"])
            return {"localId": "u1", "email": data["email"], "displayName": store.get("name", "Sachin Sharma"),
                    "idToken": "ID", "refreshToken": "RT", "expiresIn": 3600}
        if "securetoken" in url:
            return {"user_id": "u1", "id_token": "ID2", "refresh_token": "RT2", "expires_in": 3600}
        if "sendOobCode" in url:
            return {"email": data["email"]}
        return {}
    a._http = fake
    u = a.register("Sachin Sharma", "s@x.com", "secret1"); print("registered:", u.display_name, u.first_name)
    assert u.display_name == "Sachin Sharma"
    a2 = AuthService(d); a2.api_key = "fake"; a2._http = fake
    r = a2.try_restore_session(); print("restored name:", r.display_name)
    assert r.display_name == "Sachin Sharma"
    u2 = a.sign_in("s@x.com", "correct"); print("signin name:", u2.display_name, "| first:", u2.first_name)
    try: a.register("X", "bad-email", "secret1"); print("ERR")
    except AuthError as e: print("bad email ->", e)
    try: a.register("X", "ok@x.com", "123"); print("ERR")
    except AuthError as e: print("weak pw ->", e)
    print("ALL AUTH (register+name) TESTS PASSED")
