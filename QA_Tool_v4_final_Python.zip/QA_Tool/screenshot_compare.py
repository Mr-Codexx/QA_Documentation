"""
Screenshot Comparison Engine - v4.0

Before/After visual regression comparison.
  * pixel difference detection (tolerance-aware)
  * connected-region bounding boxes of changes
  * visual highlight overlay (red boxes) + side-by-side composite
  * textual change summary

Depends only on Pillow + numpy (already used by the app). No Qt.

Public API
----------
    result = compare_images("before.png", "after.png", out_dir="diffs")
    result.changed            -> bool
    result.change_percent     -> float (0..100)
    result.regions            -> list[(x, y, w, h)]
    result.summary()          -> human readable string
    result.overlay_path       -> annotated 'after' image
    result.sidebyside_path    -> before|diff|after composite
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List, Tuple

import numpy as np
from PIL import Image, ImageDraw, ImageChops


@dataclass
class ComparisonResult:
    changed: bool
    change_percent: float
    regions: List[Tuple[int, int, int, int]]
    width: int
    height: int
    overlay_path: str = ""
    sidebyside_path: str = ""
    notes: List[str] = field(default_factory=list)

    def summary(self) -> str:
        if not self.changed:
            return "No visual differences detected between the two screenshots."
        lines = [
            f"Detected {len(self.regions)} changed region(s) "
            f"covering {self.change_percent:.2f}% of the screen."
        ]
        for i, (x, y, w, h) in enumerate(self.regions[:10], 1):
            lines.append(f"  Region {i}: position ({x},{y}), size {w}x{h}px")
        if len(self.regions) > 10:
            lines.append(f"  ... and {len(self.regions) - 10} more.")
        lines.extend(self.notes)
        return "\n".join(lines)


def _load_aligned(path_a: str, path_b: str):
    a = Image.open(path_a).convert("RGB")
    b = Image.open(path_b).convert("RGB")
    if a.size != b.size:
        # normalise to the smaller common size so comparison is meaningful
        w = min(a.size[0], b.size[0])
        h = min(a.size[1], b.size[1])
        a = a.resize((w, h))
        b = b.resize((w, h))
        note = f"Images differed in size; both resized to {w}x{h} for comparison."
    else:
        note = ""
    return a, b, note


def _bounding_boxes(mask: np.ndarray, min_area: int = 64,
                    merge_gap: int = 12) -> List[Tuple[int, int, int, int]]:
    """Find changed-pixel clusters via row/column projection segmentation.

    Lightweight alternative to scipy.label; good enough for QA highlighting and
    keeps dependencies minimal.
    """
    ys, xs = np.where(mask)
    if len(xs) == 0:
        return []

    boxes: List[Tuple[int, int, int, int]] = []

    # Segment by horizontal bands of activity, then by columns within a band.
    rows_active = np.where(mask.any(axis=1))[0]
    bands = _segment(rows_active, merge_gap)
    for r0, r1 in bands:
        sub = mask[r0:r1 + 1]
        cols_active = np.where(sub.any(axis=0))[0]
        for c0, c1 in _segment(cols_active, merge_gap):
            w = c1 - c0 + 1
            h = r1 - r0 + 1
            if w * h >= min_area:
                boxes.append((int(c0), int(r0), int(w), int(h)))
    return boxes


def _segment(indices: np.ndarray, gap: int) -> List[Tuple[int, int]]:
    if len(indices) == 0:
        return []
    segs = []
    start = prev = indices[0]
    for v in indices[1:]:
        if v - prev > gap:
            segs.append((int(start), int(prev)))
            start = v
        prev = v
    segs.append((int(start), int(prev)))
    return segs


def compare_images(before_path: str, after_path: str,
                   out_dir: str = ".", tolerance: int = 25,
                   make_overlay: bool = True,
                   make_sidebyside: bool = True) -> ComparisonResult:
    """Compare two screenshots. `tolerance` is the per-channel diff threshold."""
    a, b, resize_note = _load_aligned(before_path, after_path)
    w, h = a.size

    arr_a = np.asarray(a, dtype=np.int16)
    arr_b = np.asarray(b, dtype=np.int16)
    delta = np.abs(arr_a - arr_b).max(axis=2)  # max channel diff per pixel
    mask = delta > tolerance

    changed_pixels = int(mask.sum())
    change_percent = 100.0 * changed_pixels / (w * h) if w * h else 0.0
    regions = _bounding_boxes(mask)
    changed = change_percent > 0.01 and len(regions) > 0

    notes = []
    if resize_note:
        notes.append(resize_note)

    result = ComparisonResult(
        changed=changed,
        change_percent=change_percent,
        regions=regions,
        width=w, height=h,
        notes=notes,
    )

    if not changed:
        return result

    os.makedirs(out_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(after_path))[0]

    if make_overlay:
        overlay = b.copy()
        draw = ImageDraw.Draw(overlay)
        for (x, y, rw, rh) in regions:
            draw.rectangle([x, y, x + rw, y + rh], outline=(229, 57, 53), width=3)
        result.overlay_path = os.path.join(out_dir, f"{base}_diff_overlay.png")
        overlay.save(result.overlay_path)

    if make_sidebyside:
        # before | heat-diff | after
        diff_img = ImageChops.difference(a, b).convert("L").convert("RGB")
        gap = 12
        canvas = Image.new("RGB", (w * 3 + gap * 2, h), (245, 245, 247))
        canvas.paste(a, (0, 0))
        canvas.paste(diff_img, (w + gap, 0))
        canvas.paste(b, (w * 2 + gap * 2, 0))
        result.sidebyside_path = os.path.join(out_dir, f"{base}_sidebyside.png")
        canvas.save(result.sidebyside_path)

    return result


if __name__ == "__main__":
    # self-test: synthesize two near-identical images with one changed block
    os.makedirs("/tmp/cmp", exist_ok=True)
    img1 = Image.new("RGB", (400, 300), (250, 250, 250))
    d = ImageDraw.Draw(img1)
    d.rectangle([20, 20, 180, 80], fill=(60, 120, 200))
    img1.save("/tmp/cmp/before.png")

    img2 = img1.copy()
    d2 = ImageDraw.Draw(img2)
    d2.rectangle([220, 180, 360, 250], fill=(200, 60, 60))   # new element
    d2.rectangle([20, 20, 180, 80], fill=(60, 200, 120))      # color change
    img2.save("/tmp/cmp/after.png")

    res = compare_images("/tmp/cmp/before.png", "/tmp/cmp/after.png", out_dir="/tmp/cmp")
    print(res.summary())
    print("overlay:", res.overlay_path)
    print("sidebyside:", res.sidebyside_path)
