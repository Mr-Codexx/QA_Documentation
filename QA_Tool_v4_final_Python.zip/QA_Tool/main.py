#!/usr/bin/env python3
"""
AI-Powered QA Documentation Assistant
Main Application Entry Point — v3.2 STEP EDITOR EDITION
Features: Fully responsive UI, auto-save drafts, crash recovery,
          Step image annotation editor, move/duplicate/delete steps,
          right-click context menu, scales from 11" to 4K
"""

import sys
import json
import os
import atexit
import signal
import traceback
import copy
from datetime import datetime
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QSystemTrayIcon, QMenu, QWidget,
    QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QListWidget,
    QListWidgetItem, QStackedWidget, QTextEdit, QFileDialog, QMessageBox,
    QProgressBar, QStatusBar, QSplitter, QFrame, QScrollArea, QGridLayout,
    QGroupBox, QCheckBox, QComboBox, QSpinBox, QSlider, QInputDialog,
    QDialog, QDialogButtonBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QTabWidget, QSizePolicy, QLineEdit, QToolButton, QToolBar, QStyle,
    QColorDialog
)
from PyQt6.QtCore import (
    Qt, QTimer, pyqtSignal, QSize, QRect, QPoint, QThread, pyqtSlot,
    QMutex, QEvent, QPointF, QRectF, QLineF
)
from PyQt6.QtGui import (
    QIcon, QFont, QPalette, QColor, QPixmap, QAction, QShortcut,
    QKeySequence, QPainter, QLinearGradient, QBrush, QPen, QFontMetrics,
    QScreen, QCursor, QImage, QPainterPath
)

from session_manager import SessionManager, StepData
from screenshot_tool import (
    ScreenshotTool, FloatingToolbar,
    register_ui_widget, unregister_ui_widget
)
from ai_processor import AIProcessor
from export_engine import ExportEngine
from ui_components import ModernButton, ModernCard, ToastNotification
from splash_screen import ModernSplashScreen
import ctypes
from notification_manager import NotificationManager

myappid = 'qa.documentation.assistant.v3'
ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)



# ─── v4.0 Enterprise modules (additive; degrade gracefully if missing) ───
try:
    from onedrive_integration import StorageManager
    from theme_manager import ThemeManager
    from notification_center import NotificationCenter
    from dashboard import DashboardStats
    from global_search import GlobalSearch
    from defect_assistant import DefectAssistant
    from update_manager import UpdateManager
    from cloud_sync import CloudSync, make_worker
    from premium_dialogs import (LoginDialog, AnnouncementModal, UpdateModal,
                                  FeatureModal, FeedbackDialog, ThankYouModal, BlockedDialog, BlockedScreen)
    from auth_service import AuthService
    _V4_OK = True
except Exception as _v4err:  # pragma: no cover
    print(f"[v4] enterprise modules unavailable: {_v4err}")
    _V4_OK = False

APP_VERSION = "4.0.0"
UPDATE_MANIFEST_URL = "https://codexqa.vercel.app/api/latest"   # release manifest (served from the admin portal)

def get_base_path():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def get_icon_path():
    return os.path.join(get_base_path(), "icon.ico")


# ═══════════════════════════════════════════════════════════════════
#  SCREEN METRICS
# ═══════════════════════════════════════════════════════════════════

class ScreenMetrics:
    def __init__(self):
        screen = QApplication.primaryScreen()
        rect   = screen.availableGeometry()
        self.sw  = rect.width()
        self.sh  = rect.height()
        self.dpr = screen.devicePixelRatio()
        if   self.sw < 1280: self.tier = "xs"
        elif self.sw < 1440: self.tier = "sm"
        elif self.sw < 1920: self.tier = "md"
        else:                self.tier = "lg"

    def scale(self, base, xs=None, sm=None, md=None, lg=None):
        v = {"xs": xs, "sm": sm, "md": md, "lg": lg}.get(self.tier)
        return v if v is not None else base

    @property
    def left_panel_w(self):   return self.scale(280, xs=200, sm=220, md=260, lg=300)
    @property
    def right_panel_w(self):  return self.scale(340, xs=240, sm=260, md=300, lg=360)
    @property
    def preview_h(self):      return self.scale(220, xs=140, sm=160, md=200, lg=240)
    @property
    def title_h(self):        return self.scale(56,  xs=40,  sm=44,  md=50,  lg=58)
    @property
    def btn_font(self):       return self.scale(13,  xs=10,  sm=11,  md=12,  lg=13)
    @property
    def label_font(self):     return self.scale(12,  xs=9,   sm=10,  md=11,  lg=12)
    @property
    def title_font(self):     return self.scale(15,  xs=11,  sm=12,  md=14,  lg=16)
    @property
    def btn_padding(self):    return self.scale("10px 16px", xs="5px 6px", sm="7px 8px", md="9px 12px", lg="10px 16px")
    @property
    def panel_margin(self):   return self.scale(14,  xs=6,   sm=8,   md=10,  lg=14)
    @property
    def win_min_w(self):      return self.scale(1100, xs=800, sm=900, md=1000, lg=1200)
    @property
    def win_min_h(self):      return self.scale(700,  xs=560, sm=600, md=650,  lg=750)
    @property
    def compact(self):        return False
    @property
    def icon_only_left(self): return False


_metrics = None
def metrics() -> ScreenMetrics:
    global _metrics
    if _metrics is None:
        _metrics = ScreenMetrics()
    return _metrics


# ═══════════════════════════════════════════════════════════════════
#  ANNOTATION CANVAS
# ═══════════════════════════════════════════════════════════════════

class AnnotationCanvas(QWidget):
    """
    Draws highlights, arrows, freehand lines and text labels on top of
    a screenshot. All annotations stored as dicts; undo/redo supported.
    """
    changed = pyqtSignal()

    TOOL_RECT  = "rect"
    TOOL_ARROW = "arrow"
    TOOL_FREE  = "free"
    TOOL_TEXT  = "text"
    TOOL_ERASE = "erase"

    def __init__(self, pixmap: QPixmap, parent=None):
        super().__init__(parent)
        self._base    = pixmap
        self._ann     = []          # committed annotations
        self._redo    = []
        self._tool    = self.TOOL_RECT
        self._color   = QColor("#ff4444")
        self._lw      = 3
        self._drawing = False
        self._sp      = QPoint()    # start point (img coords)
        self._fps     = []          # freehand points
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.CrossCursor)

    # ── Tool/color ──────────────────────────────────────────────
    def set_tool(self, tool):
        self._tool = tool
        cur = {self.TOOL_RECT: Qt.CursorShape.CrossCursor,
               self.TOOL_ARROW: Qt.CursorShape.CrossCursor,
               self.TOOL_FREE:  Qt.CursorShape.CrossCursor,
               self.TOOL_TEXT:  Qt.CursorShape.IBeamCursor,
               self.TOOL_ERASE: Qt.CursorShape.ForbiddenCursor}.get(tool, Qt.CursorShape.CrossCursor)
        self.setCursor(cur)

    def set_color(self, c: QColor): self._color = c
    def set_lw(self, w: int):       self._lw    = w

    def undo(self):
        if self._ann:
            self._redo.append(self._ann.pop()); self.update(); self.changed.emit()

    def redo(self):
        if self._redo:
            self._ann.append(self._redo.pop()); self.update(); self.changed.emit()

    def clear_all(self):
        self._ann.clear(); self._redo.clear(); self.update(); self.changed.emit()

    # ── Coordinate mapping ──────────────────────────────────────
    def _scale_info(self):
        iw, ih = self._base.width(), self._base.height()
        cw, ch = self.width(), self.height()
        s  = min(cw / max(iw,1), ch / max(ih,1))
        ox = (cw - iw*s) / 2
        oy = (ch - ih*s) / 2
        return s, ox, oy

    def _to_img(self, pt: QPoint) -> QPoint:
        s, ox, oy = self._scale_info()
        return QPoint(int((pt.x()-ox)/s), int((pt.y()-oy)/s))

    def _to_cv(self, x, y) -> QPoint:
        s, ox, oy = self._scale_info()
        return QPoint(int(x*s+ox), int(y*s+oy))

    # ── Mouse ────────────────────────────────────────────────────
    def mousePressEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton: return
        self._redo.clear()
        self._drawing = True
        self._sp = self._to_img(e.position().toPoint())
        if self._tool == self.TOOL_FREE:
            self._fps = [self._sp]
        elif self._tool == self.TOOL_TEXT:
            text, ok = QInputDialog.getText(self, "Add Label", "Enter label text:")
            if ok and text:
                self._ann.append({"type":"text","pt":(self._sp.x(),self._sp.y()),
                                  "text":text,"color":self._color.name(),"size":max(12,self._lw*4)})
                self.update(); self.changed.emit()
            self._drawing = False
        elif self._tool == self.TOOL_ERASE:
            self._try_erase(self._sp); self._drawing = False

    def mouseMoveEvent(self, e):
        if not self._drawing: return
        if self._tool == self.TOOL_FREE:
            self._fps.append(self._to_img(e.position().toPoint()))
        self.update()

    def mouseReleaseEvent(self, e):
        if not self._drawing or e.button() != Qt.MouseButton.LeftButton: return
        self._drawing = False
        ep = self._to_img(e.position().toPoint())
        if self._tool == self.TOOL_RECT:
            r = QRect(self._sp, ep).normalized()
            if r.width() > 3 and r.height() > 3:
                self._ann.append({"type":"rect","x":r.x(),"y":r.y(),"w":r.width(),"h":r.height(),
                                  "color":self._color.name(),"lw":self._lw})
        elif self._tool == self.TOOL_ARROW:
            if (ep-self._sp).manhattanLength() > 5:
                self._ann.append({"type":"arrow","x1":self._sp.x(),"y1":self._sp.y(),
                                  "x2":ep.x(),"y2":ep.y(),"color":self._color.name(),"lw":self._lw})
        elif self._tool == self.TOOL_FREE:
            if len(self._fps) > 2:
                self._ann.append({"type":"free","pts":[(p.x(),p.y()) for p in self._fps],
                                  "color":self._color.name(),"lw":self._lw})
            self._fps = []
        self.update(); self.changed.emit()

    def _try_erase(self, pt: QPoint):
        for i in range(len(self._ann)-1, -1, -1):
            a = self._ann[i]; hit = False
            if a["type"] == "rect":
                hit = QRect(a["x"]-8,a["y"]-8,a["w"]+16,a["h"]+16).contains(pt)
            elif a["type"] in ("arrow","free"):
                pts = [(a["x1"],a["y1"]),(a["x2"],a["y2"])] if a["type"]=="arrow" else a["pts"]
                for j in range(len(pts)-1):
                    p1x,p1y = pts[j]; p2x,p2y = pts[j+1]
                    dx,dy = p2x-p1x, p2y-p1y; lsq = dx*dx+dy*dy
                    if lsq > 0:
                        t = max(0,min(1,((pt.x()-p1x)*dx+(pt.y()-p1y)*dy)/lsq))
                        cx,cy = p1x+t*dx, p1y+t*dy
                        if ((pt.x()-cx)**2+(pt.y()-cy)**2)**0.5 < 12: hit=True; break
            elif a["type"] == "text":
                tx,ty = a["pt"]
                hit = QRect(tx-5,ty-20,120,28).contains(pt)
            if hit:
                self._redo.append(self._ann.pop(i)); self.update(); self.changed.emit(); return

    # ── Paint ────────────────────────────────────────────────────
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        s, ox, oy = self._scale_info()
        iw,ih = self._base.width(), self._base.height()
        p.drawPixmap(QRect(int(ox),int(oy),int(iw*s),int(ih*s)), self._base)

        all_ann = self._ann[:]
        if self._drawing and self._tool == self.TOOL_FREE and self._fps:
            all_ann.append({"type":"free","pts":[(pt.x(),pt.y()) for pt in self._fps],
                            "color":self._color.name(),"lw":self._lw})

        cv = self._to_cv

        for a in all_ann:
            c = QColor(a["color"]); t = a["type"]
            if t == "rect":
                pen = QPen(c, a["lw"]*s, Qt.PenStyle.SolidLine); pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
                p.setPen(pen); fill = QColor(c); fill.setAlpha(35); p.setBrush(QBrush(fill))
                p1 = cv(a["x"], a["y"])
                p.drawRect(QRect(p1, QSize(int(a["w"]*s), int(a["h"]*s))))
                p.setBrush(Qt.BrushStyle.NoBrush)
            elif t == "arrow":
                import math
                pen = QPen(c, a["lw"]*s, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
                p.setPen(pen); p.setBrush(QBrush(c))
                p1 = cv(a["x1"],a["y1"]); p2 = cv(a["x2"],a["y2"])
                p.drawLine(p1,p2)
                dx,dy = p2.x()-p1.x(), p2.y()-p1.y()
                ang = math.atan2(dy,dx); hs = max(8, a["lw"]*s*3); ha = 0.45
                path = QPainterPath(); path.moveTo(p2)
                path.lineTo(p2.x()-hs*math.cos(ang-ha), p2.y()-hs*math.sin(ang-ha))
                path.lineTo(p2.x()-hs*math.cos(ang+ha), p2.y()-hs*math.sin(ang+ha))
                path.closeSubpath(); p.drawPath(path)
            elif t == "free":
                pen = QPen(c, a["lw"]*s, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
                p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
                pts = a["pts"]
                for i in range(len(pts)-1): p.drawLine(cv(*pts[i]), cv(*pts[i+1]))
            elif t == "text":
                tx,ty = a["pt"]; cp = cv(tx,ty)
                fnt = QFont("Segoe UI", int(a["size"]*s*0.7), QFont.Weight.Bold)
                p.setFont(fnt)
                p.setPen(QPen(QColor("#000000"),1)); p.drawText(cp+QPoint(2,2), a["text"])
                p.setPen(QPen(c,1)); p.drawText(cp, a["text"])

        # Live preview while dragging rect/arrow
        if self._drawing and self._tool in (self.TOOL_RECT, self.TOOL_ARROW):
            cur = self._to_img(self.mapFromGlobal(QCursor.pos()))
            pen = QPen(self._color, self._lw*s, Qt.PenStyle.DashLine)
            p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
            if self._tool == self.TOOL_RECT:
                r = QRect(cv(self._sp.x(),self._sp.y()), cv(cur.x(),cur.y())).normalized()
                p.drawRect(r)
            else:
                p.drawLine(cv(self._sp.x(),self._sp.y()), cv(cur.x(),cur.y()))
        p.end()

    # ── Export at full image resolution ─────────────────────────
    def get_annotated_pixmap(self) -> QPixmap:
        import math
        iw, ih = self._base.width(), self._base.height()
        result = QPixmap(iw, ih); result.fill(Qt.GlobalColor.transparent)
        p = QPainter(result)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.drawPixmap(0, 0, self._base)

        def c(x,y): return QPoint(int(x),int(y))

        for a in self._ann:
            col = QColor(a["color"]); t = a["type"]
            if t == "rect":
                pen = QPen(col, a["lw"], Qt.PenStyle.SolidLine); pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
                p.setPen(pen); fill = QColor(col); fill.setAlpha(40); p.setBrush(QBrush(fill))
                p.drawRect(QRect(a["x"],a["y"],a["w"],a["h"])); p.setBrush(Qt.BrushStyle.NoBrush)
            elif t == "arrow":
                pen = QPen(col, a["lw"], Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
                p.setPen(pen); p.setBrush(QBrush(col))
                p1=c(a["x1"],a["y1"]); p2=c(a["x2"],a["y2"]); p.drawLine(p1,p2)
                dx,dy = p2.x()-p1.x(), p2.y()-p1.y()
                ang = math.atan2(dy,dx); hs = a["lw"]*6; ha = 0.45
                path = QPainterPath(); path.moveTo(p2)
                path.lineTo(p2.x()-hs*math.cos(ang-ha), p2.y()-hs*math.sin(ang-ha))
                path.lineTo(p2.x()-hs*math.cos(ang+ha), p2.y()-hs*math.sin(ang+ha))
                path.closeSubpath(); p.drawPath(path)
            elif t == "free":
                pen = QPen(col, a["lw"], Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
                p.setPen(pen); pts=a["pts"]
                for i in range(len(pts)-1): p.drawLine(c(*pts[i]), c(*pts[i+1]))
            elif t == "text":
                tx,ty = a["pt"]; fnt = QFont("Segoe UI", a["size"], QFont.Weight.Bold)
                p.setFont(fnt)
                p.setPen(QPen(QColor("#000000"),1)); p.drawText(c(tx,ty)+QPoint(2,2), a["text"])
                p.setPen(QPen(col,1)); p.drawText(c(tx,ty), a["text"])
        p.end()
        return result


# ═══════════════════════════════════════════════════════════════════
#  STEP IMAGE EDITOR DIALOG
# ═══════════════════════════════════════════════════════════════════

class StepImageEditorDialog(QDialog):
    """
    Full-screen annotation editor.
    Tools: Rectangle highlight, Arrow, Freehand, Text label, Eraser
    Keyboard: Ctrl+Z undo  Ctrl+Y redo  Escape cancel
    """
    def __init__(self, image_path: str, parent=None):
        super().__init__(parent)
        self._path = image_path
        self._orig = QPixmap(image_path)
        self.setWindowTitle("✏  Screenshot Annotation Editor")
        self.setModal(True)
        screen = QApplication.primaryScreen().availableGeometry()
        w = min(int(screen.width()  * 0.88), 1440)
        h = min(int(screen.height() * 0.88), 940)
        self.setGeometry((screen.width()-w)//2, (screen.height()-h)//2, w, h)
        self.setStyleSheet("""
            QDialog   { background: #080812; color: #e8e8ff; }
            QLabel    { color: #c8c8ee; font-size: 12px; }
            QPushButton {
                background: #12122a; border: 1px solid #2a2a5a;
                border-radius: 7px; padding: 7px 14px;
                font-size: 12px; font-weight: 600; color: #e8e8ff;
            }
            QPushButton:hover    { background: #1e1e3e; border-color: #6c63ff; }
            QPushButton:checked  { background: #2a1a5e; border-color: #a78bfa; color: #a78bfa; }
            QPushButton:pressed  { background: #6c63ff; }
            QFrame#tb { background: #06060f; border-bottom: 1px solid #1a1a30; }
            QSlider::groove:horizontal { background: #1a1a30; height: 4px; border-radius: 2px; }
            QSlider::handle:horizontal {
                background: #6c63ff; width: 14px; height: 14px;
                border-radius: 7px; margin: -5px 0;
            }
        """)
        self._build()

    def _build(self):
        root = QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)

        # ── Toolbar ──────────────────────────────────────────
        tb = QFrame(); tb.setObjectName("tb"); tb.setFixedHeight(54)
        tbl = QHBoxLayout(tb); tbl.setContentsMargins(12,6,12,6); tbl.setSpacing(6)

        tools = [("⬜","Highlight Rectangle", AnnotationCanvas.TOOL_RECT),
                 ("➡","Arrow",               AnnotationCanvas.TOOL_ARROW),
                 ("✏","Freehand Draw",        AnnotationCanvas.TOOL_FREE),
                 ("T","Text Label",           AnnotationCanvas.TOOL_TEXT),
                 ("⌫","Eraser (click annot.)",AnnotationCanvas.TOOL_ERASE)]
        self._tbns = {}
        for ico,tip,tool in tools:
            b = QPushButton(ico); b.setToolTip(tip); b.setFixedSize(36,36); b.setCheckable(True)
            b.clicked.connect(lambda _, t=tool: self._sel_tool(t))
            self._tbns[tool] = b; tbl.addWidget(b)

        tbl.addWidget(self._sep())

        self._cprev = QPushButton(); self._cprev.setFixedSize(36,36)
        self._cprev.setToolTip("Pick color"); self._col = QColor("#ff4444")
        self._upd_col(); self._cprev.clicked.connect(self._pick_col)
        tbl.addWidget(self._cprev)

        tbl.addWidget(QLabel("  Width:"))
        self._wslider = QSlider(Qt.Orientation.Horizontal)
        self._wslider.setRange(1,10); self._wslider.setValue(3); self._wslider.setFixedWidth(90)
        self._wslider.valueChanged.connect(self._on_w)
        tbl.addWidget(self._wslider)
        self._wlbl = QLabel("3px"); self._wlbl.setStyleSheet("color:#8888aa;font-size:11px;")
        self._wlbl.setFixedWidth(28); tbl.addWidget(self._wlbl)

        tbl.addWidget(self._sep())

        for lbl,tip,fn in [("↩ Undo","Undo  Ctrl+Z",self._undo),
                           ("↪ Redo","Redo  Ctrl+Y",self._redo),]:
            b = QPushButton(lbl); b.setToolTip(tip); b.clicked.connect(fn); tbl.addWidget(b)

        clr = QPushButton("🗑 Clear All"); clr.setToolTip("Remove all annotations")
        clr.setStyleSheet("QPushButton{background:#2a1a1a;border-color:#663333;color:#ff6b6b;}"
                          "QPushButton:hover{background:#3a2020;}")
        clr.clicked.connect(self._clear); tbl.addWidget(clr)

        tbl.addStretch()

        self._slbl = QLabel("0 annotations")
        self._slbl.setStyleSheet("color:#555577;font-size:11px;"); tbl.addWidget(self._slbl)
        tbl.addWidget(self._sep())

        cancel = QPushButton("✕ Cancel"); cancel.clicked.connect(self.reject); tbl.addWidget(cancel)

        save = QPushButton("✅  Save Annotations")
        save.setStyleSheet("QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
                           "stop:0 #1a4a2a,stop:1 #2a6a3a);border-color:#2ed573;color:#2ed573;}"
                           "QPushButton:hover{background:#1f5a30;}")
        save.clicked.connect(self._save); tbl.addWidget(save)
        root.addWidget(tb)

        # ── Canvas ───────────────────────────────────────────
        cf = QFrame(); cf.setStyleSheet("QFrame{background:#0a0a18;}")
        cl = QVBoxLayout(cf); cl.setContentsMargins(0,0,0,0)
        self._canvas = AnnotationCanvas(self._orig)
        self._canvas.changed.connect(self._on_chg)
        cl.addWidget(self._canvas); root.addWidget(cf, 1)

        QShortcut(QKeySequence("Ctrl+Z"),       self, self._undo)
        QShortcut(QKeySequence("Ctrl+Y"),       self, self._redo)
        QShortcut(QKeySequence("Ctrl+Shift+Z"), self, self._redo)

        self._sel_tool(AnnotationCanvas.TOOL_RECT)

    def _sep(self):
        f = QFrame(); f.setFixedSize(1,28); f.setStyleSheet("background:#1e1e38;"); return f

    def _sel_tool(self, tool):
        for t,b in self._tbns.items(): b.setChecked(t == tool)
        self._canvas.set_tool(tool)

    def _pick_col(self):
        c = QColorDialog.getColor(self._col, self, "Annotation Color")
        if c.isValid(): self._col = c; self._canvas.set_color(c); self._upd_col()

    def _upd_col(self):
        self._cprev.setStyleSheet(f"QPushButton{{background:{self._col.name()};"
                                  "border:2px solid #ffffff44;border-radius:7px;}}"
                                  "QPushButton:hover{border-color:#ffffffaa;}")

    def _on_w(self, v): self._canvas.set_lw(v); self._wlbl.setText(f"{v}px")
    def _undo(self):     self._canvas.undo()
    def _redo(self):     self._canvas.redo()

    def _clear(self):
        if QMessageBox.question(self, "Clear All", "Remove ALL annotations?",
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                                ) == QMessageBox.StandardButton.Yes:
            self._canvas.clear_all()

    def _on_chg(self):
        n = len(self._canvas._ann)
        self._slbl.setText(f"{n} annotation{'s' if n!=1 else ''}")

    def _save(self):
        pix = self._canvas.get_annotated_pixmap()
        if pix.save(self._path, "PNG"):
            self.accept()
        else:
            QMessageBox.critical(self, "Save Failed", f"Could not write:\n{self._path}")


# ═══════════════════════════════════════════════════════════════════
#  DRAFT MANAGER
# ═══════════════════════════════════════════════════════════════════

class DraftManager:
    DRAFT_FILE = "active_session_draft.json"
    LOCK_FILE  = "session.lock"

    def __init__(self, base_path: str):
        self.DRAFT_DIR   = os.path.join(base_path, "drafts")
        os.makedirs(self.DRAFT_DIR, exist_ok=True)
        self._mutex      = QMutex()
        self._draft_path = os.path.join(self.DRAFT_DIR, self.DRAFT_FILE)
        self._lock_path  = os.path.join(self.DRAFT_DIR, self.LOCK_FILE)

    def acquire_lock(self, name):
        with open(self._lock_path,"w") as f:
            json.dump({"pid":os.getpid(),"session_name":name,"started_at":datetime.now().isoformat()},f)

    def release_lock(self):
        try:
            if os.path.exists(self._lock_path): os.remove(self._lock_path)
        except Exception: pass

    def has_orphaned_lock(self):
        if not os.path.exists(self._lock_path): return None
        try:
            with open(self._lock_path) as f: data=json.load(f)
            pid=data.get("pid",0)
            if pid and pid!=os.getpid():
                try: os.kill(pid,0); return None
                except OSError: pass
            return data
        except Exception: return None

    def save_draft(self, session) -> bool:
        if not session: return False
        try:
            self._mutex.lock()
            steps=[{"image_path":s.image_path or "","capture_type":s.capture_type,
                    "timestamp":s.timestamp.isoformat(),"description":s.description or "",
                    "expected_behavior":s.expected_behavior or "",
                    "actual_observation":s.actual_observation or "","bug_hint":s.bug_hint or ""}
                   for s in session.steps]
            tmp=self._draft_path+".tmp"
            with open(tmp,"w",encoding="utf-8") as f:
                json.dump({"schema_version":"3.2","session_name":session.session_name,
                           "start_time":session.start_time.isoformat(),
                           "saved_at":datetime.now().isoformat(),
                           "steps":steps,"steps_count":len(steps)},f,indent=2,ensure_ascii=False)
            os.replace(tmp,self._draft_path); return True
        except Exception as e: print(f"[Draft] {e}"); return False
        finally: self._mutex.unlock()

    def load_draft(self):
        if not os.path.exists(self._draft_path): return None
        try:
            with open(self._draft_path,encoding="utf-8") as f: return json.load(f)
        except Exception: return None

    def has_draft(self): return os.path.exists(self._draft_path)
    def discard_draft(self):
        try:
            if os.path.exists(self._draft_path): os.remove(self._draft_path)
        except Exception: pass

    def get_draft_info(self):
        d=self.load_draft()
        if not d: return {}
        return {"session_name":d.get("session_name","?"),"saved_at":d.get("saved_at","?"),
                "steps_count":d.get("steps_count",0)}


# ═══════════════════════════════════════════════════════════════════
#  AUTO-SAVE WORKER
# ═══════════════════════════════════════════════════════════════════

class AutoSaveWorker(QThread):
    save_triggered = pyqtSignal()
    def __init__(self, interval_ms=15_000):
        super().__init__(); self.interval_ms=interval_ms; self._running=True
    def run(self):
        while self._running:
            self.msleep(self.interval_ms)
            if self._running: self.save_triggered.emit()
    def stop(self): self._running=False; self.quit(); self.wait(2000)


# ═══════════════════════════════════════════════════════════════════
#  DRAFT RECOVERY DIALOG
# ═══════════════════════════════════════════════════════════════════

class DraftRecoveryDialog(QDialog):
    def __init__(self, info: dict, parent=None):
        super().__init__(parent)
        m=metrics(); self.setWindowTitle("Recover Previous Session"); self.setModal(True)
        self.setFixedSize(m.scale(520,xs=360,sm=420,md=480,lg=540),
                          m.scale(340,xs=260,sm=290,md=320,lg=360))
        self.setStyleSheet(f"""
            QDialog{{background:#0f0f1a;border:1px solid #2a2a44;border-radius:16px;}}
            QLabel{{color:#e8e8ff;font-size:{m.label_font}px;}}
            QPushButton{{border-radius:10px;padding:{m.btn_padding};font-size:{m.btn_font}px;font-weight:bold;border:none;}}
        """)
        lay=QVBoxLayout(self)
        mp=m.scale(36,xs=16,sm=20,md=28,lg=36)
        lay.setContentsMargins(mp,mp,mp,m.scale(28,xs=14)); lay.setSpacing(m.scale(20,xs=10))

        top=QHBoxLayout()
        il=QLabel("🔄"); il.setFont(QFont("Segoe UI Emoji",m.scale(32,xs=20,sm=24))); top.addWidget(il)
        col=QVBoxLayout()
        t=QLabel("Unsaved Session Found"); t.setFont(QFont("Segoe UI",m.scale(18,xs=12,sm=13),QFont.Weight.Bold))
        t.setStyleSheet("color:#a78bfa;"); col.addWidget(t)
        s=QLabel("App closed unexpectedly. Work was auto-saved.")
        s.setStyleSheet(f"color:#8888aa;font-size:{m.scale(13,xs=9,sm=10)}px;"); s.setWordWrap(True); col.addWidget(s)
        top.addLayout(col); lay.addLayout(top)

        card=QFrame(); card.setStyleSheet("QFrame{background:#1a1a2e;border:1px solid #2a2a44;border-radius:12px;}")
        cl=QGridLayout(card); cm=m.scale(20,xs=10)
        cl.setContentsMargins(cm,m.scale(16,xs=8),cm,m.scale(16,xs=8)); cl.setHorizontalSpacing(cm); cl.setVerticalSpacing(m.scale(8,xs=4))
        def irow(r,lb,vl,col2):
            ll=QLabel(lb); ll.setStyleSheet(f"color:#555577;font-size:{m.scale(12,xs=8)}px;font-weight:bold;")
            vv=QLabel(vl); vv.setStyleSheet(f"color:{col2};font-size:{m.scale(13,xs=9)}px;"); vv.setWordWrap(True)
            cl.addWidget(ll,r,0); cl.addWidget(vv,r,1)
        try: dt=datetime.fromisoformat(info.get("saved_at","")); sf=dt.strftime("%d %b %Y  %H:%M:%S")
        except: sf=info.get("saved_at","")
        irow(0,"SESSION",info.get("session_name","?"),"#a78bfa")
        irow(1,"SAVED",sf,"#64d8cb")
        irow(2,"STEPS",f"{info.get('steps_count',0)} test steps","#f59e0b")
        lay.addWidget(card)

        br=QHBoxLayout(); br.setSpacing(m.scale(12,xs=6))
        disc=QPushButton("🗑  Discard"); disc.setStyleSheet("QPushButton{background:#2a1a1a;color:#ff4757;border:1px solid #ff4757;}QPushButton:hover{background:#3a2020;}")
        disc.clicked.connect(self.reject); br.addWidget(disc)
        rec=QPushButton("✨  Recover Session"); rec.setStyleSheet("QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #7c3aed,stop:1 #a78bfa);color:white;}QPushButton:hover{background:#8b4cf5;}")
        rec.clicked.connect(self.accept); br.addWidget(rec)
        lay.addLayout(br)


# ═══════════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ═══════════════════════════════════════════════════════════════════

class QADocumentationAssistant(QMainWindow):
    """Main application window — v3.2 STEP EDITOR EDITION"""

    def __init__(self, auth=None):
        super().__init__()
        self.auth = auth
        self._m = metrics()
        self.session_manager   = SessionManager()
        self.notifier          = NotificationManager(self)
        self.ai_processor      = AIProcessor()
        self.export_engine     = ExportEngine(ai_processor=self.ai_processor)
        # ─── v4.0 enterprise managers ───────────────────────────────
        if _V4_OK:
            self.storage_manager  = StorageManager(get_base_path())
            self.theme_manager    = ThemeManager(os.path.join(get_base_path(), "theme_settings.json"))
            self.notif_center     = NotificationCenter(self.notifier)
            self.global_search    = GlobalSearch(self.session_manager.storage_path)
            self.defect_assistant = DefectAssistant(ai_processor=self.ai_processor)
            self.update_manager   = UpdateManager(APP_VERSION, UPDATE_MANIFEST_URL, get_base_path())
            self._dashboard_stats = DashboardStats(self.session_manager.storage_path,
                                                   self.storage_manager.resolve_export_dir())
            # Route every existing notifier.notify(...) into the history store (req 12)
            self.notifier.history_sink = self.notif_center.store
            self.cloud = CloudSync(get_base_path())
            if self.auth is not None and getattr(self.auth,"current_user",None):
                _u=self.auth.current_user
                self.cloud.bind_user(_u.uid, _u.email, getattr(_u,"display_name",""))
                _tok=self.auth.id_token()
                if _tok: self.cloud.set_id_token(_tok)
            self.cloud.bump("logins")
            self.cloud.register_install(APP_VERSION)
            self._cloud_worker = make_worker(self.cloud, APP_VERSION)
            if self._cloud_worker is not None:
                self._cloud_worker.new_broadcast.connect(self._on_broadcast)
                self._cloud_worker.broadcasts_updated.connect(self._on_broadcasts_updated)
                self._cloud_worker.blocked.connect(self._on_blocked)
                self._cloud_worker.start()
                QApplication.instance().aboutToQuit.connect(self._cloud_worker.stop)
        else:
            self.notif_center = None; self.cloud = None
        self.current_session   = None
        self.floating_toolbar  = None
        self._screenshot_tool  = ScreenshotTool()
        self.draft_manager     = DraftManager(get_base_path())
        self._auto_save_worker = AutoSaveWorker(15_000)
        self._auto_save_worker.save_triggered.connect(self._auto_save_draft)
        self._auto_save_worker.start()
        atexit.register(self._emergency_save)
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT,  self._signal_handler)
        sys.excepthook = self._global_exception_handler
        self.setup_ui(); self.setup_tray(); self.setup_shortcuts(); self.load_config()
        register_ui_widget(self)
        QTimer.singleShot(600, self._check_for_draft_recovery)
        if _V4_OK:
            QTimer.singleShot(1800, self._v4_check_updates)

    # ── Crash hooks ─────────────────────────────────────────────
    def _emergency_save(self):
        try:
            if self.current_session and self.current_session.steps:
                self.draft_manager.save_draft(self.current_session)
        except Exception: pass

    def _signal_handler(self, sig, frame): self._emergency_save(); QApplication.quit()

    def _global_exception_handler(self, exc_type, exc_val, exc_tb):
        try:
            if self.current_session and self.current_session.steps:
                self.draft_manager.save_draft(self.current_session)
            with open(os.path.join(get_base_path(),"crash_report.txt"),"w") as f:
                traceback.print_exception(exc_type,exc_val,exc_tb,file=f)
        except Exception: pass
        try:
            _c=getattr(self,"cloud",None)
            if _c: _c.track_event("error", type=getattr(exc_type,"__name__","Exception")); _c.flush()
        except Exception: pass
        sys.__excepthook__(exc_type,exc_val,exc_tb)

    @pyqtSlot()
    def _auto_save_draft(self):
        if self.current_session and self.current_session.steps:
            if self.draft_manager.save_draft(self.current_session):
                self._update_autosave_indicator(True)

    def _update_autosave_indicator(self, ok):
        if hasattr(self,'_autosave_label'):
            ts=datetime.now().strftime("%H:%M"); self._autosave_label.setText(f"💾 {ts}")
            self._autosave_label.setStyleSheet("color:#2ed573;font-size:10px;background:#0a2e1a;border-radius:5px;padding:2px 6px;")
            QTimer.singleShot(4000, lambda: self._autosave_label.setText("💾 ON"))

    def _check_for_draft_recovery(self):
        if not self.draft_manager.has_draft(): self.draft_manager.release_lock(); return
        info=self.draft_manager.get_draft_info()
        if not info: return
        if DraftRecoveryDialog(info,self).exec()==QDialog.DialogCode.Accepted: self._restore_from_draft()
        else: self.draft_manager.discard_draft(); self.draft_manager.release_lock()

    def _restore_from_draft(self):
        draft=self.draft_manager.load_draft()
        if not draft: return
        try:
            name=draft.get("session_name",f"Recovered_{datetime.now().strftime('%H%M%S')}")
            self.current_session=self.session_manager.create_session(name)
            for sd in draft.get("steps",[]):
                img=sd.get("image_path") or None
                if img and not os.path.exists(img): img=None
                step=self.current_session.add_step(img,sd.get("capture_type","full_screen"))
                try: step.timestamp=datetime.fromisoformat(sd.get("timestamp",datetime.now().isoformat()))
                except: pass
                step.description=sd.get("description",""); step.expected_behavior=sd.get("expected_behavior","")
                step.actual_observation=sd.get("actual_observation",""); step.bug_hint=sd.get("bug_hint","")
            self._set_session_active(True); self._spawn_floating_toolbar()
            self.draft_manager.acquire_lock(name); self.refresh_steps_list()
            self.session_manager.save_session(self.current_session)
            count=len(self.current_session.steps)
            self.status_bar.showMessage(f"✅ Recovered '{name}' — {count} steps")
            self._stats_label.setText(f"📊 {name}")
            self.notifier.notify("Session Recovered",f"Restored {count} steps","success")
        except Exception as e: print(f"[Recovery] {e}"); self.notifier.notify("Recovery Failed","Could not restore draft","error")

    # ═══════════════════════════════════════════════════════════════
    #  UI SETUP
    # ═══════════════════════════════════════════════════════════════

    def setup_ui(self):
        m=self._m; self.setWindowTitle("AI QA Documentation Assistant  v3.2")
        screen=QApplication.primaryScreen().availableGeometry()
        win_w=min(int(screen.width()*0.92),1600); win_h=min(int(screen.height()*0.90),960)
        self.setGeometry((screen.width()-win_w)//2,(screen.height()-win_h)//2,win_w,win_h)
        self.setMinimumSize(m.win_min_w,m.win_min_h)
        bf=m.btn_font; lf=m.label_font; bp=m.btn_padding

        self.setStyleSheet(f"""
            QMainWindow,QWidget{{background-color:#080812;color:#e8e8ff;
                font-family:'Segoe UI','SF Pro Text',Arial,sans-serif;font-size:{lf}px;}}
            QPushButton{{background:#12122a;border:1px solid #2a2a5a;border-radius:8px;
                padding:{bp};font-size:{bf}px;font-weight:600;color:#e8e8ff;}}
            QPushButton:hover{{background:#1e1e3e;border-color:#6c63ff;}}
            QPushButton:pressed{{background:#6c63ff;}}
            QPushButton:disabled{{color:#444466;border-color:#1a1a30;background:#0a0a18;}}
            QListWidget{{background:#0d0d1f;border:1px solid #1e1e38;border-radius:8px;padding:4px;}}
            QListWidget::item{{padding:{m.scale(10,xs=5,sm=6,md=8,lg=10)}px 6px;border-radius:6px;margin:1px 0;}}
            QListWidget::item:hover{{background:#1a1a2e;}}
            QListWidget::item:selected{{background:#2a1a4e;border-left:3px solid #6c63ff;}}
            QTextEdit{{background:#0d0d1f;border:1px solid #1e1e38;border-radius:6px;
                padding:7px;font-size:{lf}px;color:#c8c8ee;}}
            QTextEdit:focus{{border-color:#6c63ff;}}
            QGroupBox{{border:1px solid #1e1e38;border-radius:10px;
                margin-top:{m.scale(14,xs=8,sm=10,md=12,lg=14)}px;
                font-weight:700;font-size:{m.scale(12,xs=8,sm=9,md=10,lg=12)}px;color:#7775c8;}}
            QGroupBox::title{{subcontrol-origin:margin;left:10px;padding:0 5px;background:#080812;}}
            QComboBox{{background:#0d0d1f;border:1px solid #1e1e38;border-radius:6px;
                padding:{m.scale(7,xs=3)}px {m.scale(10,xs=5)}px;color:#c8c8ee;font-size:{lf}px;}}
            QComboBox:hover{{border-color:#6c63ff;}}
            QComboBox::drop-down{{border:none;width:20px;}}
            QComboBox QAbstractItemView{{background:#12122a;color:#c8c8ee;
                selection-background-color:#2a1a4e;border:1px solid #2a2a5a;}}
            QCheckBox{{spacing:6px;font-size:{lf}px;color:#8888aa;}}
            QCheckBox::indicator{{width:{m.scale(16,xs=11,sm=12,md=14,lg=16)}px;
                height:{m.scale(16,xs=11,sm=12,md=14,lg=16)}px;
                border:1px solid #2a2a5a;border-radius:3px;background:#0d0d1f;}}
            QCheckBox::indicator:checked{{background:#6c63ff;border-color:#6c63ff;}}
            QScrollBar:vertical{{background:#0a0a18;width:5px;border-radius:3px;}}
            QScrollBar::handle:vertical{{background:#2a2a5a;border-radius:3px;min-height:20px;}}
            QScrollBar::handle:vertical:hover{{background:#6c63ff;}}
            QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{{height:0;}}
            QScrollBar:horizontal{{background:#0a0a18;height:5px;border-radius:3px;}}
            QScrollBar::handle:horizontal{{background:#2a2a5a;border-radius:3px;min-width:20px;}}
            QScrollBar::handle:horizontal:hover{{background:#6c63ff;}}
            QScrollBar::add-line:horizontal,QScrollBar::sub-line:horizontal{{width:0;}}
            QStatusBar{{background:#06060f;border-top:1px solid #1a1a30;
                font-size:{m.scale(11,xs=8,sm=9,md=10,lg=11)}px;}}
            QProgressBar{{background:#12122a;border-radius:3px;border:none;height:5px;color:transparent;}}
            QProgressBar::chunk{{background:#6c63ff;border-radius:3px;}}
            QSplitter::handle{{background:#12122a;}}
            QSplitter::handle:horizontal{{width:2px;}}
            QSplitter::handle:horizontal:hover{{background:#6c63ff;}}
            QTabWidget::pane{{border:1px solid #1e1e38;border-radius:8px;top:-1px;}}
            QTabBar::tab{{background:#0d0d1f;color:#555577;
                padding:{m.scale(8,xs=4,sm=5,md=6,lg=8)}px {m.scale(14,xs=6,sm=8,md=10,lg=14)}px;
                border-radius:6px 6px 0 0;font-size:{lf}px;margin-right:2px;}}
            QTabBar::tab:selected{{background:#12122a;color:#a78bfa;border-bottom:2px solid #6c63ff;}}
            QTabBar::tab:hover{{color:#e8e8ff;}}
            QMenu{{background:#12122a;color:#e8e8ff;border:1px solid #2a2a5a;
                border-radius:8px;padding:4px;font-size:{lf}px;}}
            QMenu::item{{padding:8px 18px 8px 12px;border-radius:5px;}}
            QMenu::item:selected{{background:#2a1a4e;color:#a78bfa;}}
            QMenu::separator{{height:1px;background:#1e1e38;margin:3px 8px;}}
            QToolTip{{background:#1a1a2e;color:#e8e8ff;border:1px solid #2a2a5a;
                border-radius:5px;padding:4px 8px;font-size:{lf}px;}}
        """)

        self._original_qss = self.styleSheet()
        central=QWidget(); self.setCentralWidget(central)
        root=QVBoxLayout(central); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        root.addWidget(self._create_title_bar())

        self._spl=QSplitter(Qt.Orientation.Horizontal); self._spl.setHandleWidth(3); self._spl.setChildrenCollapsible(False)
        left=self._create_left_panel(); center=self._create_center_panel(); right=self._create_right_panel()
        self._right_panel=right
        self._center_stack=QStackedWidget(); self._center_stack.addWidget(center)
        self._page_index={"workspace":0}
        if _V4_OK:
            self._page_index["dashboard"]=self._center_stack.addWidget(self._build_dashboard_page())
            self._page_index["notifications"]=self._center_stack.addWidget(self._build_notifications_page())
            self._page_index["help"]=self._center_stack.addWidget(self._build_help_page())
            self._page_index["settings"]=self._center_stack.addWidget(self._build_settings_page())
        center=self._center_stack
        self._spl.addWidget(left); self._spl.addWidget(center); self._spl.addWidget(right)
        lw=m.left_panel_w; rw=m.right_panel_w; cw=max(200,win_w-lw-rw-30)
        self._spl.setSizes([lw,cw,rw]); self._spl.setStretchFactor(0,0); self._spl.setStretchFactor(1,1); self._spl.setStretchFactor(2,0)

        mw=QWidget(); ml=QHBoxLayout(mw)
        ml.setContentsMargins(m.scale(10,xs=4,sm=6,md=8,lg=10),m.scale(10,xs=4,sm=6,md=8,lg=10),
                              m.scale(10,xs=4,sm=6,md=8,lg=10),m.scale(6,xs=2,sm=3,md=4,lg=6))
        ml.setSpacing(0); ml.addWidget(self._spl); root.addWidget(mw,1)

        self.status_bar=QStatusBar(); self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("  Ready — Start a session to begin")
        self._autosave_label=QLabel("💾 ON")
        self._autosave_label.setStyleSheet("color:#555577;font-size:10px;background:transparent;padding:2px 6px;")
        self.status_bar.addPermanentWidget(self._autosave_label)
        self.progress_bar=QProgressBar(); self.progress_bar.setMaximumWidth(m.scale(180,xs=80,sm=100,md=140,lg=180))
        self.progress_bar.setFixedHeight(5); self.progress_bar.setVisible(False)
        self.status_bar.addPermanentWidget(self.progress_bar)

    # ── Title bar ────────────────────────────────────────────────
    def _create_title_bar(self):
        m=self._m; bar=QFrame(); bar.setFixedHeight(m.title_h)
        bar.setStyleSheet("QFrame{background:#06060f;border-bottom:1px solid #12122a;}")
        lay=QHBoxLayout(bar); mp=m.scale(20,xs=8,sm=10,md=14,lg=20)
        lay.setContentsMargins(mp,0,mp,0); lay.setSpacing(m.scale(8,xs=4,sm=5,md=6,lg=8))
        lo=QLabel("⬛"); lo.setFont(QFont("Segoe UI Emoji",m.scale(18,xs=12,sm=13,md=15,lg=18))); lo.setStyleSheet("color:#6c63ff;"); lay.addWidget(lo)
        t=QLabel("QA  Documentation  Assistant"); t.setFont(QFont("Segoe UI",m.title_font,QFont.Weight.Bold)); t.setStyleSheet("color:#e8e8ff;letter-spacing:1px;"); lay.addWidget(t)
        v=QLabel("v3.2"); v.setStyleSheet(f"color:#6c63ff;font-size:{m.scale(10,xs=7,sm=8,md=9,lg=10)}px;font-weight:bold;background:#12122a;border:1px solid #2a2a5a;border-radius:5px;padding:2px 6px;margin-left:4px;"); lay.addWidget(v)
        lay.addStretch()
        self._global_search_box=QLineEdit(); self._global_search_box.setPlaceholderText("🔎  Search sessions, steps, notes…"); self._global_search_box.setFixedWidth(m.scale(260,xs=120,sm=150,md=200,lg=260)); self._global_search_box.setStyleSheet("QLineEdit{background:#0d0d1f;border:1px solid #2a2a5a;border-radius:8px;padding:5px 10px;color:#c8c8ee;}QLineEdit:focus{border-color:#6c63ff;}"); self._global_search_box.returnPressed.connect(self._run_global_search); lay.addWidget(self._global_search_box); self._stats_label=QLabel("📊  No Active Session"); self._stats_label.setStyleSheet(f"color:#555577;font-size:{m.label_font}px;"); self._stats_label.setSizePolicy(QSizePolicy.Policy.Preferred,QSizePolicy.Policy.Fixed); lay.addWidget(self._stats_label)
        self.ai_status=QLabel("🤖 AI Ready"); self.ai_status.setStyleSheet(f"color:#2ed573;font-size:{m.scale(11,xs=8,sm=9,md=10,lg=11)}px;background:#0a2e1a;border:1px solid #2ed573;border-radius:7px;padding:2px 8px;"); lay.addWidget(self.ai_status)
        self._logout_btn=QPushButton("⎋"); self._logout_btn.setToolTip("Log out"); self._logout_btn.setFixedSize(m.scale(30,xs=24),m.scale(26,xs=20)); self._logout_btn.setCursor(Qt.CursorShape.PointingHandCursor); self._logout_btn.setStyleSheet("QPushButton{background:#1a1a3a;border:1px solid #2a2a5a;border-radius:7px;color:#ff7585;}QPushButton:hover{background:#3a1a2a;border-color:#ff4757;}"); self._logout_btn.clicked.connect(self._logout); lay.addWidget(self._logout_btn)
        return bar

    # ── Left panel ───────────────────────────────────────────────
    def _create_left_panel(self):
        m=self._m; panel=QFrame()
        panel.setMinimumWidth(m.scale(180,xs=140,sm=160,md=170,lg=200))
        panel.setMaximumWidth(m.scale(340,xs=220,sm=260,md=300,lg=360))
        panel.setStyleSheet("QFrame{background:#06060f;border-right:1px solid #12122a;}")
        outer=QVBoxLayout(panel); mp=m.panel_margin; outer.setContentsMargins(mp,mp,mp,mp); outer.setSpacing(0)
        scroll=QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        inner=QWidget(); inner.setStyleSheet("background:transparent;")
        lay=QVBoxLayout(inner); lay.setContentsMargins(0,0,4,0); lay.setSpacing(m.scale(8,xs=4,sm=5,md=6,lg=8))

        def grp(title):
            g=QGroupBox(title); v=QVBoxLayout(g)
            v.setSpacing(m.scale(6,xs=3,sm=4,md=5,lg=6))
            v.setContentsMargins(m.scale(8,xs=4),m.scale(16,xs=10),m.scale(8,xs=4),m.scale(8,xs=4))
            return g,v

        sg,sv=grp("SESSION")
        self.start_btn=self._mk_btn("▶","Start New Session","#6c63ff","#4a3abd"); self.start_btn.clicked.connect(self.start_session); sv.addWidget(self.start_btn)
        self.end_btn=self._mk_btn("⏹","End Session","#ff4757","#cc2f3d"); self.end_btn.clicked.connect(self.end_session); self.end_btn.setEnabled(False); sv.addWidget(self.end_btn)
        lay.addWidget(sg)
        if _V4_OK:
            vg,vv=grp("VIEWS")
            self._nav_btns={}
            for key,ico,txt in [("workspace","🧭","Workspace"),("dashboard","📊","Dashboard"),("notifications","🔔","Notifications"),("help","❓","Help & Support"),("settings","⚙","Settings")]:
                b=self._mk_btn(ico,txt,"#1a1a3a","#2a2a5e"); b.clicked.connect(lambda _,k=key:self._nav_to(k)); vv.addWidget(b); self._nav_btns[key]=b
            lay.addWidget(vg)

        cg,cv=grp("CAPTURE")
        self.full_btn=self._mk_btn("📷","Full Screenshot","#0984e3","#0669b3"); self.full_btn.clicked.connect(self.capture_full); cv.addWidget(self.full_btn)
        self.snip_btn=self._mk_btn("✂","Snip Area","#e17055","#b5573e"); self.snip_btn.clicked.connect(self.capture_snip); cv.addWidget(self.snip_btn)
        self.note_btn=self._mk_btn("📝","Add Note","#f0b429","#c48f1a"); self.note_btn.clicked.connect(self.add_manual_note); cv.addWidget(self.note_btn)
        lay.addWidget(cg)
        if _V4_OK:
            tg,tv=grp("TOOLS")
            self.compare_btn=self._mk_btn("🔬","Compare Screenshots","#8e44ad","#6c3483"); self.compare_btn.clicked.connect(self._open_compare); tv.addWidget(self.compare_btn)
            self.defect_btn=self._mk_btn("🐞","Defect Assistant","#c0392b","#922b21"); self.defect_btn.clicked.connect(self._open_defect_assistant); tv.addWidget(self.defect_btn)
            lay.addWidget(tg)

        stg,stv=grp("SETTINGS")
        stv.addWidget(QLabel("AI Model:"))
        self.ai_model=QComboBox(); self.ai_model.addItems(["Groq Vision (Fast)","Fallback Mode"]); stv.addWidget(self.ai_model)
        self.auto_describe=QCheckBox("Auto-describe after capture"); self.auto_describe.setChecked(True); stv.addWidget(self.auto_describe)
        self.save_local=QCheckBox("Save screenshots locally"); self.save_local.setChecked(True); stv.addWidget(self.save_local)
        self.auto_save_toggle=QCheckBox("Auto-save draft every 15s"); self.auto_save_toggle.setChecked(True); self.auto_save_toggle.stateChanged.connect(self._toggle_autosave); stv.addWidget(self.auto_save_toggle)
        lay.addWidget(stg)

        eg,ev=grp("EXPORT")
        self.export_combo=QComboBox(); self.export_combo.addItems(["HTML Report","PDF Document","Excel Sheet","Word Document","Markdown","Enterprise DOCX"]); ev.addWidget(self.export_combo)
        self.export_btn=self._mk_btn("💾","Export Session","#00cec9","#009b96"); self.export_btn.clicked.connect(self.export_session); self.export_btn.setEnabled(False); ev.addWidget(self.export_btn)
        self.draft_export_btn=self._mk_btn("📄","Save Draft Now","#555577","#3a3a55"); self.draft_export_btn.clicked.connect(self._manual_draft_save); ev.addWidget(self.draft_export_btn)
        lay.addWidget(eg)

        lay.addStretch()
        doc=self._mk_btn("📚","Documentation","#333355","#252540"); doc.clicked.connect(self.show_documentation); lay.addWidget(doc)
        scroll.setWidget(inner); outer.addWidget(scroll)
        return panel

    # ── Center panel ─────────────────────────────────────────────
    def _create_center_panel(self):
        m=self._m; panel=QWidget(); panel.setMinimumWidth(200)
        lay=QVBoxLayout(panel); lay.setContentsMargins(0,0,0,0); lay.setSpacing(m.scale(6,xs=3,sm=4,md=5,lg=6))

        hdr=QHBoxLayout()
        hdr.addWidget(self._lbl("  TEST STEPS TIMELINE",f"color:#555577;letter-spacing:2px;font-size:{m.scale(11,xs=8,sm=9,md=10,lg=11)}px;font-weight:bold;"))
        hdr.addStretch()
        hdr.addWidget(self._lbl("Right-click to edit/move/delete  •  Double-click to annotate",f"color:#333355;font-size:{m.scale(10,xs=7,sm=8)}px;font-style:italic;"))
        self.step_count_badge=QLabel("0 steps")
        self.step_count_badge.setStyleSheet(f"color:#6c63ff;background:#12122a;border:1px solid #2a2a5a;border-radius:7px;padding:2px 8px;font-size:{m.scale(11,xs=8,sm=9,md=10,lg=11)}px;font-weight:bold;")
        hdr.addWidget(self.step_count_badge)
        lay.addLayout(hdr)

        self.steps_list=QListWidget()
        self.steps_list.setSelectionMode(QListWidget.SelectionMode.SingleSelection)
        self.steps_list.itemClicked.connect(self.on_step_selected)
        self.steps_list.itemDoubleClicked.connect(self._on_dbl_click)
        self.steps_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.steps_list.customContextMenuRequested.connect(self._ctx_menu)
        lay.addWidget(self.steps_list,1)

        pf=QFrame(); pf.setMinimumHeight(m.scale(120,xs=80,sm=100,md=110,lg=140)); pf.setMaximumHeight(m.preview_h)
        pf.setStyleSheet("QFrame{background:#0a0a18;border:1px solid #1a1a30;border-radius:10px;}")
        pl=QVBoxLayout(pf); pl.setContentsMargins(0,0,0,0); pl.setSpacing(0)
        ph=QLabel("  🖼  PREVIEW  — double-click a step to open annotation editor")
        ph.setFixedHeight(m.scale(28,xs=20,sm=22,md=24,lg=28))
        ph.setStyleSheet(f"background:#0d0d1f;color:#555577;font-size:{m.scale(10,xs=7,sm=8,md=9,lg=10)}px;font-weight:bold;letter-spacing:1px;border-radius:10px 10px 0 0;padding-left:10px;")
        pl.addWidget(ph)
        self.preview_label=QLabel("Select a step to preview")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setStyleSheet(f"color:#333355;font-size:{m.label_font}px;")
        self.preview_label.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Expanding)
        pl.addWidget(self.preview_label,1); lay.addWidget(pf)
        return panel

    def _lbl(self, text, style):
        l=QLabel(text); l.setStyleSheet(style); return l

    # ── Right panel ──────────────────────────────────────────────
    def _create_right_panel(self):
        m=self._m; panel=QFrame()
        panel.setMinimumWidth(m.scale(220,xs=180,sm=200,md=210,lg=240))
        panel.setMaximumWidth(m.scale(420,xs=280,sm=310,md=360,lg=420))
        panel.setStyleSheet("QFrame{background:#06060f;border-left:1px solid #12122a;}")
        lay=QVBoxLayout(panel); mp=m.panel_margin; lay.setContentsMargins(mp,mp,mp,mp); lay.setSpacing(m.scale(8,xs=4,sm=5,md=6,lg=8))
        lay.addWidget(self._lbl("  🧠  AI ANALYSIS",f"color:#555577;font-size:{m.scale(11,xs=8,sm=9,md=10,lg=11)}px;font-weight:bold;letter-spacing:2px;"))

        tabs=QTabWidget(); tabs.setDocumentMode(True)

        dw=QWidget(); dl=QVBoxLayout(dw); dl.setContentsMargins(6,6,6,6); dl.setSpacing(4)
        self.ai_description=QTextEdit(); self.ai_description.setPlaceholderText("AI-generated description…"); dl.addWidget(self.ai_description)
        tabs.addTab(dw,"📝 Description")

        ew=QWidget(); el=QVBoxLayout(ew); el.setContentsMargins(6,6,6,6); el.setSpacing(4)
        el.addWidget(self._lbl("Expected:",f"color:#8888aa;font-size:{m.label_font}px;"))
        self.expected_text=QTextEdit(); self.expected_text.setPlaceholderText("Expected behavior…"); self.expected_text.setMaximumHeight(m.scale(100,xs=60,sm=70,md=85,lg=100)); el.addWidget(self.expected_text)
        el.addWidget(self._lbl("Actual:",f"color:#8888aa;font-size:{m.label_font}px;"))
        self.actual_text=QTextEdit(); self.actual_text.setPlaceholderText("Actual observation…"); self.actual_text.setMaximumHeight(m.scale(100,xs=60,sm=70,md=85,lg=100)); el.addWidget(self.actual_text)
        tabs.addTab(ew,"🔍 Results")

        bw=QWidget(); bl=QVBoxLayout(bw); bl.setContentsMargins(6,6,6,6)
        self.bug_text=QTextEdit(); self.bug_text.setPlaceholderText("Potential issues detected…"); bl.addWidget(self.bug_text)
        tabs.addTab(bw,"🐛 Bugs")
        lay.addWidget(tabs,1)

        self.update_btn=self._mk_btn("🔄","Refresh AI Analysis","#1a2a4a","#111d33"); self.update_btn.clicked.connect(self.update_current_step_ai); lay.addWidget(self.update_btn)
        self.save_step_btn=self._mk_btn("💾","Save Step Edits","#1a3a2a","#112211"); self.save_step_btn.clicked.connect(self._save_step_edits); lay.addWidget(self.save_step_btn)
        self.edit_img_btn=self._mk_btn("✏","Edit Step Screenshot","#2a1a4a","#3a1a6a"); self.edit_img_btn.setToolTip("Ctrl+E"); self.edit_img_btn.clicked.connect(self._edit_selected_img); lay.addWidget(self.edit_img_btn)
        return panel

    def _mk_btn(self, ico, txt, bg, hv) -> QPushButton:
        m=self._m; b=QPushButton(f"{ico}  {txt}")
        b.setFixedHeight(m.scale(34,xs=26,sm=28,md=30,lg=34))
        b.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Fixed)
        b.setStyleSheet(f"QPushButton{{background:{bg};border:1px solid {hv};border-radius:8px;padding:{m.btn_padding};font-size:{m.btn_font}px;font-weight:600;color:#e8e8ff;text-align:left;}}QPushButton:hover{{background:{hv};}}QPushButton:pressed{{opacity:0.8;}}QPushButton:disabled{{color:#333355;border-color:#111128;background:#0a0a18;}}")
        return b

    def _set_session_active(self, a):
        self.start_btn.setEnabled(not a); self.end_btn.setEnabled(a); self.export_btn.setEnabled(a)

    # ═══════════════════════════════════════════════════════════════
    #  CONTEXT MENU
    # ═══════════════════════════════════════════════════════════════

    def _ctx_menu(self, pos: QPoint):
        item=self.steps_list.itemAt(pos)
        if not item: return
        step=item.data(Qt.ItemDataRole.UserRole)
        row=self.steps_list.row(item); total=self.steps_list.count()
        menu=QMenu(self)

        # Edit / annotate
        if step and step.image_path and os.path.exists(step.image_path):
            a=QAction("✏  Edit / Annotate Screenshot",self); a.triggered.connect(lambda:self._open_editor(step)); menu.addAction(a)
        else:
            a=QAction("📝  Edit Note Text",self); a.triggered.connect(lambda:self._edit_note(step)); menu.addAction(a)

        # Replace / Import
        if step and step.capture_type in ("full_screen","snip"):
            a=QAction("🔄  Replace Screenshot (re-capture)",self); a.triggered.connect(lambda:self._replace_ss(step,row)); menu.addAction(a)
            a=QAction("📁  Import Image from File…",self); a.triggered.connect(lambda:self._import_img(step,row)); menu.addAction(a)

        menu.addSeparator()

        # Move
        au=QAction("⬆  Move Up",self); au.setEnabled(row>0); au.triggered.connect(lambda:self._move(row,row-1)); menu.addAction(au)
        ad=QAction("⬇  Move Down",self); ad.setEnabled(row<total-1); ad.triggered.connect(lambda:self._move(row,row+1)); menu.addAction(ad)
        at=QAction("⏫  Move to Top",self); at.setEnabled(row>0); at.triggered.connect(lambda:self._move(row,0)); menu.addAction(at)
        ab=QAction("⏬  Move to Bottom",self); ab.setEnabled(row<total-1); ab.triggered.connect(lambda:self._move(row,total-1)); menu.addAction(ab)
        menu.addSeparator()

        # Duplicate
        ad2=QAction("📋  Duplicate Step  (Ctrl+D)",self); ad2.triggered.connect(lambda:self._dup(row)); menu.addAction(ad2)
        menu.addSeparator()

        # Delete
        adel=QAction("🗑  Delete Step  (Del)",self)
        adel.triggered.connect(lambda:self._del(row)); menu.addAction(adel)

        menu.exec(self.steps_list.viewport().mapToGlobal(pos))

    # ── Double-click ─────────────────────────────────────────────
    def _on_dbl_click(self, item):
        step=item.data(Qt.ItemDataRole.UserRole)
        if step and step.image_path and os.path.exists(step.image_path):
            self._open_editor(step)
        elif step and step.capture_type=="manual_note":
            self._edit_note(step)

    # ── Image editor ─────────────────────────────────────────────
    def _open_editor(self, step):
        if not step.image_path or not os.path.exists(step.image_path):
            self.notifier.notify("No Image","This step has no screenshot","warning"); return
        dlg=StepImageEditorDialog(step.image_path,self)
        if dlg.exec()==QDialog.DialogCode.Accepted:
            self.session_manager.save_session(self.current_session)
            self.draft_manager.save_draft(self.current_session)
            self.refresh_steps_list(); self._refresh_preview(step)
            self.notifier.notify("Screenshot Updated","Annotations saved","success")
            self.status_bar.showMessage("  ✅ Annotated screenshot saved")

    def _edit_selected_img(self):
        item=self.steps_list.currentItem()
        if not item: self.status_bar.showMessage("  No step selected"); return
        self._open_editor(item.data(Qt.ItemDataRole.UserRole))

    def _edit_note(self, step):
        text,ok=QInputDialog.getMultiLineText(self,"Edit Note","Edit your observation:",step.description or "")
        if ok and text:
            step.description=text; step.actual_observation=text
            self.session_manager.save_session(self.current_session)
            self.draft_manager.save_draft(self.current_session)
            self.refresh_steps_list(); self.status_bar.showMessage("  ✅ Note updated")

    # ── Replace / Import ─────────────────────────────────────────
    def _replace_ss(self, step, row):
        if QMessageBox.question(self,"Replace Screenshot",f"Re-capture Step #{row+1}?\nThis replaces the current screenshot.",
                                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes: return
        new_path=(self._screenshot_tool.capture_full_screen(self.config["save_path"],0)
                  if step.capture_type=="full_screen" else
                  self._screenshot_tool.capture_snipping_area(self.config["save_path"]))
        if new_path:
            step.image_path=new_path
            if self.auto_describe.isChecked():
                a=self.ai_processor.analyze_screenshot(new_path)
                if a: step.description=a.get("description",""); step.expected_behavior=a.get("expected_behavior",""); step.actual_observation=a.get("actual_observation",""); step.bug_hint=a.get("bug_hint","")
            self.session_manager.save_session(self.current_session); self.draft_manager.save_draft(self.current_session)
            self.refresh_steps_list(); self.notifier.notify("Screenshot Replaced",f"Step #{row+1} updated","success")

    def _import_img(self, step, row):
        path,_=QFileDialog.getOpenFileName(self,"Import Image","","Images (*.png *.jpg *.jpeg *.bmp *.webp)")
        if path:
            import shutil
            dest=os.path.join(self.config["save_path"],f"imported_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
            shutil.copy2(path,dest); step.image_path=dest
            self.session_manager.save_session(self.current_session); self.draft_manager.save_draft(self.current_session)
            self.refresh_steps_list(); self._refresh_preview(step)
            self.notifier.notify("Image Imported",f"Step #{row+1} image updated","success")

    # ── Move ─────────────────────────────────────────────────────
    def _move(self, fr, to):
        if not self.current_session: return
        steps=self.current_session.steps
        if 0<=fr<len(steps) and 0<=to<len(steps):
            s=steps.pop(fr); steps.insert(to,s)
            self.session_manager.save_session(self.current_session); self.draft_manager.save_draft(self.current_session)
            self.refresh_steps_list(); self.steps_list.setCurrentRow(to)
            self.on_step_selected(self.steps_list.currentItem())
            self.status_bar.showMessage(f"  ↕ Step moved to position #{to+1}")

    # ── Duplicate ────────────────────────────────────────────────
    def _dup(self, idx):
        if not self.current_session: return
        steps=self.current_session.steps
        if 0<=idx<len(steps):
            orig=steps[idx]; dup=self.current_session.add_step(orig.image_path,orig.capture_type)
            dup.description=orig.description; dup.expected_behavior=orig.expected_behavior
            dup.actual_observation=orig.actual_observation; dup.bug_hint=orig.bug_hint; dup.timestamp=datetime.now()
            steps.remove(dup); steps.insert(idx+1,dup)
            self.session_manager.save_session(self.current_session); self.draft_manager.save_draft(self.current_session)
            self.refresh_steps_list(); self.steps_list.setCurrentRow(idx+1)
            cnt=len(steps); self.step_count_badge.setText(f"{cnt} step{'s' if cnt!=1 else ''}")
            self.notifier.notify("Step Duplicated",f"Copy at position #{idx+2}","success")
            self.status_bar.showMessage(f"  📋 Step #{idx+1} duplicated → #{idx+2}")

    # ── Delete ───────────────────────────────────────────────────
    def _del(self, idx):
        if not self.current_session: return
        steps=self.current_session.steps
        if not (0<=idx<len(steps)): return
        if QMessageBox.question(self,"Delete Step",f"Permanently delete Step #{idx+1}?\nThis cannot be undone.",
                                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes: return
        steps.pop(idx)
        self.session_manager.save_session(self.current_session); self.draft_manager.save_draft(self.current_session)
        self.refresh_steps_list(); cnt=len(steps)
        self.step_count_badge.setText(f"{cnt} step{'s' if cnt!=1 else ''}")
        if cnt==0: self.ai_description.clear(); self.expected_text.clear(); self.actual_text.clear(); self.bug_text.clear(); self.preview_label.clear(); self.preview_label.setText("No steps yet")
        self.notifier.notify("Step Deleted",f"Step #{idx+1} removed","info")
        self.status_bar.showMessage(f"  🗑 Step #{idx+1} deleted — {cnt} remaining")

    # ── Preview ──────────────────────────────────────────────────
    def _refresh_preview(self, step):
        if step and step.image_path and os.path.exists(step.image_path):
            pw=max(self.preview_label.width()-8,100); ph=max(self.preview_label.height()-8,60)
            self.preview_label.setPixmap(QPixmap(step.image_path).scaled(pw,ph,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))

    # ═══════════════════════════════════════════════════════════════
    #  TRAY / SHORTCUTS / CONFIG
    # ═══════════════════════════════════════════════════════════════

    def setup_tray(self):
        self.tray_icon=QSystemTrayIcon(self); self.tray_icon.setIcon(QIcon(get_icon_path()))
        tm=QMenu()
        for l,s in [("Show",self.show),("Start Session",self.start_session),("Save Draft Now",self._manual_draft_save),("End Session",self.end_session)]:
            a=QAction(l,self); a.triggered.connect(s); tm.addAction(a)
        tm.addSeparator(); q=QAction("Quit",self); q.triggered.connect(self.quit_app); tm.addAction(q)
        self.tray_icon.setContextMenu(tm); self.tray_icon.show()

    def setup_shortcuts(self):
        QShortcut(QKeySequence("Ctrl+Shift+S"),self,self.start_session)
        QShortcut(QKeySequence("Ctrl+Shift+E"),self,self.end_session)
        QShortcut(QKeySequence("Ctrl+Shift+F"),self,self.capture_full)
        QShortcut(QKeySequence("Ctrl+Shift+X"),self,self.capture_snip)
        QShortcut(QKeySequence("Ctrl+Shift+N"),self,self.add_manual_note)
        QShortcut(QKeySequence("Ctrl+S"),      self,self._manual_draft_save)
        QShortcut(QKeySequence("Ctrl+E"),      self,self._edit_selected_img)
        QShortcut(QKeySequence("Ctrl+D"),      self,lambda: self._dup(self.steps_list.currentRow()))
        QShortcut(QKeySequence("Delete"),      self,lambda: self._del(self.steps_list.currentRow()))
        QShortcut(QKeySequence("Ctrl+Up"),     self,lambda: self._move(self.steps_list.currentRow(), self.steps_list.currentRow()-1))
        QShortcut(QKeySequence("Ctrl+Down"),   self,lambda: self._move(self.steps_list.currentRow(), self.steps_list.currentRow()+1))

    def load_config(self):
        self.config={"groq_api_key":os.environ.get("GROQ_API_KEY",""),"save_path":os.path.join(get_base_path(),"sessions")}
        os.makedirs(self.config["save_path"],exist_ok=True)

    def _toggle_autosave(self,state):
        self._auto_save_worker.interval_ms=15_000 if state==Qt.CheckState.Checked.value else 999_999_999

    def _manual_draft_save(self):
        if self.current_session and self.current_session.steps:
            ok=self.draft_manager.save_draft(self.current_session); self.status_bar.showMessage("Draft saved!" if ok else "Draft save failed"); self._update_autosave_indicator(ok)
        else: self.status_bar.showMessage("No active session to save.")

    # ═══════════════════════════════════════════════════════════════
    #  SESSION
    # ═══════════════════════════════════════════════════════════════

    def start_session(self):
        name=f"QA_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.current_session=self.session_manager.create_session(name)
        self._set_session_active(True); self.draft_manager.acquire_lock(name); self._spawn_floating_toolbar()
        self.status_bar.showMessage(f"  Session started: {name}"); self._stats_label.setText(f"📊 {name}")
        self.notifier.notify("Session Started","Ready to capture","success")
        self._track("session_start", counter="sessions")

    def _spawn_floating_toolbar(self):
        self.floating_toolbar=FloatingToolbar()
        self.floating_toolbar.sig_full_screen.connect(self.capture_full_with_screen)
        self.floating_toolbar.sig_snip.connect(self.capture_snip)
        self.floating_toolbar.sig_note.connect(self.add_manual_note)
        self.floating_toolbar.sig_all_screens.connect(self._capture_all_screens)
        self.floating_toolbar.show(); self._screenshot_tool.floating_toolbar=self.floating_toolbar

    def end_session(self):
        if self.current_session:
            self.draft_manager.save_draft(self.current_session); self.session_manager.end_current_session()
            self._set_session_active(False)
            if self.floating_toolbar:
                unregister_ui_widget(self.floating_toolbar); self.floating_toolbar.close(); self.floating_toolbar=None; self._screenshot_tool.floating_toolbar=None
            self.draft_manager.release_lock(); self.draft_manager.discard_draft()
            cnt=len(self.current_session.steps); self.status_bar.showMessage(f"  Session ended — {cnt} steps captured")
            self.step_count_badge.setText("0 steps"); self.refresh_steps_list()
            self.notifier.notify("Session Ended",f"Captured {cnt} steps","info")

    # ═══════════════════════════════════════════════════════════════
    #  CAPTURE
    # ═══════════════════════════════════════════════════════════════

    def capture_full(self): self.capture_full_with_screen(0)

    def capture_full_with_screen(self, idx=0):
        if not self.current_session: self.notifier.notify("No Active Session","Start a session first","warning"); return
        p=self._screenshot_tool.capture_full_screen(self.config["save_path"],idx)
        if p: self.process_captured_image(p,"full_screen")

    def _capture_all_screens(self):
        if not self.current_session: return
        for p in self._screenshot_tool.capture_all_screens(self.config["save_path"]): self.process_captured_image(p,"full_screen")

    def capture_snip(self):
        if not self.current_session: self.notifier.notify("No Active Session","Start a session first","warning"); return
        p=self._screenshot_tool.capture_snipping_area(self.config["save_path"])
        if p: self.process_captured_image(p,"snip")
        else: self.status_bar.showMessage("  Snip cancelled")

    def process_captured_image(self, image_path, capture_type):
        if not self.current_session: return
        step=self.current_session.add_step(image_path,capture_type)
        if self.auto_describe.isChecked():
            self.status_bar.showMessage("  🤖 AI analysing…"); self.progress_bar.setVisible(True); self.progress_bar.setValue(50)
            a=self.ai_processor.analyze_screenshot(image_path)
            if a: step.description=a.get("description",""); step.expected_behavior=a.get("expected_behavior",""); step.actual_observation=a.get("actual_observation",""); step.bug_hint=a.get("bug_hint",""); self.session_manager.save_session(self.current_session)
            self.progress_bar.setVisible(False); self.status_bar.showMessage("  ✅ Screenshot processed")
            self._track("ai_analysis", counter="ai_analyses")
        self.draft_manager.save_draft(self.current_session); self._update_autosave_indicator(True)
        self.refresh_steps_list(); cnt=len(self.current_session.steps)
        self.step_count_badge.setText(f"{cnt} step{'s' if cnt!=1 else ''}")
        self.notifier.notify("Screenshot Captured",f"Step {cnt} added — right-click to edit","success")
        self._maybe_live_refresh()
        self._track("screenshot_capture", counter="screenshots")

    def add_manual_note(self):
        if not self.current_session: self.notifier.notify("No Active Session","Start a session first","warning"); return
        note,ok=QInputDialog.getMultiLineText(self,"Add Manual Note","Enter your observation:")
        if ok and note:
            s=self.current_session.add_step(None,"manual_note"); s.description=note; s.expected_behavior="Manual observation"; s.actual_observation=note
            self.session_manager.save_session(self.current_session); self.draft_manager.save_draft(self.current_session)
            self.refresh_steps_list(); cnt=len(self.current_session.steps); self.step_count_badge.setText(f"{cnt} steps")
            self.notifier.notify("Note Added","Manual note saved","success")

    # ═══════════════════════════════════════════════════════════════
    #  STEPS LIST
    # ═══════════════════════════════════════════════════════════════

    def refresh_steps_list(self):
        m=self._m; self.steps_list.clear()
        if not self.current_session: return
        icon_map={"full_screen":"📷","snip":"✂","manual_note":"📝"}
        item_h=m.scale(46,xs=32,sm=34,md=38,lg=46)
        for i,step in enumerate(self.current_session.steps,1):
            iw=QWidget(); iw.setStyleSheet("background:transparent;")
            row=QHBoxLayout(iw); row.setContentsMargins(6,3,6,3); row.setSpacing(m.scale(8,xs=4,sm=5,md=6,lg=8))

            il=QLabel(icon_map.get(step.capture_type,"📸")); il.setFixedWidth(m.scale(20,xs=14,sm=16,md=18,lg=20)); il.setFont(QFont("Segoe UI Emoji",m.scale(12,xs=8,sm=9,md=10,lg=12))); row.addWidget(il)
            nl=QLabel(f"#{i:02d}"); nl.setFixedWidth(m.scale(28,xs=18,sm=20,md=22,lg=28)); nl.setStyleSheet(f"color:#6c63ff;font-size:{m.scale(11,xs=8,sm=9,md=10,lg=11)}px;font-weight:bold;"); row.addWidget(nl)

            mc=m.scale(55,xs=22,sm=28,md=40,lg=55); rd=step.description or "No description"
            dl=QLabel((rd[:mc]+"…") if len(rd)>mc else rd); dl.setStyleSheet(f"color:#c8c8ee;font-size:{m.label_font}px;"); dl.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Preferred); row.addWidget(dl,1)

            if step.bug_hint and step.bug_hint not in ("No obvious issues","No obvious issues detected",""):
                bw=QLabel("⚠"); bw.setStyleSheet(f"color:#ffa502;font-size:{m.label_font}px;"); bw.setToolTip(step.bug_hint[:80]); row.addWidget(bw)

            if step.image_path and os.path.exists(step.image_path):
                eb=QToolButton(); eb.setText("✏"); eb.setFixedSize(22,22); eb.setToolTip("Annotate screenshot")
                eb.setStyleSheet("QToolButton{background:#1a1a3a;border:1px solid #2a2a5a;border-radius:4px;color:#7775c8;font-size:10px;}QToolButton:hover{background:#2a1a5e;border-color:#a78bfa;color:#a78bfa;}")
                eb.clicked.connect(lambda _,s=step: self._open_editor(s)); row.addWidget(eb)

            tl=QLabel(step.timestamp.strftime("%H:%M:%S")); tl.setStyleSheet(f"color:#333355;font-size:{m.scale(10,xs=7,sm=8,md=9,lg=10)}px;font-family:monospace;"); row.addWidget(tl)

            item=QListWidgetItem(self.steps_list); item.setSizeHint(QSize(0,item_h)); item.setData(Qt.ItemDataRole.UserRole,step)
            self.steps_list.addItem(item); self.steps_list.setItemWidget(item,iw)

    def on_step_selected(self, item):
        if not item: return
        step=item.data(Qt.ItemDataRole.UserRole)
        if not step: return
        self.ai_description.setText(step.description or ""); self.expected_text.setText(step.expected_behavior or "")
        self.actual_text.setText(step.actual_observation or ""); self.bug_text.setText(step.bug_hint or "")
        if step.image_path and os.path.exists(step.image_path): self._refresh_preview(step)
        else: self.preview_label.clear(); self.preview_label.setText("No image preview")

    def _save_step_edits(self):
        item=self.steps_list.currentItem()
        if not item: return
        step=item.data(Qt.ItemDataRole.UserRole)
        if step:
            step.description=self.ai_description.toPlainText(); step.expected_behavior=self.expected_text.toPlainText()
            step.actual_observation=self.actual_text.toPlainText(); step.bug_hint=self.bug_text.toPlainText()
            self.session_manager.save_session(self.current_session); self.draft_manager.save_draft(self.current_session)
            self.refresh_steps_list(); self.status_bar.showMessage("  ✅ Step edits saved")

    def update_current_step_ai(self):
        item=self.steps_list.currentItem()
        if not item: return
        step=item.data(Qt.ItemDataRole.UserRole)
        if step and step.image_path:
            self.status_bar.showMessage("  🤖 Re-analysing…")
            a=self.ai_processor.analyze_screenshot(step.image_path)
            if a:
                step.description=a.get("description",""); step.expected_behavior=a.get("expected_behavior","")
                step.actual_observation=a.get("actual_observation",""); step.bug_hint=a.get("bug_hint","")
                self.session_manager.save_session(self.current_session); self.draft_manager.save_draft(self.current_session)
                self.ai_description.setText(step.description); self.expected_text.setText(step.expected_behavior)
                self.actual_text.setText(step.actual_observation); self.bug_text.setText(step.bug_hint)
                self.refresh_steps_list(); self.notifier.notify("AI Updated","Analysis refreshed","success")
                self._track("ai_analysis", counter="ai_analyses")
            self.status_bar.showMessage("  Ready")

    # ═══════════════════════════════════════════════════════════════
    #  EXPORT
    # ═══════════════════════════════════════════════════════════════

    def export_session(self):
        if not self.current_session: return
        fmt_map={"HTML Report":("HTML Files (*.html)",".html"),"PDF Document":("PDF Files (*.pdf)",".pdf"),
                 "Excel Sheet":("Excel Files (*.xlsx)",".xlsx"),"Word Document":("Word Files (*.docx)",".docx"),
                 "Markdown":("Markdown Files (*.md)",".md"),"Enterprise DOCX":("Word Files (*.docx)",".docx")}
        ef=self.export_combo.currentText(); ft,ext=fmt_map.get(ef,("All Files (*.*)", ""))
        fp,_=QFileDialog.getSaveFileName(self,f"Export {ef}",os.path.join(self.storage_manager.resolve_export_dir(), f"{self.current_session.session_name}{ext}") if _V4_OK else f"{self.current_session.session_name}{ext}",ft)
        if not fp: return
        self.status_bar.showMessage(f"  Exporting {ef}…"); self.progress_bar.setVisible(True)
        for v in range(0,80,20): self.progress_bar.setValue(v); QApplication.processEvents()
        ok=self.export_engine.export_session(self.current_session,fp,ef)
        self.progress_bar.setValue(100); QApplication.processEvents(); self.progress_bar.setVisible(False)
        if ok: self.notifier.notify("Export Complete",f"Saved: {os.path.basename(fp)}","success"); self.status_bar.showMessage(f"  ✅ Exported to {fp}")
        if ok:
            self._track("export", fmt=ef, counter="exports")
            _c=getattr(self,"cloud",None)
            if _c:
                _c.log_export(ef)
                if ef in ("Word Document","Enterprise DOCX"): _c.bump("docx_exports")
                elif ef=="PDF Document": _c.bump("pdf_exports")
                _c.flush()
        else:  self.notifier.notify("Export Failed","Check console for errors","error"); self.status_bar.showMessage("  ❌ Export failed")

    # ═══════════════════════════════════════════════════════════════
    #  RESIZE
    # ═══════════════════════════════════════════════════════════════

    def resizeEvent(self, event):
        super().resizeEvent(event)
        item=self.steps_list.currentItem() if hasattr(self,'steps_list') else None
        if item:
            step=item.data(Qt.ItemDataRole.UserRole)
            if step and step.image_path and os.path.exists(step.image_path): self._refresh_preview(step)

    # ═══════════════════════════════════════════════════════════════
    #  LIFECYCLE
    # ═══════════════════════════════════════════════════════════════

    def quit_app(self):
        self._emergency_save()
        if self.current_session and self.current_session.steps:
            if QMessageBox.question(self,"Confirm Quit",f"Session in progress ({len(self.current_session.steps)} steps).\nA draft has been auto-saved. Quit anyway?",
                                    QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)==QMessageBox.StandardButton.Yes: self._cleanup_and_quit()
        else: self._cleanup_and_quit()

    def _cleanup_and_quit(self):
        self._auto_save_worker.stop()
        if self.floating_toolbar: self.floating_toolbar.close()
        QApplication.quit()

    def closeEvent(self, event):

        self._maybe_ask_feedback()
        if self.current_session and self.current_session.steps:
            self.draft_manager.save_draft(self.current_session)
            if QMessageBox.question(self,"Exit — Draft Saved",f"Session has {len(self.current_session.steps)} steps.\n✅ Draft auto-saved — recover it next launch.\n\nExit now?",
                                    QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)==QMessageBox.StandardButton.Yes:
                self._auto_save_worker.stop()
                if self.floating_toolbar: unregister_ui_widget(self.floating_toolbar); self.floating_toolbar.close()
                unregister_ui_widget(self); event.accept()
            else: event.ignore()
        else:
            self._auto_save_worker.stop(); self.draft_manager.release_lock()
            if self.floating_toolbar: self.floating_toolbar.close()
            unregister_ui_widget(self); event.accept()


    # ═══════════════════════════════════════════════════════════════
    #  v4.0 ENTERPRISE INTEGRATION
    # ═══════════════════════════════════════════════════════════════
    def _nav_to(self, key):
        idx=self._page_index.get(key,0); self._center_stack.setCurrentIndex(idx)
        if hasattr(self,"_right_panel"): self._right_panel.setVisible(key=="workspace")
        if key=="dashboard": self._refresh_dashboard()
        if key=="notifications": self._notif_refresh()
        if key=="help": self._refresh_help()

    def _build_dashboard_page(self):
        w=QWidget(); v=QVBoxLayout(w); v.setContentsMargins(14,14,14,14); v.setSpacing(10)
        hdr=QHBoxLayout(); hdr.addWidget(self._lbl("  📊  DASHBOARD","color:#a78bfa;font-size:15px;font-weight:bold;letter-spacing:2px;")); hdr.addStretch()
        rb=self._mk_btn("🔄","Refresh","#1a1a3a","#2a2a5e"); rb.clicked.connect(self._refresh_dashboard); hdr.addWidget(rb); v.addLayout(hdr)
        self._dash_grid_host=QWidget(); self._dash_grid=QGridLayout(self._dash_grid_host); self._dash_grid.setSpacing(10); v.addWidget(self._dash_grid_host)
        v.addWidget(self._lbl("  RECENT SESSIONS","color:#555577;font-size:11px;font-weight:bold;letter-spacing:1px;"))
        self._dash_recent=QListWidget(); v.addWidget(self._dash_recent,1)
        QTimer.singleShot(0,self._refresh_dashboard); return w

    def _refresh_dashboard(self):
        if not hasattr(self,"_dash_grid"): return
        data=self._dashboard_stats.compute()
        if self.current_session:
            data["sessions_created"]+=1
            data["screenshots_captured"]+=sum(1 for s in self.current_session.steps if s.image_path)
            data["defects_identified"]+=sum(1 for s in self.current_session.steps if s.bug_hint and "no obvious" not in s.bug_hint.lower())
        while self._dash_grid.count():
            it=self._dash_grid.takeAt(0); ww=it.widget()
            if ww: ww.deleteLater()
        cards=[("Sessions",data["sessions_created"],"#6c63ff"),("Screenshots",data["screenshots_captured"],"#0984e3"),
               ("Defects",data["defects_identified"],"#ff4757"),("AI Analyses",data["ai_analyses_performed"],"#a78bfa"),
               ("Reports",data["reports_generated"],"#00cec9"),("Avg Steps",data["avg_steps_per_session"],"#f0b429")]
        for i,(lbl,val,col) in enumerate(cards):
            card=QFrame(); card.setStyleSheet("QFrame{background:#0d0d1f;border:1px solid #1e1e38;border-radius:12px;}")
            cl=QVBoxLayout(card); cl.setContentsMargins(16,14,16,14)
            vlbl=QLabel(str(val)); vlbl.setStyleSheet(f"color:{col};font-size:26px;font-weight:bold;")
            tlbl=QLabel(lbl); tlbl.setStyleSheet("color:#8888aa;font-size:11px;")
            cl.addWidget(vlbl); cl.addWidget(tlbl); self._dash_grid.addWidget(card,i//3,i%3)
        self._dash_recent.clear()
        for r in data["recent_sessions"]: self._dash_recent.addItem(f"  📁  {r['name']}   —   {r['steps']} steps")

    def _build_notifications_page(self):
        w=QWidget(); v=QVBoxLayout(w); v.setContentsMargins(14,14,14,14); v.setSpacing(10)
        hdr=QHBoxLayout(); hdr.addWidget(self._lbl("  🔔  NOTIFICATION CENTER","color:#a78bfa;font-size:15px;font-weight:bold;letter-spacing:2px;")); hdr.addStretch()
        clr=self._mk_btn("🗑","Clear All","#ff4757","#cc2f3d"); clr.clicked.connect(self._notif_clear); hdr.addWidget(clr); v.addLayout(hdr)
        ctr=QHBoxLayout()
        self._notif_search=QLineEdit(); self._notif_search.setPlaceholderText("Search notifications…"); self._notif_search.textChanged.connect(self._notif_refresh); ctr.addWidget(self._notif_search,1)
        self._notif_filter=QComboBox(); self._notif_filter.addItems(["all","info","success","warning","error"]); self._notif_filter.currentTextChanged.connect(self._notif_refresh); ctr.addWidget(self._notif_filter)
        v.addLayout(ctr)
        self._notif_list=QListWidget(); v.addWidget(self._notif_list,1)
        if self.notif_center: self.notif_center.store.subscribe(self._notif_refresh)
        QTimer.singleShot(0,self._notif_refresh); return w

    def _notif_refresh(self,*a):
        if not hasattr(self,"_notif_list") or not self.notif_center: return
        q=self._notif_search.text() if hasattr(self,"_notif_search") else ""
        items=self.notif_center.store.search(q)
        lvl=self._notif_filter.currentText() if hasattr(self,"_notif_filter") else "all"
        if lvl!="all": items=[n for n in items if n.level==lvl]
        self._notif_list.clear()
        icons={"info":"ℹ","success":"✅","warning":"⚠","error":"❌","progress":"⏳","action":"⚡"}
        for n in items: self._notif_list.addItem(f"  {icons.get(n.level,'•')}  {n.title} — {n.message}    ({n.age_text()})")

    def _notif_clear(self):
        if self.notif_center: self.notif_center.store.clear(); self._notif_refresh()

    def _build_settings_page(self):
        w=QWidget(); root=QVBoxLayout(w); root.setContentsMargins(0,0,0,0)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setStyleSheet("QScrollArea{border:none;}")
        inner=QWidget(); v=QVBoxLayout(inner); v.setContentsMargins(14,14,14,14); v.setSpacing(12)
        v.addWidget(self._lbl("  ⚙  SETTINGS","color:#a78bfa;font-size:15px;font-weight:bold;letter-spacing:2px;"))
        tg=QGroupBox("APPEARANCE — THEME"); tv=QVBoxLayout(tg)
        tv.addWidget(QLabel("Application theme (applies instantly to every screen):"))
        self._theme_combo=QComboBox(); self._theme_combo.addItem("QA Dark (default)")
        self._theme_combo.addItems([tn.replace("_"," ").title() for tn in self.theme_manager.available()])
        self._theme_combo.currentTextChanged.connect(self._apply_theme); tv.addWidget(self._theme_combo); v.addWidget(tg)
        og=QGroupBox("STORAGE — ONEDRIVE / SHAREPOINT"); ov=QVBoxLayout(og)
        ov.addWidget(QLabel("Export destination (synced by the OneDrive client — no login required):"))
        self._storage_combo=QComboBox(); self._storage_locs=self.storage_manager.detect_all()
        for loc in self._storage_locs: self._storage_combo.addItem(f"{loc.label}  —  {loc.path}")
        ov.addWidget(self._storage_combo)
        bh=QHBoxLayout()
        ab=self._mk_btn("✔","Use Selected","#00cec9","#009b96"); ab.clicked.connect(self._apply_storage); bh.addWidget(ab)
        cb=self._mk_btn("📂","Custom Folder…","#555577","#3a3a55"); cb.clicked.connect(self._pick_custom_storage); bh.addWidget(cb)
        ov.addLayout(bh)
        self._storage_status=QLabel(f"Current: {self.storage_manager.resolve_export_dir()}"); self._storage_status.setStyleSheet("color:#2ed573;font-size:11px;"); ov.addWidget(self._storage_status); v.addWidget(og)
        ug=QGroupBox("UPDATES"); uv=QVBoxLayout(ug)
        uv.addWidget(QLabel(f"Current version: {APP_VERSION}"))
        uc=self._mk_btn("⬇","Check for Updates Now","#6c63ff","#4a3abd"); uc.clicked.connect(lambda: self._v4_check_updates(manual=True)); uv.addWidget(uc)
        self._update_status=QLabel("Auto-check runs ~2s after startup."); self._update_status.setStyleSheet("color:#8888aa;font-size:11px;"); uv.addWidget(self._update_status); v.addWidget(ug)
        v.addStretch(); scroll.setWidget(inner); root.addWidget(scroll); return w

    def _apply_theme(self, label):
        app=QApplication.instance()
        if label.startswith("QA Dark"):
            app.setStyleSheet(""); self.setStyleSheet(self._original_qss); return
        name=label.lower().replace(" ","_")
        try:
            qss=self.theme_manager.qss_for(name); self.setStyleSheet(""); app.setStyleSheet(qss)
            self.theme_manager.current=name; self.theme_manager._save(); self.notifier.notify("Theme Applied",label,"success")
        except Exception as e:
            self.notifier.notify("Theme Error",str(e),"error")

    def _apply_storage(self):
        i=self._storage_combo.currentIndex()
        if 0<=i<len(self._storage_locs):
            loc=self._storage_locs[i]; self.storage_manager.set_destination(loc.kind,loc.path)
            self._storage_status.setText(f"Current: {self.storage_manager.resolve_export_dir()}"); self.notifier.notify("Storage Updated",loc.label,"success")

    def _pick_custom_storage(self):
        d=QFileDialog.getExistingDirectory(self,"Choose export folder")
        if d:
            self.storage_manager.set_destination("custom",d)
            self._storage_status.setText(f"Current: {self.storage_manager.resolve_export_dir()}"); self.notifier.notify("Storage Updated","Custom folder set","success")

    def _run_global_search(self):
        q=self._global_search_box.text().strip()
        if not q: return
        self.global_search.reindex(); hits=self.global_search.search(q)
        dlg=QDialog(self); dlg.setWindowTitle(f"Search: {q}"); dlg.resize(560,420)
        lay=QVBoxLayout(dlg); lay.addWidget(QLabel(f"  {len(hits)} result(s) for “{q}”"))
        lst=QListWidget(); lay.addWidget(lst)
        for h in hits: lst.addItem(f"  [{h.field}]  {h.session_name}  —  {h.snippet}")
        if not hits: lst.addItem("  No matches found.")
        dlg.exec()

    def _open_compare(self):
        if not _V4_OK: return
        a,_=QFileDialog.getOpenFileName(self,"Select BEFORE screenshot","","Images (*.png *.jpg *.jpeg)")
        if not a: return
        b,_=QFileDialog.getOpenFileName(self,"Select AFTER screenshot","","Images (*.png *.jpg *.jpeg)")
        if not b: return
        try:
            res=self._screenshot_tool.compare(a,b,self.storage_manager.resolve_export_dir())
        except Exception as e:
            QMessageBox.critical(self,"Comparison Failed",str(e)); return
        extra=f"\n\nOverlay saved: {res.overlay_path}" if res.overlay_path else ""
        QMessageBox.information(self,"Screenshot Comparison",res.summary()+extra)
        self.notifier.notify("Comparison Complete",f"{len(res.regions)} region(s) changed","info")

    def _open_defect_assistant(self):
        if not _V4_OK: return
        item=self.steps_list.currentItem()
        if not item or not self.current_session:
            QMessageBox.warning(self,"Defect Assistant","Select a step in the timeline first."); return
        step=item.data(Qt.ItemDataRole.UserRole)
        rep=self.defect_assistant.build(self.current_session,step); txt=rep.to_markdown()
        dlg=QDialog(self); dlg.setWindowTitle(f"Defect — {rep.severity} / {rep.priority}"); dlg.resize(560,520)
        lay=QVBoxLayout(dlg); te=QTextEdit(); te.setPlainText(txt); lay.addWidget(te)
        cp=self._mk_btn("📋","Copy to Clipboard","#00cec9","#009b96")
        cp.clicked.connect(lambda: (QApplication.clipboard().setText(txt), self.notifier.notify("Copied","Defect report on clipboard","success")))
        lay.addWidget(cp); dlg.exec()

    def _v4_check_updates(self, manual=False):
        if not _V4_OK: return
        try: info=self.update_manager.check_for_update()
        except Exception: info=None
        if info:
            if hasattr(self,"_update_status"): self._update_status.setText(f"Version {info.version} available")
            dlg=UpdateModal(info.version, info.notes or "A new version is available.", self); dlg.exec()
            if dlg.choice==UpdateModal.UPDATE_NOW:
                self._start_update(info)
        elif manual:
            if hasattr(self,"_update_status"): self._update_status.setText("You are up to date.")
            self.notifier.notify("Up to Date",f"v{APP_VERSION} is current","info")

    def _start_update(self, info=None):
        if not _V4_OK: return
        from PyQt6.QtWidgets import QApplication as _A, QMessageBox
        if info is None:
            try: info=self.update_manager.check_for_update()
            except Exception: info=None
        if not info:
            self.notifier.notify("Up to Date", f"v{APP_VERSION} is current", "info"); return
        self.notifier.notify("Downloading update", f"v{info.version}…", "info")
        def prog(done,total):
            if total:
                try: self.status_bar.showMessage(f"  ⬇ Downloading update {int(done*100/total)}%")
                except Exception: pass
            _A.processEvents()
        try: zip_path=self.update_manager.download_update(info, prog)
        except Exception: zip_path=None
        if not zip_path:
            self.notifier.notify("Update Failed","Could not download or verify the update.","error"); return
        ok=False
        try: ok=self.update_manager.stage(zip_path) and self.update_manager.apply_on_restart()
        except Exception: ok=False
        if ok:
            self._track("update_now", version=info.version)
            self.notifier.notify("Update Installed", f"v{info.version} ready — restart to finish.", "success")
            if QMessageBox.question(self,"Restart","Update installed. Restart now to apply?",
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)==QMessageBox.StandardButton.Yes:
                self._relaunch()
        else:
            self.notifier.notify("Update Failed","Could not apply the update (changes were rolled back).","error")

    def _relaunch(self):
        import sys, os
        self._feedback_asked=True
        try:
            if getattr(self,"_cloud_worker",None): self._cloud_worker.stop()
        except Exception: pass
        try:
            os.execl(sys.executable, sys.executable, *sys.argv)
        except Exception:
            from PyQt6.QtWidgets import QApplication; QApplication.quit()

    def _maybe_live_refresh(self):
        if hasattr(self,"_center_stack") and hasattr(self,"_page_index"):
            if self._center_stack.currentIndex()==self._page_index.get("dashboard",-1):
                self._refresh_dashboard()

    # ═══════════════════════════════════════════════════════════════
    #  v4.0 CLOUD / HELP & SUPPORT / FEEDBACK / TELEMETRY
    # ═══════════════════════════════════════════════════════════════
    def _track(self, name, counter=None, **props):
        c=getattr(self,"cloud",None)
        if not c: return
        try:
            c.track_event(name, **props)
            if counter: c.bump(counter)
        except Exception: pass

    def _on_blocked(self):
        if getattr(self, "_blocked_shown", False): return
        self._blocked_shown = True
        try:
            if getattr(self, "_cloud_worker", None): self._cloud_worker.stop()
        except Exception: pass
        try:
            if getattr(self, "tray_icon", None): self.tray_icon.hide()
        except Exception: pass
        try:
            if getattr(self, "floating_toolbar", None) and self.floating_toolbar:
                self.floating_toolbar.close()
        except Exception: pass
        self._feedback_asked = True
        self.hide()
        try:
            self._blocked_screen = BlockedScreen(getattr(self, "cloud", None),
                                                 getattr(self, "ai_processor", None))
            self._blocked_screen.showFullScreen()
        except Exception:
            from PyQt6.QtWidgets import QApplication as _A
            _A.quit()
    def _build_help_page(self):
        w=QWidget(); root=QVBoxLayout(w); root.setContentsMargins(14,14,14,14); root.setSpacing(10)
        root.addWidget(self._lbl("  ❓  HELP & SUPPORT","color:#a78bfa;font-size:15px;font-weight:bold;letter-spacing:2px;"))
        tabs=QTabWidget(); root.addWidget(tabs,1)
        tabs.addTab(self._help_tab_assistant(), "🤖  AI Assistant")
        tabs.addTab(self._help_tab_support(),   "💬  Live Support")
        tabs.addTab(self._help_tab_news(),      "📢  What's New")
        tabs.addTab(self._help_tab_about(),     "ℹ  About")
        return w

    def _help_tab_assistant(self):
        w=QWidget(); v=QVBoxLayout(w)
        v.addWidget(self._lbl("Ask anything about the tool \u2014 capture, annotate, compare, export\u2026","color:#8888aa;font-size:11px;"))
        self._ai_list=QListWidget(); v.addWidget(self._ai_list,1)
        self._ai_history=[]
        self._ai_list.addItem("\U0001F916  Hi! I'm your QA assistant. Ask me how to use any feature, or tap Tour.")
        row=QHBoxLayout()
        self._ai_input=QLineEdit(); self._ai_input.setPlaceholderText("e.g. How do I export a Word report?")
        self._ai_input.returnPressed.connect(self._ai_send); row.addWidget(self._ai_input,1)
        ask=self._mk_btn("\u27a4","Ask","#6c63ff","#4a3abd"); ask.clicked.connect(self._ai_send); row.addWidget(ask)
        tour=self._mk_btn("\U0001F9ED","Tour","#333355","#252540"); tour.clicked.connect(self._take_tour); row.addWidget(tour)
        v.addLayout(row); return w

    def _ai_send(self):
        q=self._ai_input.text().strip()
        if not q: return
        self._ai_input.clear(); self._ai_list.addItem(f"\U0001F9D1  {q}")
        self._ai_list.addItem("\U0001F916  \u2026thinking\u2026")
        from PyQt6.QtWidgets import QApplication as _A; _A.processEvents()
        try: ans=self.ai_processor.chat(q, self._ai_history)
        except Exception as e: ans=f"Sorry, I couldn't answer ({e})."
        self._ai_list.takeItem(self._ai_list.count()-1)
        self._ai_list.addItem(f"\U0001F916  {ans}"); self._ai_list.scrollToBottom()
        self._ai_history.append({"role":"user","content":q}); self._ai_history.append({"role":"assistant","content":ans})
        self._track("ai_help_query")

    def _take_tour(self):
        self._ai_input.setText("Give me a quick tour of how to use this tool"); self._ai_send()

    def _help_tab_support(self):
        w=QWidget(); v=QVBoxLayout(w)
        v.addWidget(self._lbl("Chat live with the admin. Replies appear here automatically.","color:#8888aa;font-size:11px;"))
        self._chat_list=QListWidget(); v.addWidget(self._chat_list,1)
        row=QHBoxLayout()
        self._chat_input=QLineEdit(); self._chat_input.setPlaceholderText("Type a message to support\u2026")
        self._chat_input.returnPressed.connect(self._support_send); row.addWidget(self._chat_input,1)
        sb=self._mk_btn("\u27a4","Send","#00cec9","#009b96"); sb.clicked.connect(self._support_send); row.addWidget(sb)
        v.addLayout(row)
        self._chat_timer=QTimer(self); self._chat_timer.timeout.connect(self._support_refresh); self._chat_timer.start(2000)
        QTimer.singleShot(300, self._support_refresh); return w

    def _support_send(self):
        t=self._chat_input.text().strip(); c=getattr(self,"cloud",None)
        if not t: return
        if not c or not c.enabled:
            self._chat_list.addItem("\u26a0  Live support needs an internet connection."); return
        self._chat_input.clear(); c.send_chat(t); c.flush(); self._support_refresh()

    def _support_refresh(self):
        c=getattr(self,"cloud",None)
        if not c or not hasattr(self,"_chat_list"): return
        try: msgs=c.fetch_chat()
        except Exception: msgs=[]
        self._chat_list.clear()
        if not msgs: self._chat_list.addItem("\U0001F4AC  No messages yet. Say hello to start a conversation.")
        for m in msgs:
            who="\U0001F9D1 You" if m.get("from")=="user" else "\U0001F6DF Support"
            self._chat_list.addItem(f"{who}:  {m.get('text','')}")
        self._chat_list.scrollToBottom()

    def _help_tab_news(self):
        w=QWidget(); v=QVBoxLayout(w)
        self._help_inbox=QListWidget(); v.addWidget(self._help_inbox,1)
        QTimer.singleShot(0,self._refresh_help); return w

    def _help_tab_about(self):
        w=QWidget(); v=QVBoxLayout(w); v.setSpacing(8)
        who=self.auth.current_user.email if (getattr(self,"auth",None) and getattr(self.auth,"current_user",None)) else "Signed in"
        v.addWidget(QLabel(f"Version: {APP_VERSION}")); v.addWidget(QLabel(f"Account: {who}"))
        v.addWidget(self._lbl("Contact support (creates a ticket):","color:#8888aa;font-size:11px;"))
        self._ticket_subject=QLineEdit(); self._ticket_subject.setPlaceholderText("Subject"); v.addWidget(self._ticket_subject)
        self._ticket_body=QTextEdit(); self._ticket_body.setMaximumHeight(90); self._ticket_body.setPlaceholderText("Message"); v.addWidget(self._ticket_body)
        self._ticket_contact=QLineEdit(); self._ticket_contact.setPlaceholderText("Your email (optional)"); v.addWidget(self._ticket_contact)
        sb=self._mk_btn("\U0001F4E8","Send to Support","#6c63ff","#4a3abd"); sb.clicked.connect(self._submit_ticket); v.addWidget(sb)
        self._ticket_status=QLabel(""); self._ticket_status.setStyleSheet("color:#2ed573;font-size:11px;"); v.addWidget(self._ticket_status)
        doc=self._mk_btn("\U0001F4DA","Open Documentation","#333355","#252540"); doc.clicked.connect(self.show_documentation); v.addWidget(doc)
        logout=self._mk_btn("\u23cf","Log Out","#ff4757","#cc2f3d"); logout.clicked.connect(self._logout); v.addWidget(logout)
        v.addStretch(); return w

    def _refresh_help(self):
        if not hasattr(self,"_help_inbox"): return
        c=getattr(self,"cloud",None); items=c.fetch_broadcasts() if c else []
        self._help_inbox.clear()
        ic={"announcement":"📢","feature":"✨","notification":"🔔"}
        if not items: self._help_inbox.addItem("  No announcements yet — you are all caught up.")
        for it in items: self._help_inbox.addItem(f"  {ic.get(it['type'],'•')}  {it['title']}  —  {it['body']}")

    def _submit_ticket(self):
        c=getattr(self,"cloud",None)
        if not c: self._ticket_status.setText("Cloud not configured (Settings → Cloud)."); return
        subj=self._ticket_subject.text().strip(); body=self._ticket_body.toPlainText().strip()
        if not subj or not body: self._ticket_status.setText("Subject and message are required."); return
        try:
            c.submit_support_ticket(subj, body, self._ticket_contact.text().strip()); c.flush()
            self._ticket_subject.clear(); self._ticket_body.clear()
            if c.enabled:
                self._ticket_status.setText("✓ Sent — thank you! We'll be in touch.")
            else:
                self._ticket_status.setText("✓ Saved — will send once cloud is enabled (Settings → Cloud).")
            self.notifier.notify("Support Ticket",subj,"success")
        except Exception as e:
            self._ticket_status.setText(f"Could not send: {e}")

    def _on_broadcast(self, item):
        self._route_broadcast(item)

    def _on_broadcasts_updated(self, items):
        self._refresh_help()

    def _save_cloud_config(self):
        c=getattr(self,"cloud",None)
        if not c: return
        c.config.enabled=self._cloud_enable.isChecked()
        c.config.database_url=self._cloud_url.text().strip().rstrip("/")
        c.config.auth_token=self._cloud_token.text().strip()
        c.config.save()
        self._cloud_status.setText("Saved — " + ("cloud enabled." if c.config.ready else "disabled / incomplete."))
        if c.config.ready:
            c.register_install(APP_VERSION); c.flush()

    def _cloud_test(self):
        c=getattr(self,"cloud",None)
        if not c: return
        c.track_event("test_ping"); n=c.flush()
        self._cloud_status.setText(f"Flushed {n} item(s)." if c.enabled else "Cloud not enabled / configured.")

    def _maybe_ask_feedback(self):
        if getattr(self,"_feedback_asked",False): return
        self._feedback_asked=True
        c=getattr(self,"cloud",None)
        if not c or not _V4_OK: return
        try:
            dlg=FeedbackDialog(self)
            if dlg.exec()==QDialog.DialogCode.Accepted:
                rating,comment=dlg.result_data()
                c.submit_feedback(rating, comment, APP_VERSION)
            c.heartbeat(APP_VERSION); c.flush()
        except Exception: pass

    def _logout(self):
        if QMessageBox.question(self,"Log Out","Sign out of the QA tool?",
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes: return
        try:
            if getattr(self,"auth",None): self.auth.logout()
            if getattr(self,"_cloud_worker",None): self._cloud_worker.stop()
        except Exception: pass
        self._feedback_asked=True
        QApplication.quit()

    def _route_broadcast(self, item):
        ty=item.get("type","announcement")
        try:
            if ty=="update":   self._show_update_modal(item.get("version",""), item.get("body",""), item.get("id"))
            elif ty=="feature": self._show_feature_modal(item)
            elif ty=="announcement": self._show_announcement_modal(item)
            else:
                lvl=item.get("level","info"); lvl=lvl if lvl in ("info","success","warning","error") else "info"
                self.notifier.notify(item.get("title","Notification"), item.get("body",""), lvl)
        except Exception:
            self.notifier.notify(item.get("title","Update"), item.get("body",""), "info")

    def _ack(self, item):
        c=getattr(self,"cloud",None)
        if c and item.get("id"):
            try: c.acknowledge(item["id"], APP_VERSION); c.flush()
            except Exception: pass

    def _show_announcement_modal(self, item):
        if not _V4_OK: return
        AnnouncementModal(item, self).exec()
        self._ack(item)
        ThankYouModal("Thank you", self).exec()

    def _show_feature_modal(self, item):
        if not _V4_OK: return
        c=getattr(self,"cloud",None); name=item.get("title","")
        if c: c.track_feature(name,"viewed")
        dlg=FeatureModal(item, self); dlg.exec()
        if c:
            c.track_feature(name, "opened" if dlg.choice==FeatureModal.TRY else "dismissed")
        self._ack(item)

    def _show_update_modal(self, version, notes, ann_id=None):
        if not _V4_OK: return
        dlg=UpdateModal(version, notes, self); dlg.exec()
        if ann_id: self._ack({"id":ann_id})
        if dlg.choice==UpdateModal.UPDATE_NOW:
            self._start_update()
    def show_documentation(self):
        try:
            from documentation_viewer import DocumentationViewer; DocumentationViewer(self).exec()
        except Exception as e: QMessageBox.warning(self,"Error",f"Could not open documentation: {e}")


# ═══════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(True)
    icon_path = get_icon_path()
    app.setWindowIcon(QIcon(icon_path))
    # ── Mandatory authentication gate ──
    _auth = None
    try:
        from auth_service import AuthService
        from premium_dialogs import LoginDialog
        _auth = AuthService(get_base_path())
        if _auth.configured:
            if not _auth.try_restore_session():
                _dlg = LoginDialog(_auth, icon_path)
                if _dlg.exec() != QDialog.DialogCode.Accepted or not _auth.current_user:
                    sys.exit(0)
        else:
            from app_backend import ALLOW_OFFLINE_DEV
            if not ALLOW_OFFLINE_DEV:
                QMessageBox.critical(None, "Sign in required", "Authentication is not configured for this build.")
                sys.exit(0)
    except SystemExit:
        raise
    except Exception as _e:
        print(f"[auth] {_e}")
        from app_backend import ALLOW_OFFLINE_DEV
        if not ALLOW_OFFLINE_DEV:
            sys.exit(0)

    main_window = QADocumentationAssistant(auth=_auth)
    main_window.setWindowIcon(QIcon(icon_path))
    splash = ModernSplashScreen()
    try:
        _nm = (_auth.current_user.first_name if (_auth and getattr(_auth,"current_user",None)) else "")
        if _nm: splash.set_welcome(_nm)
    except Exception: pass
    splash.start_loading(main_window)
    sys.exit(app.exec())