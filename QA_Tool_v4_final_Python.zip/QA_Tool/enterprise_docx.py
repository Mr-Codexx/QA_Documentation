"""
Enterprise DOCX Engine - v4.0

Consulting-grade Word report generation with python-docx (matches the app's
existing dependency). Additive: this does NOT touch ExportEngine._export_word;
wire it in as a new "Enterprise DOCX" export option.

Features
  * Cover page (logo, project, module, tester, session id, date, environment)
  * Auto-generated clickable Table of Contents (Word field - update on open)
  * Executive Summary (steps, screenshots, defects, AI observations, risks)
  * Test Execution Evidence table (Step/Action/Expected/Actual/Status/Shot)
  * AI Analysis section (summary, risks, recommendations, improvements)
  * Screenshot gallery appendix
  * Headers + footers + page numbers (PAGE / NUMPAGES fields)
  * Diagonal text watermark (header VML)
  * Bookmarks + document metadata + corporate theme colours

Usage
-----
    from enterprise_docx import EnterpriseDocxExporter, ReportMeta
    EnterpriseDocxExporter(theme="corporate_blue").export(
        session, "report.docx",
        meta=ReportMeta(project="Acme Portal", module="Login",
                        tester="J. Doe", environment="Win11/Chrome124"),
        logo_path="icon.ico")
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


THEMES = {
    "corporate_blue": {"primary": "1F4E79", "accent": "2E75B6", "text": "1A1A1A",
                       "muted": "595959", "ok": "2E7D32", "bad": "C62828",
                       "band": "D6E4F0"},
    "healthcare":     {"primary": "00695C", "accent": "26A69A", "text": "1A1A1A",
                       "muted": "546E7A", "ok": "2E7D32", "bad": "C62828",
                       "band": "D7EFEC"},
    "dark":           {"primary": "111827", "accent": "374151", "text": "111827",
                       "muted": "6B7280", "ok": "059669", "bad": "DC2626",
                       "band": "E5E7EB"},
    "light":          {"primary": "263238", "accent": "546E7A", "text": "1A1A1A",
                       "muted": "78909C", "ok": "2E7D32", "bad": "C62828",
                       "band": "ECEFF1"},
}


@dataclass
class ReportMeta:
    project: str = "QA Test Documentation"
    module: str = ""
    tester: str = ""
    environment: str = ""
    company: str = "QA Documentation Assistant"
    watermark: str = "CONFIDENTIAL"


def _rgb(hexstr: str) -> RGBColor:
    return RGBColor.from_string(hexstr)


def _set_cell_bg(cell, hexcolor: str):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hexcolor)
    tcPr.append(shd)


def _add_field(paragraph, instr: str):
    """Insert a Word field (e.g. PAGE, NUMPAGES, TOC) that Word evaluates."""
    run = paragraph.add_run()
    fldBegin = OxmlElement("w:fldChar"); fldBegin.set(qn("w:fldCharType"), "begin")
    instrText = OxmlElement("w:instrText"); instrText.set(qn("xml:space"), "preserve")
    instrText.text = instr
    fldSep = OxmlElement("w:fldChar"); fldSep.set(qn("w:fldCharType"), "separate")
    fldEnd = OxmlElement("w:fldChar"); fldEnd.set(qn("w:fldCharType"), "end")
    run._r.append(fldBegin); run._r.append(instrText)
    run._r.append(fldSep); run._r.append(fldEnd)


def _add_bookmark(paragraph, name: str, bid: int):
    start = OxmlElement("w:bookmarkStart")
    start.set(qn("w:id"), str(bid)); start.set(qn("w:name"), name)
    end = OxmlElement("w:bookmarkEnd"); end.set(qn("w:id"), str(bid))
    paragraph._p.insert(0, start)
    paragraph._p.append(end)


class EnterpriseDocxExporter:
    def __init__(self, theme: str = "corporate_blue"):
        self.t = THEMES.get(theme, THEMES["corporate_blue"])
        self._bid = 0

    # ---- public --------------------------------------------------------
    def export(self, session, filepath: str, meta: ReportMeta = None,
               logo_path: str = None, ai_section: dict = None) -> bool:
        meta = meta or ReportMeta()
        doc = Document()
        self._base_styles(doc)
        self._metadata(doc, session, meta)
        self._headers_footers(doc, meta)

        self._cover_page(doc, session, meta, logo_path)
        self._toc_page(doc)
        self._executive_summary(doc, session)
        self._evidence_section(doc, session)
        self._ai_section(doc, session, ai_section)
        self._gallery(doc, session)

        doc.save(filepath)
        return True

    # ---- styling -------------------------------------------------------
    def _base_styles(self, doc):
        normal = doc.styles["Normal"]
        normal.font.name = "Calibri"
        normal.font.size = Pt(11)
        normal.font.color.rgb = _rgb(self.t["text"])
        for i, sz in ((1, 18), (2, 14), (3, 12)):
            st = doc.styles[f"Heading {i}"]
            st.font.name = "Calibri"
            st.font.size = Pt(sz)
            st.font.bold = True
            st.font.color.rgb = _rgb(self.t["primary"])

    def _metadata(self, doc, session, meta):
        cp = doc.core_properties
        cp.title = f"{meta.project} - QA Report"
        cp.author = meta.tester or meta.company
        cp.company = meta.company
        cp.category = "QA Test Documentation"
        cp.comments = f"Session {getattr(session, 'session_id', '')}"
        cp.created = datetime.now()

    def _headers_footers(self, doc, meta):
        section = doc.sections[0]
        section.different_first_page_header_footer = True

        # Header (skipped on cover via different first page)
        header = section.header
        hp = header.paragraphs[0]
        hp.text = meta.project
        hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for r in hp.runs:
            r.font.size = Pt(8); r.font.color.rgb = _rgb(self.t["muted"])
        self._para_bottom_border(hp)

        # Footer with page numbers
        footer = section.footer
        fp = footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = fp.add_run("Page "); run.font.size = Pt(8); run.font.color.rgb = _rgb(self.t["muted"])
        _add_field(fp, "PAGE")
        r2 = fp.add_run(" of "); r2.font.size = Pt(8); r2.font.color.rgb = _rgb(self.t["muted"])
        _add_field(fp, "NUMPAGES")

        # Watermark in header
        self._watermark(header, meta.watermark)

    def _para_bottom_border(self, paragraph):
        pPr = paragraph._p.get_or_add_pPr()
        pbdr = OxmlElement("w:pBdr")
        bottom = OxmlElement("w:bottom")
        bottom.set(qn("w:val"), "single"); bottom.set(qn("w:sz"), "6")
        bottom.set(qn("w:space"), "1"); bottom.set(qn("w:color"), self.t["accent"])
        pbdr.append(bottom); pPr.append(pbdr)

    def _watermark(self, header, text):
        """Best-effort diagonal text watermark via VML in the header."""
        try:
            p = header.add_paragraph()
            run = p.add_run()
            pict = OxmlElement("w:pict")
            shape = OxmlElement("v:shape")
            shape.set(qn("o:spid"), "_x0000_s2049")
            shape.set("type", "#_x0000_t136")
            shape.set("style",
                      "position:absolute;left:0;text-align:center;margin-left:0;"
                      "margin-top:0;width:480pt;height:160pt;rotation:315;"
                      "z-index:-1;mso-position-horizontal:center;"
                      "mso-position-vertical:center")
            shape.set("fillcolor", "#" + self.t["muted"])
            shape.set("stroked", "f")
            fill = OxmlElement("v:fill"); fill.set("opacity", ".12")
            textpath = OxmlElement("v:textpath")
            textpath.set("style", "font-family:'Calibri';font-size:1pt")
            textpath.set("string", text)
            shape.append(fill); shape.append(textpath)
            pict.append(shape); run._r.append(pict)
        except Exception:
            pass

    # ---- pages ---------------------------------------------------------
    def _cover_page(self, doc, session, meta, logo_path):
        doc.add_paragraph().add_run().add_break()
        if logo_path and os.path.exists(logo_path) and not logo_path.lower().endswith(".ico"):
            try:
                p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p.add_run().add_picture(logo_path, width=Inches(1.6))
            except Exception:
                pass

        title = doc.add_paragraph(); title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        tr = title.add_run(meta.project)
        tr.font.size = Pt(30); tr.font.bold = True; tr.font.color.rgb = _rgb(self.t["primary"])

        sub = doc.add_paragraph(); sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
        sr = sub.add_run("QA Test Execution Report")
        sr.font.size = Pt(15); sr.font.color.rgb = _rgb(self.t["accent"])

        doc.add_paragraph().add_run().add_break()
        doc.add_paragraph().add_run().add_break()

        info = [
            ("Module", meta.module or "—"),
            ("Tester", meta.tester or "—"),
            ("Session ID", getattr(session, "session_id", "—")),
            ("Execution Date", datetime.now().strftime("%d %B %Y")),
            ("Environment", meta.environment or "—"),
            ("Total Steps", str(len(getattr(session, "steps", [])))),
        ]
        tbl = doc.add_table(rows=0, cols=2)
        tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        for k, v in info:
            row = tbl.add_row().cells
            kr = row[0].paragraphs[0].add_run(k)
            kr.bold = True; kr.font.color.rgb = _rgb(self.t["primary"])
            row[1].paragraphs[0].add_run(str(v))
            row[0].width = Inches(2.0); row[1].width = Inches(3.5)

        foot = doc.add_paragraph(); foot.alignment = WD_ALIGN_PARAGRAPH.CENTER
        doc.add_paragraph().add_run().add_break()
        fr = foot.add_run(meta.company)
        fr.font.size = Pt(10); fr.font.color.rgb = _rgb(self.t["muted"])
        self._page_break(doc)

    def _toc_page(self, doc):
        h = doc.add_heading("Table of Contents", level=1)
        p = doc.add_paragraph()
        _add_field(p, r'TOC \o "1-3" \h \z \u')
        note = doc.add_paragraph()
        nr = note.add_run("(Right-click the table above and choose "
                          "\u201CUpdate Field\u201D to populate page numbers.)")
        nr.italic = True; nr.font.size = Pt(8); nr.font.color.rgb = _rgb(self.t["muted"])
        self._page_break(doc)

    def _executive_summary(self, doc, session):
        self._heading_bm(doc, "Executive Summary", "exec_summary")
        steps = getattr(session, "steps", [])
        screenshots = sum(1 for s in steps if getattr(s, "image_path", None))
        defects = sum(1 for s in steps
                      if (getattr(s, "bug_hint", "") or "").strip()
                      and "no obvious" not in (s.bug_hint or "").lower())

        cards = [
            ("Total Steps", len(steps)),
            ("Screenshots Captured", screenshots),
            ("Potential Defects", defects),
            ("AI Observations", sum(1 for s in steps if getattr(s, "description", ""))),
        ]
        tbl = doc.add_table(rows=1, cols=len(cards))
        tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        for i, (lbl, val) in enumerate(cards):
            cell = tbl.rows[0].cells[i]
            _set_cell_bg(cell, self.t["band"])
            vp = cell.paragraphs[0]; vp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            vr = vp.add_run(str(val)); vr.bold = True; vr.font.size = Pt(22)
            vr.font.color.rgb = _rgb(self.t["primary"])
            lp = cell.add_paragraph(); lp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            lr = lp.add_run(lbl); lr.font.size = Pt(9); lr.font.color.rgb = _rgb(self.t["muted"])

        doc.add_paragraph()
        risk = "High" if defects >= 5 else "Medium" if defects else "Low"
        p = doc.add_paragraph()
        p.add_run("Risk Areas: ").bold = True
        rr = p.add_run(f"{risk} ({defects} potential defect(s) flagged across "
                       f"{len(steps)} step(s)).")
        rr.font.color.rgb = _rgb(self.t["bad"] if defects else self.t["ok"])
        self._page_break(doc)

    def _evidence_section(self, doc, session):
        # Switch to landscape for the wide evidence table
        new_sec = doc.add_section(WD_SECTION.NEW_PAGE)
        new_sec.orientation = WD_ORIENT.LANDSCAPE
        new_sec.page_width, new_sec.page_height = new_sec.page_height, new_sec.page_width

        self._heading_bm(doc, "Test Execution Evidence", "evidence")
        steps = getattr(session, "steps", [])
        cols = ["#", "Action", "Expected Result", "Actual Result", "Status", "Screenshot"]
        tbl = doc.add_table(rows=1, cols=len(cols))
        tbl.style = "Table Grid"
        for i, c in enumerate(cols):
            cell = tbl.rows[0].cells[i]
            _set_cell_bg(cell, self.t["primary"])
            r = cell.paragraphs[0].add_run(c)
            r.bold = True; r.font.color.rgb = _rgb("FFFFFF"); r.font.size = Pt(10)

        for idx, s in enumerate(steps, 1):
            hint = (getattr(s, "bug_hint", "") or "")
            is_bug = hint.strip() and "no obvious" not in hint.lower()
            status = "FAIL" if is_bug else "PASS"
            row = tbl.add_row().cells
            row[0].paragraphs[0].add_run(str(idx))
            row[1].paragraphs[0].add_run(getattr(s, "description", "") or s.capture_type)
            row[2].paragraphs[0].add_run(getattr(s, "expected_behavior", "") or "—")
            row[3].paragraphs[0].add_run(getattr(s, "actual_observation", "") or "—")
            sr = row[4].paragraphs[0].add_run(status)
            sr.bold = True
            sr.font.color.rgb = _rgb(self.t["bad"] if is_bug else self.t["ok"])
            img = getattr(s, "image_path", None)
            if img and os.path.exists(img):
                try:
                    row[5].paragraphs[0].add_run().add_picture(img, width=Inches(1.8))
                except Exception:
                    row[5].paragraphs[0].add_run("(image)")
            else:
                row[5].paragraphs[0].add_run("—")

        # back to portrait
        back = doc.add_section(WD_SECTION.NEW_PAGE)
        back.orientation = WD_ORIENT.PORTRAIT
        back.page_width, back.page_height = back.page_height, back.page_width

    def _ai_section(self, doc, session, ai_section):
        self._heading_bm(doc, "AI Analysis", "ai_analysis")
        ai_section = ai_section or {}
        steps = getattr(session, "steps", [])
        default_summary = (ai_section.get("summary")
                           or f"AI processed {len(steps)} step(s). "
                              "See per-step observations in the evidence table.")
        risks = ai_section.get("risks") or [
            s.bug_hint for s in steps
            if (getattr(s, "bug_hint", "") or "").strip()
            and "no obvious" not in (s.bug_hint or "").lower()
        ]
        recs = ai_section.get("recommendations") or [
            "Re-test all FAIL steps after fixes are applied.",
            "Add regression coverage for the flagged areas.",
        ]
        improvements = ai_section.get("improvements") or [
            "Capture before/after screenshots for regression-prone flows.",
        ]

        doc.add_heading("Summary", level=2)
        doc.add_paragraph(default_summary)
        for label, items in (("Risks", risks), ("Recommendations", recs),
                             ("Potential Improvements", improvements)):
            doc.add_heading(label, level=2)
            if items:
                for it in items[:20]:
                    doc.add_paragraph(str(it), style="List Bullet")
            else:
                doc.add_paragraph("None identified.")
        self._page_break(doc)

    def _gallery(self, doc, session):
        steps = [s for s in getattr(session, "steps", [])
                 if getattr(s, "image_path", None) and os.path.exists(s.image_path)]
        if not steps:
            return
        self._heading_bm(doc, "Screenshot Gallery", "gallery")
        for idx, s in enumerate(steps, 1):
            cap = doc.add_paragraph()
            cr = cap.add_run(f"Figure {idx}: {getattr(s, 'description', '') or 'Screenshot'}")
            cr.bold = True; cr.font.size = Pt(10); cr.font.color.rgb = _rgb(self.t["primary"])
            try:
                p = doc.add_paragraph()
                p.add_run().add_picture(s.image_path, width=Inches(6.0))
            except Exception:
                doc.add_paragraph("(image could not be embedded)")
            doc.add_paragraph()

    # ---- helpers -------------------------------------------------------
    def _heading_bm(self, doc, text, bookmark):
        h = doc.add_heading(text, level=1)
        self._bid += 1
        _add_bookmark(h, bookmark, self._bid)
        return h

    def _page_break(self, doc):
        doc.add_page_break()


if __name__ == "__main__":
    # self-test using stand-in objects matching the app's model
    class Step:
        def __init__(self, **k): self.__dict__.update(k)

    class Sess:
        session_id = "demo1234"
        def __init__(self, steps): self.steps = steps; self.metadata = {}

    steps = [
        Step(step_id="s1", capture_type="full_screen",
             description="Open the login page",
             expected_behavior="Login form renders correctly",
             actual_observation="Form rendered as expected",
             bug_hint="No obvious issues", image_path=None),
        Step(step_id="s2", capture_type="snip",
             description="Submit empty credentials",
             expected_behavior="Inline validation error shown",
             actual_observation="Page returns HTTP 500",
             bug_hint="Server 500 error on empty submit", image_path=None),
    ]
    sess = Sess(steps)
    EnterpriseDocxExporter("corporate_blue").export(
        sess, "/tmp/enterprise_report.docx",
        meta=ReportMeta(project="Acme Customer Portal", module="Authentication",
                        tester="Jane Doe", environment="Windows 11 / Chrome 124"))
    print("wrote /tmp/enterprise_report.docx",
          os.path.getsize("/tmp/enterprise_report.docx"), "bytes")
