#!/usr/bin/env python3
"""
Premium Rounded Splash Screen (Borderless + Animated + Thin Progress)
"""

import sys
from PyQt6.QtWidgets import (
    QSplashScreen, QProgressBar, QLabel,
    QVBoxLayout, QWidget, QApplication,
    QGraphicsOpacityEffect
)
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QPixmap, QFont


class ModernSplashScreen(QSplashScreen):
    def __init__(self):
        pixmap = QPixmap(600, 380)
        pixmap.fill(Qt.GlobalColor.transparent)
        super().__init__(pixmap)

        # 🔥 Window setup (borderless + transparent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        # 🔥 Main container (rounded modal)
        self.container = QWidget(self)
        self.container.setGeometry(5, 5, 590, 370)  # slight inset = shadow feel
        self.container.setStyleSheet("""
            QWidget {
                background-color: #0f172a;
                border-radius: 18px;
            }
        """)

        self.setup_ui()
        self.center()

        # Progress logic (~6 sec)
        self.progress = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_progress)

        # Animation
        self.setup_animation()

    # -----------------------
    def center(self):
        screen = QApplication.primaryScreen().geometry()
        self.setGeometry(
            (screen.width() - 600) // 2,
            (screen.height() - 380) // 2,
            600, 380
        )

    # -----------------------
    def setup_ui(self):
        layout = QVBoxLayout(self.container)
        layout.setContentsMargins(40, 40, 40, 20)
        layout.setSpacing(8)

        # 🤖 Logo
        self.logo = QLabel("🤖")
        self.logo.setFont(QFont("Segoe UI", 54))
        self.logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo.setStyleSheet("color: #e94560;")
        layout.addWidget(self.logo)

        # Title
        self.title = QLabel("AI QA Documentation Assistant")
        self.title.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title.setStyleSheet("color: white;")
        layout.addWidget(self.title)

        # Subtitle
        self.subtitle = QLabel("Smart Test Documentation")
        self.subtitle.setFont(QFont("Segoe UI", 10))
        self.subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.subtitle.setStyleSheet("color: #94a3b8;")
        layout.addWidget(self.subtitle)

        layout.addStretch()

        # Status
        self.status = QLabel("Initializing...")
        self.status.setFont(QFont("Segoe UI", 9))
        self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status.setStyleSheet("color: #64748b;")
        layout.addWidget(self.status)

        # 🔥 Thin Progress Bar (bottom)
        self.bar = QProgressBar()
        self.bar.setFixedHeight(4)
        self.bar.setRange(0, 100)
        self.bar.setTextVisible(False)

        self.bar.setStyleSheet("""
            QProgressBar {
                background-color: #1e293b;
                border-radius: 2px;
            }
            QProgressBar::chunk {
                border-radius: 2px;
                background-color: qlineargradient(
                    x1:0, y1:0, x2:1, y2:0,
                    stop:0 #e94560,
                    stop:0.5 #6366f1,
                    stop:1 #22c55e
                );
            }
        """)
        layout.addWidget(self.bar)

        # Footer
        self.footer = QLabel("Sachin Sharma • Software Engineer")
        self.footer.setFont(QFont("Segoe UI", 8))
        self.footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.footer.setStyleSheet("color: #475569;")
        layout.addWidget(self.footer)

    # -----------------------
    def setup_animation(self):
        """Fade-in animation"""
        self.effect = QGraphicsOpacityEffect()
        self.container.setGraphicsEffect(self.effect)

        self.fade = QPropertyAnimation(self.effect, b"opacity")
        self.fade.setDuration(1200)
        self.fade.setStartValue(0)
        self.fade.setEndValue(1)
        self.fade.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self.fade.start()

    # -----------------------
    def update_progress(self):
        self.progress += 1  # ~6–7 sec total

        # Status updates
        if self.progress < 20:
            self.status.setText("Loading modules...")
        elif self.progress < 40:
            self.status.setText("Initializing capture engine...")
        elif self.progress < 60:
            self.status.setText("Connecting AI engine...")
        elif self.progress < 80:
            self.status.setText("Preparing UI...")
        elif self.progress < 100:
            self.status.setText("Almost ready...")
        else:
            self.status.setText("Ready 🚀")

        self.bar.setValue(self.progress)

        if self.progress >= 100:
            self.timer.stop()
            QTimer.singleShot(400, self.finish_splash)

    # -----------------------
    from PyQt6.QtCore import Qt, QTimer

    def finish_splash(self):
        self.finish(self.main_window)

        def bring_to_front():
            self.main_window.show()

            # 🚀 Force on top + active
            self.main_window.raise_()
            self.main_window.activateWindow()

            # 🧠 Fix minimized/background issue (Windows)
            self.main_window.setWindowState(
                self.main_window.windowState()
                & ~Qt.WindowState.WindowMinimized
                | Qt.WindowState.WindowActive
            )

        # small delay ensures OS focus switch works
        QTimer.singleShot(100, bring_to_front)

    # -----------------------
    def set_welcome(self, name):
        try:
            self.subtitle.setText(f"Welcome back, {name}  👋")
            self.subtitle.setStyleSheet("color: #a78bfa; font-weight: 600;")
        except Exception:
            pass

    def start_loading(self, main_window):
        self.main_window = main_window
        self.show()
        self.timer.start(60)  # ~6 seconds


# -----------------------
# TEST RUN
# -----------------------
# if __name__ == "__main__":
#     from PyQt6.QtWidgets import QMainWindow

#     app = QApplication(sys.argv)

#     main_window = QMainWindow()
#     main_window.setWindowTitle("Main App")
#     main_window.resize(900, 500)

#     splash = ModernSplashScreen()
#     splash.start_loading(main_window)

#     sys.exit(app.exec())