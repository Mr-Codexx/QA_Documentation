"""
Session Manager - Handles session creation, storage, and step management
"""

import json
import os
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import List, Optional
import uuid


@dataclass
class StepData:
    """Individual test step data"""
    step_id: str
    session_id: str
    timestamp: datetime
    image_path: Optional[str]
    capture_type: str  # full_screen, snip, manual_note
    description: str
    expected_behavior: str
    actual_observation: str
    bug_hint: str
    tags: List[str]
    
    def __init__(self, session_id: str, image_path: Optional[str], capture_type: str):
        self.step_id = str(uuid.uuid4())[:8]
        self.session_id = session_id
        self.timestamp = datetime.now()
        self.image_path = image_path
        self.capture_type = capture_type
        self.description = ""
        self.expected_behavior = ""
        self.actual_observation = ""
        self.bug_hint = ""
        self.tags = []
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "step_id": self.step_id,
            "session_id": self.session_id,
            "timestamp": self.timestamp.isoformat(),
            "image_path": self.image_path,
            "capture_type": self.capture_type,
            "description": self.description,
            "expected_behavior": self.expected_behavior,
            "actual_observation": self.actual_observation,
            "bug_hint": self.bug_hint,
            "tags": self.tags
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create StepData from dictionary"""
        step = cls(data["session_id"], data["image_path"], data["capture_type"])
        step.step_id = data["step_id"]
        step.timestamp = datetime.fromisoformat(data["timestamp"])
        step.description = data["description"]
        step.expected_behavior = data["expected_behavior"]
        step.actual_observation = data["actual_observation"]
        step.bug_hint = data["bug_hint"]
        step.tags = data["tags"]
        step.highlight_regions = []
        step.highlighted_text = ""
        return step


@dataclass
class Session:
    """Test documentation session"""
    session_id: str
    session_name: str
    start_time: datetime
    end_time: Optional[datetime]
    steps: List[StepData]
    metadata: dict
    
    def __init__(self, session_name: str):
        self.session_id = str(uuid.uuid4())[:8]
        self.session_name = session_name
        self.start_time = datetime.now()
        self.end_time = None
        self.steps = []
        self.metadata = {
            "application": "QA Documentation Assistant",
            "version": "2.0",
            "total_steps": 0
        }
    
    def add_step(self, image_path: Optional[str], capture_type: str) -> StepData:
        """Add a new step to the session"""
        step = StepData(self.session_id, image_path, capture_type)
        self.steps.append(step)
        self.metadata["total_steps"] = len(self.steps)
        return step
    
    def end_session(self):
        """Mark session as ended"""
        self.end_time = datetime.now()
    
    def to_dict(self):
        """Convert session to dictionary"""
        return {
            "session_id": self.session_id,
            "session_name": self.session_name,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "steps": [step.to_dict() for step in self.steps],
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create Session from dictionary"""
        session = cls(data["session_name"])
        session.session_id = data["session_id"]
        session.start_time = datetime.fromisoformat(data["start_time"])
        session.end_time = datetime.fromisoformat(data["end_time"]) if data["end_time"] else None
        session.steps = [StepData.from_dict(step_data) for step_data in data["steps"]]
        session.metadata = data["metadata"]
        return session


class SessionManager:
    """Manages multiple sessions with persistent storage"""
    
    def __init__(self, storage_path: str = "sessions"):
        self.storage_path = storage_path
        self.current_session = None
        os.makedirs(storage_path, exist_ok=True)
    
    def create_session(self, session_name: str) -> Session:
        """Create a new session"""
        self.current_session = Session(session_name)
        return self.current_session
    
    def end_current_session(self):
        """End the current session and save"""
        if self.current_session:
            self.current_session.end_session()
            self.save_session(self.current_session)
            self.current_session = None
    
    def save_session(self, session: Session):
        """Save session to disk"""
        session_file = os.path.join(self.storage_path, f"{session.session_id}.json")
        with open(session_file, 'w') as f:
            json.dump(session.to_dict(), f, indent=2)
    
    def load_session(self, session_id: str) -> Optional[Session]:
        """Load a session from disk"""
        session_file = os.path.join(self.storage_path, f"{session_id}.json")
        if os.path.exists(session_file):
            with open(session_file, 'r') as f:
                data = json.load(f)
                return Session.from_dict(data)
        return None
    
    def list_sessions(self) -> List[dict]:
        """List all saved sessions"""
        sessions = []
        for filename in os.listdir(self.storage_path):
            if filename.endswith('.json'):
                with open(os.path.join(self.storage_path, filename), 'r') as f:
                    data = json.load(f)
                    sessions.append({
                        "session_id": data["session_id"],
                        "session_name": data["session_name"],
                        "start_time": data["start_time"],
                        "total_steps": len(data["steps"])
                    })
        return sorted(sessions, key=lambda x: x["start_time"], reverse=True)