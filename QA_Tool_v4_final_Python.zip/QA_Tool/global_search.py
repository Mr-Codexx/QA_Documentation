"""
Global Search - v4.0

Instant search across every session: names, step descriptions, expected/actual,
bug hints, tags, OCR text and AI analysis. Builds an in-memory inverted-ish
index from the sessions/ folder and ranks results.

Qt-free. The UI layer just calls `GlobalSearch.search(query)` and renders hits.

Public API
----------
    gs = GlobalSearch(storage_path="sessions")
    gs.reindex()                       # scan disk
    hits = gs.search("login crash")    # -> list[SearchHit] ranked
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import List, Dict


@dataclass
class SearchHit:
    session_id: str
    session_name: str
    step_id: str
    field: str          # which field matched: name|description|bug_hint|ocr|ai|tag
    snippet: str
    score: float
    image_path: str = ""


_TOKEN = re.compile(r"[a-z0-9]+")


def _tokens(text: str) -> List[str]:
    return _TOKEN.findall((text or "").lower())


class _Doc:
    __slots__ = ("session_id", "session_name", "step_id", "field", "text",
                 "image_path", "_tokens")

    def __init__(self, session_id, session_name, step_id, field, text, image_path):
        self.session_id = session_id
        self.session_name = session_name
        self.step_id = step_id
        self.field = field
        self.text = text or ""
        self.image_path = image_path or ""
        self._tokens = set(_tokens(self.text))


# Per-field weighting so a name/bug match ranks above an incidental OCR match.
FIELD_WEIGHT = {
    "name": 3.0, "bug_hint": 2.5, "description": 2.0,
    "expected": 1.5, "actual": 1.5, "tag": 2.0, "ai": 1.2, "ocr": 1.0,
}


class GlobalSearch:
    def __init__(self, storage_path: str = "sessions"):
        self.storage_path = storage_path
        self.docs: List[_Doc] = []

    def reindex(self) -> int:
        self.docs = []
        if not os.path.isdir(self.storage_path):
            return 0
        for fn in os.listdir(self.storage_path):
            if not fn.endswith(".json"):
                continue
            try:
                with open(os.path.join(self.storage_path, fn), "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                continue
            self._index_session(data)
        return len(self.docs)

    def _add(self, sid, sname, step_id, field, text, image=""):
        if text and str(text).strip():
            self.docs.append(_Doc(sid, sname, step_id, field, str(text), image))

    def _index_session(self, data: Dict):
        sid = data.get("session_id", "")
        sname = data.get("session_name", "")
        self._add(sid, sname, "", "name", sname)

        for step in data.get("steps", []):
            step_id = step.get("step_id", "")
            img = step.get("image_path", "") or ""
            self._add(sid, sname, step_id, "description", step.get("description"), img)
            self._add(sid, sname, step_id, "expected", step.get("expected_behavior"), img)
            self._add(sid, sname, step_id, "actual", step.get("actual_observation"), img)
            self._add(sid, sname, step_id, "bug_hint", step.get("bug_hint"), img)
            # OCR / AI fields are written by v4 modules; index if present.
            self._add(sid, sname, step_id, "ocr", step.get("ocr_text"), img)
            self._add(sid, sname, step_id, "ai", step.get("ai_summary"), img)
            for tag in step.get("tags", []) or []:
                self._add(sid, sname, step_id, "tag", tag, img)

    def search(self, query: str, limit: int = 50) -> List[SearchHit]:
        q_tokens = _tokens(query)
        if not q_tokens:
            return []
        q_set = set(q_tokens)
        phrase = query.lower().strip()
        hits: List[SearchHit] = []

        for doc in self.docs:
            overlap = q_set & doc._tokens
            if not overlap:
                continue
            score = len(overlap) / len(q_set)
            score *= FIELD_WEIGHT.get(doc.field, 1.0)
            # phrase bonus
            if len(q_tokens) > 1 and phrase in doc.text.lower():
                score += 2.0
            hits.append(SearchHit(
                session_id=doc.session_id,
                session_name=doc.session_name,
                step_id=doc.step_id,
                field=doc.field,
                snippet=self._snippet(doc.text, overlap),
                score=round(score, 3),
                image_path=doc.image_path,
            ))

        hits.sort(key=lambda h: h.score, reverse=True)
        return hits[:limit]

    def _snippet(self, text: str, terms: set, width: int = 90) -> str:
        low = text.lower()
        pos = min((low.find(t) for t in terms if low.find(t) >= 0), default=0)
        start = max(0, pos - width // 3)
        end = min(len(text), start + width)
        snip = text[start:end].strip()
        return ("..." if start > 0 else "") + snip + ("..." if end < len(text) else "")


if __name__ == "__main__":
    # self-test against a temp sessions folder
    os.makedirs("/tmp/sess", exist_ok=True)
    demo = {
        "session_id": "s1", "session_name": "Login Module Regression",
        "steps": [
            {"step_id": "x1", "image_path": "a.png",
             "description": "User opens the login page",
             "expected_behavior": "Form renders", "actual_observation": "Form renders",
             "bug_hint": "No obvious issues", "tags": ["login", "smoke"]},
            {"step_id": "x2", "image_path": "b.png",
             "description": "Submit empty credentials",
             "expected_behavior": "Validation error", "actual_observation": "App crashes",
             "bug_hint": "Server returns 500 error on empty submit", "tags": ["login"]},
        ],
    }
    with open("/tmp/sess/s1.json", "w") as f:
        json.dump(demo, f)

    gs = GlobalSearch("/tmp/sess")
    print("indexed docs:", gs.reindex())
    for h in gs.search("login crash"):
        print(f"  [{h.score:>5}] {h.field:11} {h.session_name} :: {h.snippet}")
    print("---")
    for h in gs.search("500 error"):
        print(f"  [{h.score:>5}] {h.field:11} {h.snippet}")
