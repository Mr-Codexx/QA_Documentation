"""
Auto-Update System - v4.0

Self-update against a JSON manifest hosted by the developer. No app-store,
no manual EXE distribution. Design:

  manifest.json (hosted):
    { "version": "4.1.0",
      "url": "https://.../QA_Tool-4.1.0.zip",
      "sha256": "abc...", "notes": "...", "mandatory": false }

  Flow: check_for_update() -> download_update() -> stage -> apply_on_restart()
  Rollback: previous version is kept in a backup dir and restored on failure.

Security: every download is SHA-256 verified against the manifest before it is
staged. HTTPS is required. The version-compare + verification logic is Qt-free
and unit-testable; the network/file-swap parts are clearly isolated.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
from dataclasses import dataclass
from typing import Optional, Tuple


def parse_version(v: str) -> Tuple[int, ...]:
    parts = []
    for chunk in str(v).strip().lstrip("vV").split("."):
        num = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(num) if num else 0)
    return tuple(parts) or (0,)


def is_newer(candidate: str, current: str) -> bool:
    a, b = parse_version(candidate), parse_version(current)
    n = max(len(a), len(b))
    a += (0,) * (n - len(a)); b += (0,) * (n - len(b))
    return a > b


def sha256_file(path: str, chunk: int = 65536) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


@dataclass
class UpdateInfo:
    version: str
    url: str
    sha256: str
    notes: str = ""
    mandatory: bool = False


class UpdateManager:
    def __init__(self, current_version: str,
                 manifest_url: str = "",
                 app_dir: str = ".",
                 work_dir: str = "_update"):
        self.current_version = current_version
        self.manifest_url = manifest_url
        self.app_dir = os.path.abspath(app_dir)
        self.work_dir = os.path.abspath(work_dir)
        self.backup_dir = os.path.join(self.work_dir, "backup")

    # ---- check ---------------------------------------------------------
    def check_for_update(self, timeout: int = 10) -> Optional[UpdateInfo]:
        manifest = self._fetch_manifest(timeout)
        if not manifest:
            return None
        return self.evaluate_manifest(manifest)

    def evaluate_manifest(self, manifest: dict) -> Optional[UpdateInfo]:
        """Pure logic: decide whether the manifest offers a newer version."""
        ver = manifest.get("version", "")
        if not ver or not is_newer(ver, self.current_version):
            return None
        url = manifest.get("url", "")
        if not url.lower().startswith("https://"):
            return None  # refuse non-HTTPS downloads
        return UpdateInfo(
            version=ver, url=url,
            sha256=manifest.get("sha256", ""),
            notes=manifest.get("notes", ""),
            mandatory=bool(manifest.get("mandatory", False)),
        )

    def _fetch_manifest(self, timeout: int) -> Optional[dict]:
        if not self.manifest_url:
            return None
        try:
            import requests
            r = requests.get(self.manifest_url, timeout=timeout)
            if r.status_code == 200:
                return r.json()
        except Exception:
            return None
        return None

    # ---- download + verify --------------------------------------------
    def download_update(self, info: UpdateInfo, progress_cb=None) -> Optional[str]:
        os.makedirs(self.work_dir, exist_ok=True)
        dest = os.path.join(self.work_dir, f"update-{info.version}.zip")
        try:
            import requests
            with requests.get(info.url, stream=True, timeout=60) as r:
                r.raise_for_status()
                total = int(r.headers.get("content-length", 0))
                done = 0
                with open(dest, "wb") as f:
                    for chunk in r.iter_content(chunk_size=65536):
                        if not chunk:
                            continue
                        f.write(chunk); done += len(chunk)
                        if progress_cb and total:
                            progress_cb(int(done * 100 / total))
        except Exception:
            return None
        if not self.verify(dest, info.sha256):
            try:
                os.remove(dest)
            except OSError:
                pass
            return None
        return dest

    def verify(self, path: str, expected_sha256: str) -> bool:
        if not os.path.exists(path):
            return False
        if not expected_sha256:
            return True  # no hash provided; caller accepted that risk
        return sha256_file(path).lower() == expected_sha256.lower()

    # ---- stage / apply / rollback -------------------------------------
    def stage(self, zip_path: str) -> bool:
        """Extract the verified zip into a staging folder ready for apply."""
        staging = os.path.join(self.work_dir, "staging")
        try:
            shutil.rmtree(staging, ignore_errors=True)
            os.makedirs(staging, exist_ok=True)
            shutil.unpack_archive(zip_path, staging)
            return True
        except Exception:
            return False

    def apply_on_restart(self) -> bool:
        """Back up current app, copy staged files over it. Call then restart."""
        staging = os.path.join(self.work_dir, "staging")
        if not os.path.isdir(staging):
            return False
        # find the payload root (zip may contain a top folder)
        roots = [os.path.join(staging, d) for d in os.listdir(staging)]
        payload = roots[0] if len(roots) == 1 and os.path.isdir(roots[0]) else staging
        try:
            shutil.rmtree(self.backup_dir, ignore_errors=True)
            os.makedirs(self.backup_dir, exist_ok=True)
            for name in os.listdir(payload):
                src = os.path.join(payload, name)
                dst = os.path.join(self.app_dir, name)
                if os.path.exists(dst):
                    bdst = os.path.join(self.backup_dir, name)
                    if os.path.isdir(dst):
                        shutil.copytree(dst, bdst, dirs_exist_ok=True)
                    else:
                        shutil.copy2(dst, bdst)
                if os.path.isdir(src):
                    shutil.copytree(src, dst, dirs_exist_ok=True)
                else:
                    shutil.copy2(src, dst)
            return True
        except Exception:
            self.rollback()
            return False

    def rollback(self) -> bool:
        if not os.path.isdir(self.backup_dir):
            return False
        try:
            for name in os.listdir(self.backup_dir):
                src = os.path.join(self.backup_dir, name)
                dst = os.path.join(self.app_dir, name)
                if os.path.isdir(src):
                    shutil.copytree(src, dst, dirs_exist_ok=True)
                else:
                    shutil.copy2(src, dst)
            return True
        except Exception:
            return False


if __name__ == "__main__":
    # version-compare tests
    assert is_newer("4.1.0", "4.0.0")
    assert is_newer("4.0.1", "4.0.0")
    assert is_newer("v4.10.0", "4.9.9")
    assert not is_newer("4.0.0", "4.0.0")
    assert not is_newer("3.9.9", "4.0.0")
    print("version compare: OK")

    um = UpdateManager(current_version="4.0.0", manifest_url="")
    # newer, https -> accepted
    info = um.evaluate_manifest({"version": "4.1.0",
                                 "url": "https://example.com/u.zip",
                                 "sha256": "deadbeef", "notes": "Bug fixes"})
    print("offered update:", info.version if info else None, "| notes:", info.notes if info else "")
    # non-https -> rejected
    assert um.evaluate_manifest({"version": "5.0.0", "url": "http://x/u.zip"}) is None
    # same version -> none
    assert um.evaluate_manifest({"version": "4.0.0", "url": "https://x/u.zip"}) is None
    print("manifest evaluation (https-only, newer-only): OK")

    # sha verify roundtrip
    with open("/tmp/_u.bin", "wb") as f:
        f.write(b"hello world")
    digest = sha256_file("/tmp/_u.bin")
    assert um.verify("/tmp/_u.bin", digest)
    assert not um.verify("/tmp/_u.bin", "0" * 64)
    print("sha256 verification: OK")
