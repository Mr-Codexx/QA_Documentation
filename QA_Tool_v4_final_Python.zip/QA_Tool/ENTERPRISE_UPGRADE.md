# AI QA Documentation Assistant — v4.0 Enterprise Modules

These modules are **additive**. None of your existing files (`main.py`,
`export_engine.py`, `ai_processor.py`, `session_manager.py`, etc.) were modified,
so every current workflow keeps working exactly as before. Each module is a new,
self-contained file you opt into by importing it and wiring a button/tab.

`requirements.txt` is unchanged except for one added line (`requests`), and every
library each module needs (`Pillow`, `python-docx`, `numpy`) was already in your
project.

---

## What's included and its status

| # (spec) | Module | What it does | Status |
|---|---|---|---|
| 2 | `enterprise_docx.py` | Consulting-grade DOCX: cover page, clickable TOC, exec summary, **landscape** evidence table, AI section, screenshot gallery, headers/footers/page numbers, watermark, bookmarks, metadata, corporate themes | **Production-ready, tested** (renders cleanly in Word/LibreOffice) |
| 1 | `onedrive_integration.py` | Detects OneDrive Personal/Business + synced SharePoint folders with **no Graph/OAuth/Azure**; picks an export destination | **Production-ready, tested** (detection is OS-specific) |
| 13 | `screenshot_compare.py` | Before/after diff: changed regions, red-box overlay, side-by-side composite, change summary | **Production-ready, tested** |
| 14 | `defect_assistant.py` | One-click defect: summary, steps-to-reproduce, expected/actual, severity + priority (heuristic, with optional AI pass) | **Production-ready, tested** |
| 11 | `global_search.py` | Instant ranked search across sessions/notes/OCR/AI/tags | **Production-ready, tested** |
| 10 | `dashboard.py` | Aggregates sessions/screenshots/defects/AI/reports + trend; optional Qt widget | Data layer **tested**; widget is drop-in |
| 9 / 3 | `theme_manager.py` | Light / Dark / Corporate Blue / Healthcare / custom themes via QSS design tokens, instant switch | **Tested** (QSS generation); apply needs a running app |
| 7 | `notification_center.py` | History + search + filter + clear-all + rich actions, wrapping your existing toast manager | Store layer **tested**; panel is drop-in |
| 6 | `update_manager.py` | Manifest-based self-update: HTTPS-only, SHA-256 verified, staged apply + rollback | Logic **tested**; needs a hosted `manifest.json` + release zips |

### Not attempted here (and why)
Items **4 (custom window frame)**, **5 (perf targets)**, **8 (DPI-responsive relayout)**
and the *full* UI reskin in **3** require surgical edits to your actual `main.py`
UI code and on-device profiling/visual testing. Doing them blind would risk
breaking the working app — exactly what your spec forbids. `theme_manager.py`
gives you the visual-system foundation for #3; the rest should be done against the
live UI. **#12 (session recovery) already exists** in your code as `DraftManager`
inside `main.py` (auto-save + orphaned-lock recovery), so it's covered.

---

## Wiring examples

### Enterprise DOCX export (add alongside your existing Word export)
```python
from enterprise_docx import EnterpriseDocxExporter, ReportMeta

def export_enterprise(self):
    meta = ReportMeta(
        project=self.session.session_name,
        module=self.module_field.text(),
        tester=self.tester_field.text(),
        environment=self.env_field.text(),
    )
    out = self.storage.resolve_export_dir()          # from onedrive_integration
    path = os.path.join(out, f"{self.session.session_id}_enterprise.docx")
    EnterpriseDocxExporter(theme=self.theme_name).export(
        self.session, path, meta=meta, logo_path=get_icon_path())
    self.notif.success("Export Finished", path)       # from notification_center
```

### Storage destination (OneDrive)
```python
from onedrive_integration import StorageManager
self.storage = StorageManager(base_path=get_base_path())
for loc in self.storage.detect_all():
    print(loc.label, loc.path)        # populate a combo box in Settings
self.storage.set_destination("onedrive", chosen_path)
```

### Theme switcher
```python
from theme_manager import ThemeManager
self.themes = ThemeManager()
self.themes.apply("corporate_blue", QApplication.instance())   # instant
```

### Screenshot comparison
```python
from screenshot_compare import compare_images
res = compare_images(before_png, after_png, out_dir=self.storage.resolve_export_dir())
self.show_image(res.overlay_path)
self.notes.setPlainText(res.summary())
```

### Defect assistant (copy to clipboard)
```python
from defect_assistant import DefectAssistant
rep = DefectAssistant(ai_processor=self.ai).build(self.session, step)
QApplication.clipboard().setText(rep.to_clipboard_text())
```

### Dashboard tab
```python
from dashboard import DashboardStats, build_widget
data = DashboardStats("sessions", "exports").compute()
self.tabs.addTab(build_widget(data), "Dashboard")
```

### Notification center
```python
from notification_center import NotificationCenter, build_panel
self.notif = NotificationCenter(self.notification_manager)   # reuse existing toasts
self.notif.success("Screenshot Captured", "step_03.png")
self.tabs.addTab(build_panel(self.notif), "Notifications")
```

### Auto-update check on startup
```python
from update_manager import UpdateManager
um = UpdateManager(current_version="4.0.0",
                   manifest_url="https://your-host/qa-tool/manifest.json",
                   app_dir=get_base_path())
info = um.check_for_update()
if info:
    self.notif.notify("Update Available", info.version, level="action",
                      actions=[("Update now", lambda: self._do_update(um, info))])
```
To publish an update, host a `manifest.json` and a release zip:
```json
{ "version": "4.1.0",
  "url": "https://your-host/qa-tool/QA_Tool-4.1.0.zip",
  "sha256": "<sha256 of the zip>",
  "notes": "What changed", "mandatory": false }
```

---

## Testing
Every module has a `__main__` self-test. Run any of them directly:
```bash
python enterprise_docx.py      # writes a sample report
python screenshot_compare.py   # synthesizes before/after and diffs them
python defect_assistant.py
python global_search.py
python dashboard.py
python theme_manager.py
python notification_center.py
python update_manager.py
python onedrive_integration.py
```
