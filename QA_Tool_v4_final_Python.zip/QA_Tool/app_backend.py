"""
Developer-only backend configuration.

END USERS NEVER SEE OR EDIT THIS. It is not surfaced anywhere in the UI.
Only the developer (Sachin Sharma) edits these values and ships the build.

Source: Firebase project "qa-snip-python-tool".
  * Project settings → General → "Web API Key"   -> FIREBASE_API_KEY
  * Realtime Database → the database URL          -> FIREBASE_DB_URL
"""

APP_VERSION = "4.0.0"

# ── Firebase (developer-managed) ────────────────────────────────────────
FIREBASE_API_KEY = "AIzaSyDO8SxOUXwGi1KH4gcRcetU_bNokW-Ly9I"
FIREBASE_DB_URL  = "https://qa-snip-python-tool-default-rtdb.firebaseio.com"

# Full web config (for reference / future Storage or Analytics use):
#   authDomain:        "qa-snip-python-tool.firebaseapp.com"
#   projectId:         "qa-snip-python-tool"
#   storageBucket:     "qa-snip-python-tool.firebasestorage.app"
#   messagingSenderId: "301384238830"
#   appId:             "1:301384238830:web:28620570ec47d21900d5ff"
#   measurementId:     "G-SC6YGSD56C"

# Allow a logged-out / offline run during development if auth isn't set up yet.
# Set to False for production builds so login is STRICTLY enforced (recommended,
# now that Firebase is configured).
ALLOW_OFFLINE_DEV = True


def backend_configured() -> bool:
    return bool(FIREBASE_API_KEY and FIREBASE_DB_URL)
