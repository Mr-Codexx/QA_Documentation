"""
AI Defect Assistant - v4.0

Turns a captured step (+ optional AI analysis) into a structured, copy-ready
defect report: summary, steps to reproduce, expected/actual, and suggested
severity & priority. No external bug-tracker integration required.

Severity/priority are inferred from keyword heuristics over the AI bug_hint /
observations, with an optional AIProcessor pass for a richer suggestion.

Public API
----------
    da = DefectAssistant(ai_processor=None)
    report = da.build(session, step)         # -> DefectReport
    report.to_markdown()
    report.to_clipboard_text()
    report.to_jira_text()
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional


SEVERITY_RULES = [
    ("Critical", ["crash", "data loss", "cannot", "blocked", "freeze", "hang",
                  "corrupt", "security", "exception", "fatal", "500", "stack trace"]),
    ("High", ["error", "fail", "broken", "incorrect", "wrong", "missing",
              "not working", "unresponsive", "404", "timeout"]),
    ("Medium", ["misaligned", "overlap", "slow", "delay", "inconsistent",
                "truncated", "cut off", "validation"]),
    ("Low", ["cosmetic", "typo", "spacing", "color", "minor", "alignment",
             "padding", "tooltip"]),
]

PRIORITY_BY_SEVERITY = {
    "Critical": "P1 - Urgent",
    "High": "P2 - High",
    "Medium": "P3 - Medium",
    "Low": "P4 - Low",
}


@dataclass
class DefectReport:
    title: str
    summary: str
    steps_to_reproduce: List[str]
    expected: str
    actual: str
    severity: str
    priority: str
    environment: str = ""
    step_id: str = ""
    screenshot: str = ""
    confidence: str = "heuristic"
    extra: List[str] = field(default_factory=list)

    def to_markdown(self) -> str:
        steps = "\n".join(f"{i}. {s}" for i, s in enumerate(self.steps_to_reproduce, 1))
        md = [
            f"# {self.title}",
            "",
            f"**Severity:** {self.severity}  |  **Priority:** {self.priority}",
            f"**Environment:** {self.environment or 'Not specified'}",
            "",
            "## Summary",
            self.summary,
            "",
            "## Steps to Reproduce",
            steps or "1. (add steps)",
            "",
            "## Expected Result",
            self.expected or "(describe expected behaviour)",
            "",
            "## Actual Result",
            self.actual or "(describe actual behaviour)",
        ]
        if self.screenshot:
            md += ["", "## Evidence", f"Screenshot: `{self.screenshot}`"]
        if self.extra:
            md += ["", "## Notes", *[f"- {e}" for e in self.extra]]
        return "\n".join(md)

    def to_clipboard_text(self) -> str:
        return self.to_markdown()

    def to_jira_text(self) -> str:
        steps = "\n".join(f"# {s}" for s in self.steps_to_reproduce)
        return (
            f"h2. {self.title}\n"
            f"*Severity:* {self.severity}  *Priority:* {self.priority}\n"
            f"*Environment:* {self.environment or 'Not specified'}\n\n"
            f"h3. Summary\n{self.summary}\n\n"
            f"h3. Steps to Reproduce\n{steps}\n\n"
            f"h3. Expected\n{self.expected}\n\n"
            f"h3. Actual\n{self.actual}\n"
        )


class DefectAssistant:
    def __init__(self, ai_processor=None):
        self.ai = ai_processor

    # ---- severity inference -------------------------------------------
    def infer_severity(self, text: str) -> str:
        low = (text or "").lower()
        for sev, kws in SEVERITY_RULES:
            if any(k in low for k in kws):
                return sev
        return "Medium"

    # ---- main builder --------------------------------------------------
    def build(self, session, step, environment: str = "") -> DefectReport:
        desc = getattr(step, "description", "") or ""
        expected = getattr(step, "expected_behavior", "") or ""
        actual = getattr(step, "actual_observation", "") or ""
        bug_hint = getattr(step, "bug_hint", "") or ""

        signal = " ".join([bug_hint, actual, desc])
        severity = self.infer_severity(signal)

        # Build steps to reproduce from prior steps in the session.
        steps_to_repro = self._reproduction_path(session, step)

        title = self._make_title(desc, bug_hint)
        summary = bug_hint if bug_hint and "no obvious" not in bug_hint.lower() else \
            (actual or desc or "Observed unexpected behaviour during testing.")

        env = environment or self._guess_env(session)

        report = DefectReport(
            title=title,
            summary=summary.strip(),
            steps_to_reproduce=steps_to_repro,
            expected=expected.strip(),
            actual=actual.strip(),
            severity=severity,
            priority=PRIORITY_BY_SEVERITY[severity],
            environment=env,
            step_id=getattr(step, "step_id", ""),
            screenshot=getattr(step, "image_path", "") or "",
        )

        # Optional AI enrichment (best-effort, never blocks).
        if self.ai is not None and not getattr(self.ai, "fallback_mode", True):
            self._enrich_with_ai(report, step)

        return report

    def _reproduction_path(self, session, step) -> List[str]:
        steps = []
        try:
            for s in session.steps:
                label = (s.description or s.capture_type).strip()
                if label:
                    steps.append(label)
                if getattr(s, "step_id", None) == getattr(step, "step_id", None):
                    break
        except Exception:
            pass
        if not steps:
            steps = [step.description or "Reproduce the captured action."]
        return steps

    def _make_title(self, desc: str, bug_hint: str) -> str:
        if bug_hint and "no obvious" not in bug_hint.lower():
            base = bug_hint
        else:
            base = desc or "Unexpected behaviour observed"
        base = re.sub(r"\s+", " ", base).strip().rstrip(".")
        return base[:90] + ("..." if len(base) > 90 else "")

    def _guess_env(self, session) -> str:
        meta = getattr(session, "metadata", {}) or {}
        env = meta.get("environment") or meta.get("application")
        return env or ""

    def _enrich_with_ai(self, report: DefectReport, step):
        img = getattr(step, "image_path", None)
        if not img:
            return
        prompt = (
            "You are a senior QA engineer. Based on this screenshot, return ONLY JSON "
            'with fields: {"severity": "Critical|High|Medium|Low", '
            '"priority": "P1|P2|P3|P4", "summary": "one sentence", '
            '"steps": ["step1","step2"]}.'
        )
        try:
            res = self.ai.analyze_screenshot(img, custom_prompt=prompt)
            if isinstance(res, dict):
                sev = res.get("severity")
                if sev in PRIORITY_BY_SEVERITY:
                    report.severity = sev
                    report.priority = PRIORITY_BY_SEVERITY[sev]
                    report.confidence = "ai"
                if res.get("summary"):
                    report.summary = res["summary"]
                if isinstance(res.get("steps"), list) and res["steps"]:
                    report.steps_to_reproduce = res["steps"]
        except Exception as e:
            report.extra.append(f"AI enrichment skipped: {e}")


if __name__ == "__main__":
    # self-test with lightweight stand-ins matching the app's data model
    class S:
        def __init__(self, **k): self.__dict__.update(k)

    sess = S(metadata={"environment": "Windows 11 / Chrome 124"}, steps=[])
    s1 = S(step_id="a1", description="Open login page", capture_type="full_screen",
           expected_behavior="", actual_observation="", bug_hint="", image_path=None)
    s2 = S(step_id="a2", description="Submit empty form", capture_type="snip",
           expected_behavior="Validation error should appear",
           actual_observation="Application crashes with a 500 error",
           bug_hint="Server returns 500 internal error on empty submit",
           image_path=None)
    sess.steps = [s1, s2]

    da = DefectAssistant(ai_processor=None)
    rep = da.build(sess, s2)
    print(rep.to_markdown())
    print("\n--- severity inferred:", rep.severity, "/", rep.priority)
