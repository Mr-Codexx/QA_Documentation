import os
import sys
from datetime import datetime
from PyQt6.QtWidgets import (QWidget, QApplication, QRubberBand,
                             QVBoxLayout, QHBoxLayout, QPushButton,
                             QLabel, QFrame, QComboBox, QDialog,
                             QTextEdit, QColorDialog, QSlider, QSpinBox,
                             QToolButton, QButtonGroup, QStackedWidget,
                             QScrollArea, QSizePolicy, QMainWindow,
                             QGraphicsView, QGraphicsScene, QGraphicsPixmapItem,
                             QGraphicsOpacityEffect)
from PyQt6.QtCore import (Qt, QRect, QPoint, pyqtSignal, QTimer, QSize,
                          QPointF, QRectF, QThread, QObject, QEvent, QEventLoop,
                          QPropertyAnimation, QEasingCurve, QSequentialAnimationGroup)
from PyQt6.QtGui import (QPixmap, QPainter, QPen, QColor, QFont,
                         QGuiApplication, QScreen, QBrush, QIcon,
                         QPainterPath, QPolygon, QCursor, QKeySequence,
                         QShortcut, QImage, QLinearGradient, QRadialGradient,
                         QPalette, QFontDatabase, QTransform, QBitmap)

from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import numpy as np
from io import BytesIO
import math
import time


# ─────────────────────────── THEME ───────────────────────────
THEME = {
    "bg_deep":        "#04040c",
    "bg_card":        "#0d0d1f",
    "bg_surface":     "#12122a",
    "bg_elevated":    "#1a1a38",
    "accent":         "#6c63ff",
    "accent_glow":    "rgba(108,99,255,0.3)",
    "accent_2":       "#a78bfa",
    "accent_3":       "#10b981",
    "accent_4":       "#f59e0b",
    "accent_5":       "#38bdf8",
    "text_primary":   "#e8e8ff",
    "text_secondary": "#8888bb",
    "text_muted":     "#4a4a77",
    "border":         "#1e1e38",
    "border_bright":  "#2a2a5a",
    "danger":         "#ef4444",
    "success":        "#10b981",
    "warning":        "#f59e0b",
}

GLOBAL_STYLE = f"""
QWidget {{
    background-color: {THEME['bg_deep']};
    color: {THEME['text_primary']};
    font-family: 'Sora', 'Segoe UI', 'SF Pro Display', Helvetica, sans-serif;
    font-size: 13px;
}}
QToolTip {{
    background-color: {THEME['bg_elevated']};
    color: {THEME['text_primary']};
    border: 1px solid {THEME['accent']};
    border-radius: 8px;
    padding: 6px 12px;
    font-size: 11px;
    letter-spacing: 0.3px;
}}
QScrollBar:vertical {{
    background: {THEME['bg_card']};
    width: 5px;
    border-radius: 3px;
}}
QScrollBar::handle:vertical {{
    background: {THEME['accent']};
    border-radius: 3px;
    min-height: 20px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
QScrollBar:horizontal {{
    background: {THEME['bg_card']};
    height: 5px;
    border-radius: 3px;
}}
QScrollBar::handle:horizontal {{
    background: {THEME['accent']};
    border-radius: 3px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}
"""


# ─────────────────────────── DRAWING TOOL ───────────────────────────
class DrawingTool:
    NONE        = "none"
    PEN         = "pen"
    HIGHLIGHTER = "highlighter"
    RECTANGLE   = "rectangle"
    ELLIPSE     = "ellipse"
    LINE        = "line"
    ARROW       = "arrow"
    TEXT        = "text"
    BLUR        = "blur"
    ERASER      = "eraser"
    CROP        = "crop"


# ─────────────────────────── HIGHLIGHTER CURSOR ───────────────────────────
def make_highlighter_cursor(color: QColor, width: int) -> QCursor:
    size    = max(min(width, 96), 24)
    px_size = size + 8

    img = QImage(px_size, px_size, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)

    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    nib_color = QColor(color)
    nib_color.setAlpha(180)
    p.setBrush(QBrush(nib_color))
    p.setPen(QPen(QColor(255, 255, 255, 200), 1.5))

    nib_w = max(int(size * 0.8), 14)
    nib_h = max(int(size * 0.35), 8)
    nib_x = (px_size - nib_w) // 2
    nib_y = (px_size - nib_h) // 2
    p.drawRoundedRect(nib_x, nib_y, nib_w, nib_h, 3, 3)

    cx, cy = px_size // 2, px_size // 2
    p.setPen(QPen(QColor(255, 255, 255, 230), 1))
    p.drawLine(cx - 3, cy, cx + 3, cy)
    p.drawLine(cx, cy - 3, cx, cy + 3)
    p.end()

    pixmap = QPixmap.fromImage(img)
    return QCursor(pixmap, px_size // 2, px_size // 2)


# ─────────────────────────── GLOBAL WIDGET REGISTRY ───────────────────────────
_REGISTERED_UI_WIDGETS: list = []

def register_ui_widget(widget: QWidget):
    if widget not in _REGISTERED_UI_WIDGETS:
        _REGISTERED_UI_WIDGETS.append(widget)

def unregister_ui_widget(widget: QWidget):
    if widget in _REGISTERED_UI_WIDGETS:
        _REGISTERED_UI_WIDGETS.remove(widget)

def hide_all_ui_widgets() -> list:
    hidden = []
    for w in list(_REGISTERED_UI_WIDGETS):
        try:
            if w and w.isVisible():
                w.hide()
                hidden.append(w)
        except RuntimeError:
            pass
    QApplication.processEvents()
    return hidden

def show_ui_widgets(widgets: list):
    for w in widgets:
        try:
            if w:
                w.show()
        except RuntimeError:
            pass
    QApplication.processEvents()


# ─────────────────────────── SCREENSHOT TOOL CORE ───────────────────────────
class ScreenshotTool:
    def __init__(self):
        self.snipping_overlay     = None
        self.last_capture_time    = 0
        self.floating_toolbar     = None
        self.active_session_popup = None
        self._snipping_active     = False
    def compare(self, before_path: str, after_path: str, out_dir: str = "."):
        """v4.0: before/after visual regression comparison (returns ComparisonResult)."""
        from screenshot_compare import compare_images
        return compare_images(before_path, after_path, out_dir=out_dir)

    def _hide_ui(self) -> list:
        self._snipping_active = True
        hidden = hide_all_ui_widgets()
        for w in [self.floating_toolbar, self.active_session_popup]:
            if w and w not in hidden:
                try:
                    if w.isVisible():
                        w.hide()
                        hidden.append(w)
                except RuntimeError:
                    pass
        QApplication.processEvents()
        return hidden

    def _show_ui(self, hidden_widgets: list = None):
        self._snipping_active = False
        if hidden_widgets is not None:
            show_ui_widgets(hidden_widgets)
        else:
            for w in list(_REGISTERED_UI_WIDGETS):
                try:
                    if w: w.show()
                except RuntimeError:
                    pass
            for w in [self.floating_toolbar, self.active_session_popup]:
                if w:
                    try: w.show()
                    except RuntimeError: pass
            QApplication.processEvents()

    @staticmethod
    def get_all_screens():
        return QGuiApplication.screens()

    @staticmethod
    def _grab_screen_native(screen: QScreen) -> QPixmap:
        geom   = screen.geometry()
        dpr    = screen.devicePixelRatio()
        pixmap = screen.grabWindow(0, geom.x(), geom.y(), geom.width(), geom.height())
        pixmap.setDevicePixelRatio(dpr)
        return pixmap

    def capture_full_screen(self, save_path: str, screen_index: int = 0) -> str:
        now = datetime.now().timestamp()
        if now - self.last_capture_time < 0.5:
            return None
        self.last_capture_time = now

        hidden = self._hide_ui()
        QApplication.processEvents()
        time.sleep(0.18)
        QApplication.processEvents()

        screens = self.get_all_screens()
        screen  = screens[screen_index] if screen_index < len(screens) \
                  else QGuiApplication.primaryScreen()

        pixmap   = self._grab_screen_native(screen)
        filepath = self._save(pixmap, save_path, "fullscreen")

        self._show_ui(hidden)
        return filepath

    def capture_all_screens(self, save_path: str) -> list:
        hidden = self._hide_ui()
        QApplication.processEvents()
        time.sleep(0.18)
        QApplication.processEvents()

        paths = []
        for i, screen in enumerate(self.get_all_screens()):
            px = self._grab_screen_native(screen)
            paths.append(self._save(px, save_path, f"screen{i+1}"))

        self._show_ui(hidden)
        return paths

    def capture_snipping_area(self, save_path: str) -> str:
        hidden = self._hide_ui()
        QApplication.processEvents()
        time.sleep(0.18)
        QApplication.processEvents()

        result_pixmap = None
        event_loop    = QEventLoop()

        def on_snip_completed(pixmap):
            nonlocal result_pixmap
            result_pixmap = pixmap
            event_loop.quit()

        overlay = HighQualitySnippingOverlay(self.get_all_screens())
        overlay.snip_completed.connect(on_snip_completed)
        overlay.showFullScreen()
        overlay.activateWindow()
        overlay.raise_()

        event_loop.exec()
        self._show_ui(hidden)

        if result_pixmap and not result_pixmap.isNull():
            return self._save(result_pixmap, save_path, "snip")
        return None

    @staticmethod
    def _save(pixmap: QPixmap, save_path: str, prefix: str) -> str:
        if not pixmap or pixmap.isNull():
            return None
        os.makedirs(save_path, exist_ok=True)
        ts   = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        path = os.path.join(save_path, f"{prefix}_{ts}.png")
        pixmap.save(path, "PNG", 100)
        print(f"✅ Saved: {path}")
        return path


# ─────────────────────────── SNIPPING OVERLAY ───────────────────────────
class HighQualitySnippingOverlay(QWidget):
    snip_completed = pyqtSignal(QPixmap)

    def __init__(self, screens=None):
        super().__init__()
        self.screens = screens or QGuiApplication.screens()

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.BypassWindowManagerHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setMouseTracking(True)

        self._virtual_rect = QRect()
        for s in self.screens:
            self._virtual_rect = self._virtual_rect.united(s.geometry())

        self.setGeometry(self._virtual_rect)

        self._raw_background = self._composite_all_screens()
        self._dim_background  = self._apply_dim(self._raw_background)

        self._start  = QPoint()
        self._end    = QPoint()
        self._sel    = QRect()
        self._active = False
        self._shift  = False
        self._done   = False

        self.setCursor(Qt.CursorShape.CrossCursor)
        self._setup_labels()

    def _composite_all_screens(self) -> QPixmap:
        vr      = self._virtual_rect
        max_dpr = max(s.devicePixelRatio() for s in self.screens)
        pw      = int(vr.width()  * max_dpr)
        ph      = int(vr.height() * max_dpr)

        composed = QPixmap(pw, ph)
        composed.setDevicePixelRatio(max_dpr)
        composed.fill(Qt.GlobalColor.black)

        p = QPainter(composed)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

        for screen in self.screens:
            sg  = screen.geometry()
            dpr = screen.devicePixelRatio()
            grab = screen.grabWindow(0, sg.x(), sg.y(), sg.width(), sg.height())
            grab.setDevicePixelRatio(dpr)

            dx = int((sg.x() - vr.x()) * max_dpr)
            dy = int((sg.y() - vr.y()) * max_dpr)
            dw = int(sg.width()  * max_dpr)
            dh = int(sg.height() * max_dpr)

            scaled = grab.scaled(dw, dh,
                                 Qt.AspectRatioMode.IgnoreAspectRatio,
                                 Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap(dx, dy, scaled)

        p.end()
        return composed

    def _apply_dim(self, src: QPixmap) -> QPixmap:
        result = src.copy()
        p = QPainter(result)
        p.fillRect(result.rect(), QColor(0, 0, 0, 120))
        p.end()
        return result

    def _setup_labels(self):
        self._hint = QLabel(
            "  ✂  Click & drag to select   ·   Shift = square   ·   Esc = cancel  ", self
        )
        self._hint.setStyleSheet("""
            background: rgba(8,8,20,220);
            color: #a78bfa;
            font-size: 13px; font-weight: 600;
            padding: 10px 22px;
            border-radius: 12px;
            border: 1px solid rgba(108,99,255,0.5);
            letter-spacing: 0.5px;
        """)
        self._hint.adjustSize()
        self._hint.move(24, 24)

        self._dim_lbl = QLabel(self)
        self._dim_lbl.setStyleSheet("""
            background: rgba(108,99,255,0.9);
            color: white;
            font-size: 12px; font-weight: 700;
            padding: 4px 12px;
            border-radius: 8px;
            font-family: 'JetBrains Mono', monospace;
        """)
        self._dim_lbl.hide()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        p.drawPixmap(self.rect(), self._dim_background, self._dim_background.rect())

        if self._active and not self._sel.isEmpty():
            dpr = self._raw_background.devicePixelRatio()
            src_rect = QRect(
                int(self._sel.x() * dpr), int(self._sel.y() * dpr),
                int(self._sel.width() * dpr), int(self._sel.height() * dpr),
            )
            p.drawPixmap(self._sel, self._raw_background, src_rect)

            # Main selection border
            pen = QPen(QColor("#6c63ff"), 2)
            p.setPen(pen)
            p.drawRect(self._sel.adjusted(0, 0, -1, -1))

            # Glow effect
            for alpha, extra in [(30, 4), (15, 8)]:
                glow_pen = QPen(QColor(108, 99, 255, alpha), extra)
                p.setPen(glow_pen)
                p.drawRect(self._sel.adjusted(-extra//2, -extra//2, extra//2, extra//2))

            # Corner + midpoint handles
            p.setPen(Qt.PenStyle.NoPen)
            hs = 7
            for cx, cy, big in [
                (self._sel.left(),         self._sel.top(),         True),
                (self._sel.right(),        self._sel.top(),         True),
                (self._sel.left(),         self._sel.bottom(),      True),
                (self._sel.right(),        self._sel.bottom(),      True),
                (self._sel.center().x(),   self._sel.top(),         False),
                (self._sel.center().x(),   self._sel.bottom(),      False),
                (self._sel.left(),         self._sel.center().y(),  False),
                (self._sel.right(),        self._sel.center().y(),  False),
            ]:
                sz = hs if big else hs - 2
                # Outer white ring
                p.setBrush(QColor(255, 255, 255, 200))
                p.drawEllipse(cx - sz//2 - 1, cy - sz//2 - 1, sz + 2, sz + 2)
                # Inner accent
                p.setBrush(QColor("#6c63ff"))
                p.drawEllipse(cx - sz//2, cy - sz//2, sz, sz)

        p.end()

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._start  = e.pos()
            self._end    = e.pos()
            self._sel    = QRect()
            self._active = True
            self._dim_lbl.show()

    def mouseMoveEvent(self, e):
        if not self._active:
            return
        self._end = e.pos()

        if self._shift:
            dx = self._end.x() - self._start.x()
            dy = self._end.y() - self._start.y()
            s  = max(abs(dx), abs(dy))
            self._end = QPoint(
                self._start.x() + (s if dx >= 0 else -s),
                self._start.y() + (s if dy >= 0 else -s)
            )

        self._sel = QRect(self._start, self._end).normalized()
        self.update()

        w, h = self._sel.width(), self._sel.height()
        self._dim_lbl.setText(f"  {w} × {h}  ")
        self._dim_lbl.adjustSize()
        lx = self._sel.x()
        ly = self._sel.y() - self._dim_lbl.height() - 8
        if ly < 0:
            ly = self._sel.bottom() + 8
        self._dim_lbl.move(lx, ly)

    def mouseReleaseEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton or self._done:
            return
        self._active = False
        self._dim_lbl.hide()

        if self._sel.width() < 5 or self._sel.height() < 5:
            self._launch_editor(self._grab_primary_full())
            return

        cropped = self._crop_selection(self._sel)
        self._launch_editor(cropped)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self._done = True
            self.snip_completed.emit(QPixmap())
            self.close()
        elif e.key() == Qt.Key.Key_Shift:
            self._shift = True
        elif e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if self._sel.width() > 5 and self._sel.height() > 5:
                cropped = self._crop_selection(self._sel)
                self._launch_editor(cropped)

    def keyReleaseEvent(self, e):
        if e.key() == Qt.Key.Key_Shift:
            self._shift = False

    def _crop_selection(self, sel: QRect) -> QPixmap:
        dpr = self._raw_background.devicePixelRatio()
        src = QRect(
            int(sel.x() * dpr), int(sel.y() * dpr),
            int(sel.width() * dpr), int(sel.height() * dpr),
        )
        cropped = self._raw_background.copy(src)
        cropped.setDevicePixelRatio(dpr)
        return cropped

    def _grab_primary_full(self) -> QPixmap:
        return QGuiApplication.primaryScreen().grabWindow(0)

    def _launch_editor(self, pixmap: QPixmap):
        if self._done:
            return
        self._done = True
        self.hide()
        editor = AdvancedImageEditor(pixmap)
        editor.editing_finished.connect(self._on_edit_done)
        editor.show()
        editor.activateWindow()
        self._editor = editor

    def _on_edit_done(self, pixmap: QPixmap):
        self.snip_completed.emit(pixmap)
        self.close()


# ─────────────────────────── ADVANCED IMAGE EDITOR ───────────────────────────
def _editor_prefs_path():
    import os
    return os.path.join(os.path.expanduser("~"), ".qa_editor_prefs.json")

def _load_editor_prefs():
    import json
    try:
        with open(_editor_prefs_path(), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_editor_prefs(d):
    import json
    try:
        with open(_editor_prefs_path(), "w", encoding="utf-8") as f:
            json.dump(d, f)
    except Exception:
        pass


class AdvancedImageEditor(QMainWindow):
    editing_finished = pyqtSignal(QPixmap)

    def __init__(self, pixmap: QPixmap):
        super().__init__()
        self.original_pixmap = pixmap
        self.current_pixmap  = pixmap.copy()
        self.scale_factor    = 1.0
        self._finished       = False
        self._prefs          = _load_editor_prefs()

        self.drawing       = False
        self.current_tool  = self._prefs.get("last_tool", DrawingTool.PEN)
        self.last_point    = None
        self.start_point   = None
        self.undo_stack    = [pixmap.copy()]
        self.redo_stack    = []

        self.pen_color       = QColor(self._prefs.get("pen_color", "#ef4444"))
        self.pen_width       = int(self._prefs.get("pen_width", 3))
        self.highlight_color = QColor(self._prefs.get("hl_color", "#fff176"))
        self.highlight_width = int(self._prefs.get("hl_width", 22))
        self.blur_radius     = 14
        self.text_font       = QFont("Segoe UI", 16, QFont.Weight.Bold)
        self.highlight_regions = []
        self._init_ui()
        self._setup_shortcuts()
        if self.current_tool not in self.tool_buttons:
            self.current_tool = DrawingTool.PEN
        self.set_tool(self.current_tool)
        QTimer.singleShot(120, self._fit_to_window)

    def _init_ui(self):
        self.setWindowTitle("Screenshot Editor  ·  Ctrl+Z = undo  ·  Ctrl+S = save")
        self.setMinimumSize(820, 560)
        self.setStyleSheet(GLOBAL_STYLE + f"""
            QMainWindow, #root_widget {{ background: {THEME['bg_deep']}; }}
        """)

        root = QWidget()
        root.setObjectName("root_widget")
        self.setCentralWidget(root)
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        root_layout.addWidget(self._build_toolbar())

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scroll.setStyleSheet(f"QScrollArea {{ background:{THEME['bg_deep']}; border:none; }}")

        self.canvas = EditorCanvas(self)
        self.canvas.set_pixmap(self.current_pixmap)
        self.scroll.setWidget(self.canvas)
        root_layout.addWidget(self.scroll, 1)
        root_layout.addWidget(self._build_statusbar())

    def _build_toolbar(self) -> QFrame:
        bar = QFrame()
        bar.setFixedHeight(54)
        bar.setStyleSheet(f"""
            QFrame {{
                background: {THEME['bg_card']};
                border-bottom: 1px solid {THEME['border']};
            }}
        """)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(4)

        tools = [
            (DrawingTool.PEN,         "✏",  "Pen (P)",              THEME['accent']),
            (DrawingTool.HIGHLIGHTER, "▓",  "Highlighter (H)",      "#f59e0b"),
            (DrawingTool.LINE,        "╱",  "Line (L)",             THEME['text_secondary']),
            (DrawingTool.ARROW,       "➤",  "Arrow (A)",            THEME['text_secondary']),
            (DrawingTool.RECTANGLE,   "▭",  "Rectangle (R)",        THEME['text_secondary']),
            (DrawingTool.ELLIPSE,     "○",  "Ellipse (E)",          THEME['text_secondary']),
            (DrawingTool.TEXT,        "T",  "Text (T)",             "#38bdf8"),
            (DrawingTool.BLUR,        "◉",  "Blur / Redact (B)",    "#a78bfa"),
            (DrawingTool.ERASER,      "◌",  "Eraser (X)",           THEME['text_muted']),
        ]

        self.tool_buttons = {}
        for tid, icon, tip, color in tools:
            btn = self._tool_btn(icon, tip, color)
            btn.clicked.connect(lambda _, t=tid: self.set_tool(t))
            layout.addWidget(btn)
            self.tool_buttons[tid] = btn

        self.tool_buttons[DrawingTool.PEN].setChecked(True)
        layout.addWidget(self._sep())

        self._color_swatch = QPushButton()
        self._color_swatch.setFixedSize(38, 38)
        self._color_swatch.setToolTip("Pen color (C)")
        self._color_swatch.clicked.connect(self._pick_color)
        self._update_swatch()
        layout.addWidget(self._color_swatch)

        self._hl_swatch = QPushButton()
        self._hl_swatch.setFixedSize(38, 38)
        self._hl_swatch.setToolTip("Highlighter color")
        self._hl_swatch.clicked.connect(self._pick_highlight_color)
        self._update_hl_swatch()
        self._hl_swatch.setVisible(False)
        layout.addWidget(self._hl_swatch)

        w_lbl = QLabel("W:")
        w_lbl.setStyleSheet(f"color:{THEME['text_muted']};font-size:10px;letter-spacing:1px;")
        layout.addWidget(w_lbl)

        self.width_slider = QSlider(Qt.Orientation.Horizontal)
        self.width_slider.setRange(1, 60)
        self.width_slider.setValue(self.pen_width)
        self.width_slider.setFixedWidth(90)
        self.width_slider.setStyleSheet(self._slider_style())
        self.width_slider.valueChanged.connect(self._on_width_changed)
        layout.addWidget(self.width_slider)

        self.width_spin = QSpinBox()
        self.width_spin.setRange(1, 60)
        self.width_spin.setValue(self.pen_width)
        self.width_spin.setFixedWidth(54)
        self.width_spin.setStyleSheet(self._spinbox_style())
        self.width_spin.valueChanged.connect(self.width_slider.setValue)
        self.width_slider.valueChanged.connect(self.width_spin.setValue)
        layout.addWidget(self.width_spin)

        layout.addWidget(self._sep())

        undo_btn = self._action_btn("↩", "Undo  Ctrl+Z")
        undo_btn.clicked.connect(self.undo)
        layout.addWidget(undo_btn)

        redo_btn = self._action_btn("↪", "Redo  Ctrl+Y")
        redo_btn.clicked.connect(self.redo)
        layout.addWidget(redo_btn)

        layout.addWidget(self._sep())

        copy_btn = self._action_btn("⧉ Copy", "Copy to clipboard  Ctrl+C")
        copy_btn.clicked.connect(self._copy_clipboard)
        layout.addWidget(copy_btn)

        save_btn = self._action_btn("💾 Save", "Save file  Ctrl+S")
        save_btn.clicked.connect(self._save_file)
        layout.addWidget(save_btn)

        layout.addStretch()

        done_btn = QPushButton("  ✔  Done  ")
        done_btn.setFixedHeight(38)
        done_btn.setStyleSheet(f"""
            QPushButton {{
                background: {THEME['accent_3']};
                color: #022c1a;
                font-weight: 700; font-size: 13px;
                border: none; border-radius: 10px; padding: 0 22px;
                letter-spacing: 0.5px;
            }}
            QPushButton:hover {{ background: #34d399; }}
            QPushButton:pressed {{ background: #059669; }}
        """)
        done_btn.clicked.connect(self._finish)
        layout.addWidget(done_btn)

        cancel_btn = QPushButton("✕")
        cancel_btn.setFixedSize(38, 38)
        cancel_btn.setToolTip("Cancel (Esc)")
        cancel_btn.setStyleSheet(f"""
            QPushButton {{
                background: {THEME['bg_elevated']};
                color: {THEME['danger']};
                border: 1px solid {THEME['danger']}44;
                font-weight: 700; font-size: 15px; border-radius: 10px;
            }}
            QPushButton:hover {{
                background: {THEME['danger']}22;
                border-color: {THEME['danger']};
            }}
        """)
        cancel_btn.clicked.connect(self._cancel)
        layout.addWidget(cancel_btn)

        return bar

    def _build_statusbar(self) -> QFrame:
        bar = QFrame()
        bar.setFixedHeight(30)
        bar.setStyleSheet(f"""
            QFrame {{ background:{THEME['bg_card']}; border-top:1px solid {THEME['border']}; }}
            QLabel {{ color:{THEME['text_muted']}; font-size:11px; font-family:monospace; }}
        """)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(14, 0, 14, 0)
        layout.setSpacing(20)

        self._pos_lbl  = QLabel("Position: —")
        self._size_lbl = QLabel(
            f"Size: {self.original_pixmap.width()} × {self.original_pixmap.height()} px"
        )
        self._tool_lbl = QLabel("Tool: Pen")
        layout.addWidget(self._pos_lbl)
        layout.addWidget(self._size_lbl)
        layout.addStretch()
        layout.addWidget(self._tool_lbl)

        layout.addWidget(QLabel("Zoom:"))
        self.zoom_combo = QComboBox()
        self.zoom_combo.addItems(["Fit", "25%", "50%", "75%", "100%", "150%", "200%", "300%"])
        self.zoom_combo.setCurrentText("Fit")
        self.zoom_combo.setFixedWidth(78)
        self.zoom_combo.setStyleSheet(f"""
            QComboBox {{
                background:{THEME['bg_elevated']};color:{THEME['text_primary']};
                border:1px solid {THEME['border']};border-radius:6px;
                padding:2px 8px;font-size:11px;
            }}
            QComboBox::drop-down{{border:none;}}
            QComboBox QAbstractItemView{{
                background:{THEME['bg_elevated']};color:{THEME['text_primary']};
                selection-background-color:{THEME['accent']};
                border:1px solid {THEME['border']};
            }}
        """)
        self.zoom_combo.currentTextChanged.connect(self._on_zoom_changed)
        layout.addWidget(self.zoom_combo)

        return bar

    def _tool_btn(self, icon: str, tip: str, accent: str = None) -> QToolButton:
        a = accent or THEME['accent']
        btn = QToolButton()
        btn.setText(icon)
        btn.setToolTip(tip)
        btn.setCheckable(True)
        btn.setFixedSize(40, 40)
        btn.setStyleSheet(f"""
            QToolButton {{
                background:{THEME['bg_surface']};color:{THEME['text_secondary']};
                font-size:16px;border:1px solid {THEME['border']};border-radius:10px;
            }}
            QToolButton:hover {{
                background:{THEME['bg_elevated']};
                border-color:{a}88;color:{THEME['text_primary']};
            }}
            QToolButton:checked {{
                background:{a}22;color:{a};
                border-color:{a};
            }}
            QToolButton:pressed{{background:{a}33;}}
        """)
        return btn

    def _action_btn(self, icon: str, tip: str) -> QToolButton:
        btn = QToolButton()
        btn.setText(icon)
        btn.setToolTip(tip)
        btn.setFixedHeight(38)
        btn.setStyleSheet(f"""
            QToolButton {{
                background:{THEME['bg_surface']};color:{THEME['text_secondary']};
                font-size:12px;border:1px solid {THEME['border']};
                border-radius:9px;padding:0 12px;
            }}
            QToolButton:hover{{
                background:{THEME['bg_elevated']};color:{THEME['text_primary']};
                border-color:{THEME['border_bright']};
            }}
            QToolButton:pressed{{background:{THEME['accent']}22;color:{THEME['accent']};}}
        """)
        return btn

    def _sep(self) -> QFrame:
        s = QFrame()
        s.setFrameShape(QFrame.Shape.VLine)
        s.setFixedHeight(32)
        s.setStyleSheet(f"color:{THEME['border']};")
        return s

    @staticmethod
    def _slider_style():
        return f"""
            QSlider::groove:horizontal {{
                height:4px;background:{THEME['bg_elevated']};border-radius:2px;
            }}
            QSlider::handle:horizontal {{
                background:{THEME['accent']};width:14px;height:14px;
                margin:-5px 0;border-radius:7px;
            }}
            QSlider::sub-page:horizontal{{background:{THEME['accent']};border-radius:2px;}}
        """

    @staticmethod
    def _spinbox_style():
        return f"""
            QSpinBox {{
                background:{THEME['bg_elevated']};color:{THEME['text_primary']};
                border:1px solid {THEME['border']};border-radius:8px;
                padding:5px;font-size:12px;font-family:monospace;
            }}
            QSpinBox::up-button,QSpinBox::down-button{{width:16px;}}
        """

    def _setup_shortcuts(self):
        def sc(seq, fn):
            QShortcut(QKeySequence(seq), self).activated.connect(fn)
        sc("Ctrl+Z", self.undo)
        sc("Ctrl+Y", self.redo)
        sc("Ctrl+Shift+Z", self.redo)
        sc("Ctrl+C", self._copy_clipboard)
        sc("Ctrl+S", self._save_file)
        sc("P", lambda: self.set_tool(DrawingTool.PEN))
        sc("H", lambda: self.set_tool(DrawingTool.HIGHLIGHTER))
        sc("L", lambda: self.set_tool(DrawingTool.LINE))
        sc("A", lambda: self.set_tool(DrawingTool.ARROW))
        sc("R", lambda: self.set_tool(DrawingTool.RECTANGLE))
        sc("E", lambda: self.set_tool(DrawingTool.ELLIPSE))
        sc("T", lambda: self.set_tool(DrawingTool.TEXT))
        sc("B", lambda: self.set_tool(DrawingTool.BLUR))
        sc("X", lambda: self.set_tool(DrawingTool.ERASER))
        sc("Escape", self._cancel)
        sc("+", self._zoom_in)
        sc("=", self._zoom_in)
        sc("-", self._zoom_out)

    def set_tool(self, tool):
        self.current_tool = tool
        for t, btn in self.tool_buttons.items():
            btn.setChecked(t == tool)
        self._tool_lbl.setText(f"Tool: {tool.capitalize()}")

        is_hl = (tool == DrawingTool.HIGHLIGHTER)
        self._color_swatch.setVisible(not is_hl)
        self._hl_swatch.setVisible(is_hl)

        if is_hl:
            self.width_slider.blockSignals(True)
            self.width_slider.setRange(8, 60)
            self.width_slider.setValue(self.highlight_width)
            self.width_spin.setRange(8, 60)
            self.width_spin.setValue(self.highlight_width)
            self.width_slider.blockSignals(False)
        else:
            self.width_slider.blockSignals(True)
            self.width_slider.setRange(1, 60)
            self.width_slider.setValue(self.pen_width)
            self.width_spin.setRange(1, 60)
            self.width_spin.setValue(self.pen_width)
            self.width_slider.blockSignals(False)

        self._apply_tool_cursor(tool)
        self._persist_prefs()

    def _persist_prefs(self):
        try:
            _save_editor_prefs({"last_tool": self.current_tool,
                                "pen_color": self.pen_color.name(),
                                "pen_width": int(self.pen_width),
                                "hl_color": self.highlight_color.name(),
                                "hl_width": int(self.highlight_width)})
        except Exception:
            pass

    def _apply_tool_cursor(self, tool):
        if tool == DrawingTool.HIGHLIGHTER:
            cursor = make_highlighter_cursor(self.highlight_color, self.highlight_width)
        elif tool == DrawingTool.TEXT:
            cursor = QCursor(Qt.CursorShape.IBeamCursor)
        elif tool == DrawingTool.ERASER:
            cursor = self._make_eraser_cursor(self.pen_width)
        elif tool == DrawingTool.BLUR:
            cursor = QCursor(Qt.CursorShape.ForbiddenCursor)
        else:
            cursor = QCursor(Qt.CursorShape.CrossCursor)
        self.canvas.setCursor(cursor)

    @staticmethod
    def _make_eraser_cursor(width: int) -> QCursor:
        size = max(min(width * 3, 96), 16)
        img  = QImage(size + 2, size + 2, QImage.Format.Format_ARGB32_Premultiplied)
        img.fill(Qt.GlobalColor.transparent)
        p = QPainter(img)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(QColor(200, 200, 220, 200), 1.5))
        p.setBrush(QBrush(QColor(255, 255, 255, 30)))
        p.drawEllipse(1, 1, size, size)
        p.end()
        cx = (size + 2) // 2
        return QCursor(QPixmap.fromImage(img), cx, cx)

    def _pick_color(self):
        c = QColorDialog.getColor(self.pen_color, self, "Pen Color",
                                  QColorDialog.ColorDialogOption.ShowAlphaChannel)
        if c.isValid():
            self.pen_color = c
            self._update_swatch()

    def _pick_highlight_color(self):
        c = QColorDialog.getColor(self.highlight_color, self, "Highlighter Color",
                                  QColorDialog.ColorDialogOption.ShowAlphaChannel)
        if c.isValid():
            self.highlight_color = c
            self._persist_prefs()
            self._update_hl_swatch()
            if self.current_tool == DrawingTool.HIGHLIGHTER:
                self.canvas.setCursor(make_highlighter_cursor(self.highlight_color, self.highlight_width))

    def _update_swatch(self):
        c = self.pen_color.name()
        self._color_swatch.setStyleSheet(f"""
            QPushButton {{
                background:{c};border:2px solid {THEME['border_bright']};border-radius:10px;
            }}
            QPushButton:hover{{border-color:white;}}
        """)

    def _update_hl_swatch(self):
        r, g, b, a = (self.highlight_color.red(), self.highlight_color.green(),
                      self.highlight_color.blue(), self.highlight_color.alpha())
        self._hl_swatch.setStyleSheet(f"""
            QPushButton {{
                background:rgba({r},{g},{b},{a});
                border:2px solid {THEME['border_bright']};border-radius:10px;
            }}
            QPushButton:hover{{border-color:white;}}
        """)

    def _on_width_changed(self, v):
        if self.current_tool == DrawingTool.HIGHLIGHTER:
            self.highlight_width = v
            self.canvas.setCursor(make_highlighter_cursor(self.highlight_color, v))
        elif self.current_tool == DrawingTool.ERASER:
            self.pen_width = v
            self.canvas.setCursor(self._make_eraser_cursor(v))
        else:
            self.pen_width = v

    def _fit_to_window(self):
        avail = self.scroll.viewport().size()
        img   = self.current_pixmap.size()
        if avail.width() > 0 and img.width() > 0:
            self.scale_factor = min(avail.width() / img.width(),
                                    avail.height() / img.height()) * 0.93
        self._apply_zoom()
        self.zoom_combo.blockSignals(True)
        self.zoom_combo.setCurrentText("Fit")
        self.zoom_combo.blockSignals(False)

    def _on_zoom_changed(self, text):
        if text == "Fit":
            self._fit_to_window()
        else:
            self.scale_factor = int(text.rstrip('%')) / 100
            self._apply_zoom()

    def _zoom_in(self):
        self.scale_factor = min(self.scale_factor * 1.2, 8.0)
        self._apply_zoom()

    def _zoom_out(self):
        self.scale_factor = max(self.scale_factor / 1.2, 0.05)
        self._apply_zoom()

    def _apply_zoom(self):
        w = max(1, int(self.current_pixmap.width()  * self.scale_factor))
        h = max(1, int(self.current_pixmap.height() * self.scale_factor))
        self.canvas.setFixedSize(w, h)
        self.canvas.set_pixmap(self.current_pixmap)

    def save_state(self):
        self.undo_stack.append(self.current_pixmap.copy())
        if len(self.undo_stack) > 80:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def undo(self):
        if len(self.undo_stack) > 1:
            self.redo_stack.append(self.undo_stack.pop())
            self.current_pixmap = self.undo_stack[-1].copy()
            self.canvas.set_pixmap(self.current_pixmap)

    def redo(self):
        if self.redo_stack:
            s = self.redo_stack.pop()
            self.undo_stack.append(s)
            self.current_pixmap = s.copy()
            self.canvas.set_pixmap(self.current_pixmap)

    def _copy_clipboard(self):
        QApplication.clipboard().setPixmap(self.current_pixmap)
        self.setWindowTitle("Screenshot Editor  ·  ✓ Copied to clipboard")
        QTimer.singleShot(2000, lambda: self.setWindowTitle(
            "Screenshot Editor  ·  Ctrl+Z = undo  ·  Ctrl+S = save"))

    def _save_file(self):
        ts   = datetime.now().strftime('%Y%m%d_%H%M%S')
        path = f"screenshot_{ts}.png"
        self.current_pixmap.save(path, "PNG", 100)
        self.setWindowTitle(f"Screenshot Editor  ·  Saved: {path}")

    def _finish(self):
        if not self._finished:
            self._finished = True
            self.editing_finished.emit(self.current_pixmap)
            self.close()

    def _cancel(self):
        if not self._finished:
            self._finished = True
            self.editing_finished.emit(self.current_pixmap)
            self.close()

    def closeEvent(self, e):
        if not self._finished:
            self._finished = True
            self.editing_finished.emit(self.current_pixmap)
        super().closeEvent(e)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self, 'zoom_combo') and self.zoom_combo.currentText() == "Fit":
            QTimer.singleShot(10, self._fit_to_window)


# ─────────────────────────── EDITOR CANVAS ───────────────────────────
class EditorCanvas(QWidget):
    def __init__(self, editor: AdvancedImageEditor):
        super().__init__()
        self.editor = editor
        self._pixmap: QPixmap = QPixmap()
        self._text_widget = None
        self.setMouseTracking(True)
        self.highlight_regions = []

    def set_pixmap(self, pixmap: QPixmap):
        sf = self.editor.scale_factor
        if sf != 1.0:
            w = max(1, int(pixmap.width()  * sf))
            h = max(1, int(pixmap.height() * sf))
            self._pixmap = pixmap.scaled(w, h,
                Qt.AspectRatioMode.IgnoreAspectRatio,
                Qt.TransformationMode.SmoothTransformation)
        else:
            self._pixmap = pixmap.copy()
        self.update()

    def paintEvent(self, _):
        if self._pixmap.isNull():
            return
        p = QPainter(self)
        p.drawPixmap(0, 0, self._pixmap)
        p.end()

    def _widget_to_image(self, pt: QPoint) -> QPoint:
        sf = self.editor.scale_factor
        if sf <= 0:
            return pt
        return QPoint(int(pt.x() / sf), int(pt.y() / sf))

    def mousePressEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton:
            return
        self.editor.save_state()
        self.editor.drawing = True
        img_pt = self._widget_to_image(e.pos())

        if self.editor.current_tool == DrawingTool.TEXT:
            self._show_text_input(e.pos())
            return

        self.editor.start_point = img_pt
        self.editor.last_point  = img_pt

    def mouseMoveEvent(self, e):
        self.editor._pos_lbl.setText(f"Position: {e.pos().x()}, {e.pos().y()}")
        if not (self.editor.drawing and e.buttons() == Qt.MouseButton.LeftButton):
            return

        img_pt = self._widget_to_image(e.pos())
        tool   = self.editor.current_tool

        if tool == DrawingTool.PEN:
            self._draw_pen(self.editor.last_point, img_pt)
            self.set_pixmap(self.editor.current_pixmap)
        elif tool == DrawingTool.HIGHLIGHTER:
            self._draw_highlight(self.editor.last_point, img_pt)
            self.set_pixmap(self.editor.current_pixmap)
        elif tool == DrawingTool.ERASER:
            self._draw_eraser(self.editor.last_point, img_pt)
            self.set_pixmap(self.editor.current_pixmap)
        elif tool in (DrawingTool.LINE, DrawingTool.ARROW,
                      DrawingTool.RECTANGLE, DrawingTool.ELLIPSE):
            self._preview_shape(self.editor.start_point, img_pt)

        self.editor.last_point = img_pt

    def mouseReleaseEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton or not self.editor.drawing:
            return
        img_pt = self._widget_to_image(e.pos())
        tool   = self.editor.current_tool

        if tool == DrawingTool.LINE:
            self._draw_line(self.editor.start_point, img_pt)
        elif tool == DrawingTool.ARROW:
            self._draw_arrow(self.editor.start_point, img_pt)
        elif tool == DrawingTool.RECTANGLE:
            self._draw_rect(self.editor.start_point, img_pt)
        elif tool == DrawingTool.ELLIPSE:
            self._draw_ellipse(self.editor.start_point, img_pt)
        elif tool == DrawingTool.BLUR:
            self._apply_blur(self.editor.start_point, img_pt)

        self.editor.drawing = False
        self.set_pixmap(self.editor.current_pixmap)

    def _painter(self) -> QPainter:
        p = QPainter(self.editor.current_pixmap)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        return p

    def _pen(self, color=None, width=None, cap=Qt.PenCapStyle.RoundCap):
        c = color or self.editor.pen_color
        w = width or self.editor.pen_width
        pen = QPen(c, w)
        pen.setCapStyle(cap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        return pen

    def _draw_pen(self, a, b):
        p = self._painter(); p.setPen(self._pen()); p.drawLine(a, b); p.end()

    def _draw_highlight(self, a, b):
        p = self._painter()
        p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Multiply)
        hl  = QColor(self.editor.highlight_color); hl.setAlpha(255)
        pen = QPen(hl, self.editor.highlight_width)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        p.drawLine(a, b)
        p.end()

    def _draw_eraser(self, a, b):
        p = QPainter(self.editor.current_pixmap)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Source)
        pen = QPen(Qt.GlobalColor.transparent, self.editor.pen_width * 3)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        p.drawLine(a, b)
        p.end()

    def _draw_line(self, a, b):
        p = self._painter(); p.setPen(self._pen()); p.drawLine(a, b); p.end()

    def _draw_arrow(self, a, b):
        p = self._painter()
        p.setPen(self._pen())
        p.drawLine(a, b)
        dx, dy = b.x() - a.x(), b.y() - a.y()
        length = math.hypot(dx, dy)
        if length > 0:
            sz    = min(24, length / 3)
            angle = math.atan2(dy, dx)
            for sign in (1, -1):
                ax = b.x() - sz * math.cos(angle - sign * math.pi / 6)
                ay = b.y() - sz * math.sin(angle - sign * math.pi / 6)
                p.drawLine(b, QPoint(int(ax), int(ay)))
        p.end()

    def _draw_rect(self, a, b):
        p = self._painter()
        p.setPen(self._pen())
        p.drawRect(QRect(a, b).normalized())
        p.end()

    def _draw_ellipse(self, a, b):
        p = self._painter()
        p.setPen(self._pen())
        p.drawEllipse(QRect(a, b).normalized())
        p.end()

    def _apply_blur(self, a, b):
        rect = QRect(a, b).normalized()
        if rect.width() < 4 or rect.height() < 4:
            return
        buf = BytesIO()
        self.editor.current_pixmap.save(buf, "PNG")
        buf.seek(0)
        img = Image.open(buf).convert("RGBA")

        x0, y0 = rect.x(), rect.y()
        x1 = min(x0 + rect.width(),  img.width)
        y1 = min(y0 + rect.height(), img.height)

        region  = img.crop((x0, y0, x1, y1))
        blurred = region.filter(ImageFilter.GaussianBlur(radius=self.editor.blur_radius))
        img.paste(blurred, (x0, y0))

        out = BytesIO()
        img.save(out, "PNG")
        out.seek(0)
        px = QPixmap()
        px.loadFromData(out.read(), "PNG")
        self.editor.current_pixmap = px

    def _preview_shape(self, a, b):
        preview = self.editor.current_pixmap.copy()
        p = QPainter(preview)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        pen = QPen(self.editor.pen_color, self.editor.pen_width, Qt.PenStyle.DashLine)
        p.setPen(pen)

        tool = self.editor.current_tool
        if tool == DrawingTool.LINE:
            p.drawLine(a, b)
        elif tool == DrawingTool.ARROW:
            p.drawLine(a, b)
            dx, dy = b.x() - a.x(), b.y() - a.y()
            length = math.hypot(dx, dy)
            if length > 0:
                sz    = min(24, length / 3)
                angle = math.atan2(dy, dx)
                for sign in (1, -1):
                    ax = b.x() - sz * math.cos(angle - sign * math.pi / 6)
                    ay = b.y() - sz * math.sin(angle - sign * math.pi / 6)
                    p.drawLine(b, QPoint(int(ax), int(ay)))
        elif tool == DrawingTool.RECTANGLE:
            p.drawRect(QRect(a, b).normalized())
        elif tool == DrawingTool.ELLIPSE:
            p.drawEllipse(QRect(a, b).normalized())
        p.end()

        sf = self.editor.scale_factor
        w  = max(1, int(preview.width()  * sf))
        h  = max(1, int(preview.height() * sf))
        self._pixmap = preview.scaled(w, h,
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation)
        self.update()

    def _show_text_input(self, widget_pos: QPoint):
        if self._text_widget:
            self._text_widget.deleteLater()

        te = QTextEdit(self)
        te.setStyleSheet(f"""
            QTextEdit {{
                background:rgba(8,8,20,210);color:{THEME['text_primary']};
                border:2px solid {THEME['accent']};border-radius:8px;
                padding:8px;font-size:15px;font-weight:bold;
            }}
        """)
        te.setFont(self.editor.text_font)
        te.move(widget_pos)
        te.resize(240, 96)
        te.setPlaceholderText("Type here…  Ctrl+Enter = done  Esc = cancel")
        te.show()
        te.setFocus()
        te.installEventFilter(self)
        self._text_widget = te
        self._text_pos    = self._widget_to_image(widget_pos)

    def eventFilter(self, obj, e):
        if obj is self._text_widget and e.type() == QEvent.Type.KeyPress:
            if (e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and
                    e.modifiers() == Qt.KeyboardModifier.ControlModifier):
                self._commit_text()
                return True
            if e.key() == Qt.Key.Key_Escape:
                self._text_widget.deleteLater()
                self._text_widget = None
                return True
        return super().eventFilter(obj, e)

    def _commit_text(self):
        if not self._text_widget:
            return
        text = self._text_widget.toPlainText().strip()
        if text:
            p = self._painter()
            p.setFont(self.editor.text_font)
            p.setPen(QPen(self.editor.pen_color))
            p.drawText(self._text_pos, text)
            p.end()
            self.set_pixmap(self.editor.current_pixmap)
        self._text_widget.deleteLater()
        self._text_widget = None


# ───────────────────────────  FLOATING TOOLBAR ───────────────────────────
class FloatingToolbar(QWidget):
    """
    Cinematic floating toolbar with glass morphism aesthetic.
    Draggable, always-on-top, registered in global widget registry.
    """
    sig_full_screen = pyqtSignal(int)
    sig_snip        = pyqtSignal()
    sig_all_screens = pyqtSignal()
    sig_note        = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool |
            Qt.WindowType.NoDropShadowWindowHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._drag_pos  = None
        self._throttle  = {}
        self._collapsed = False

        self._build_ui()

        sg = QGuiApplication.primaryScreen().geometry()
        self.adjustSize()
        self.move(sg.width() - self.width() - 24, sg.top() + 28)

        self._raise_timer = QTimer(self)
        self._raise_timer.timeout.connect(self._force_top)
        self._raise_timer.start(1500)

        register_ui_widget(self)

    def __del__(self):
        unregister_ui_widget(self)

    def _force_top(self):
        if self.isVisible():
            self.raise_()
            try:
                import ctypes
                HWND_TOPMOST = -1
                flags = 0x0002 | 0x0001 | 0x0010 | 0x0040
                ctypes.windll.user32.SetWindowPos(
                    int(self.winId()), HWND_TOPMOST, 0, 0, 0, 0, flags)
            except Exception:
                pass

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 6)

        self._frame = QFrame()
        self._frame.setObjectName("tb_frame")
        self._frame.setStyleSheet(f"""
            QFrame#tb_frame {{
                background: rgba(8,8,20,240);
                border: 1px solid rgba(108,99,255,0.5);
                border-radius: 18px;
            }}
        """)
        fl = QHBoxLayout(self._frame)
        fl.setContentsMargins(14, 8, 14, 8)
        fl.setSpacing(8)

        # Logo / brand
        logo = QLabel("◆")
        logo.setStyleSheet(f"""
            color: {THEME['accent']};
            font-size: 14px;
            font-weight: 900;
        """)
        fl.addWidget(logo)

        brand = QLabel("SnapKit")
        brand.setStyleSheet(f"""
            color: {THEME['text_primary']};
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 0.5px;
        """)
        fl.addWidget(brand)

        self._vsep(fl)

        # Screen selector (multi-monitor)
        self._screens = QGuiApplication.screens()
        if len(self._screens) > 1:
            monitor_lbl = QLabel("🖥")
            monitor_lbl.setToolTip("Monitor")
            monitor_lbl.setStyleSheet("font-size:14px;")
            fl.addWidget(monitor_lbl)

            self.screen_combo = QComboBox()
            for i, s in enumerate(self._screens):
                g = s.geometry()
                self.screen_combo.addItem(f"Screen {i+1}  {g.width()}×{g.height()}")
            self.screen_combo.setFixedWidth(160)
            self.screen_combo.setStyleSheet(f"""
                QComboBox {{
                    background: rgba(255,255,255,0.06);
                    color: {THEME['text_primary']};
                    border: 1px solid rgba(108,99,255,0.35);
                    border-radius: 9px; padding: 5px 10px; font-size: 12px;
                }}
                QComboBox::drop-down {{ border: none; width: 20px; }}
                QComboBox QAbstractItemView {{
                    background: {THEME['bg_elevated']};
                    color: {THEME['text_primary']};
                    selection-background-color: {THEME['accent']};
                    border: 1px solid {THEME['border_bright']};
                }}
            """)
            fl.addWidget(self.screen_combo)
            self._vsep(fl)
        else:
            self.screen_combo = None

        # Action buttons
        btn_specs = [
            ("📷  Full",     "Capture selected monitor  (Ctrl+Shift+F)", "_on_full",  THEME['accent']),
            ("✂  Snip",     "Select region  (Ctrl+Shift+X)",             "_on_snip",  "#a78bfa"),
            ("🖥  All",      "Capture all monitors",                      "_on_all",   "#38bdf8"),
            ("📝  Note",     "Add manual note  (Ctrl+Shift+N)",           "_on_note",  "#f59e0b"),
        ]

        for label, tip, handler_name, color in btn_specs:
            btn = self._make_btn(label, tip, color)
            btn.clicked.connect(getattr(self, handler_name))
            fl.addWidget(btn)

        self._vsep(fl)

        # Close
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(30, 30)
        close_btn.setToolTip("Close toolbar")
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(239,68,68,0.15);
                color: {THEME['danger']};
                border: 1px solid rgba(239,68,68,0.3);
                border-radius: 8px;
                font-weight: 700;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background: {THEME['danger']};
                color: white;
                border-color: {THEME['danger']};
            }}
        """)
        close_btn.clicked.connect(self.close)
        fl.addWidget(close_btn)

        outer.addWidget(self._frame)

    def _make_btn(self, label: str, tip: str, color: str = None) -> QPushButton:
        c = color or THEME['accent']
        btn = QPushButton(label)
        btn.setToolTip(tip)
        btn.setFixedHeight(34)
        btn.setStyleSheet(f"""
            QPushButton {{
                background: rgba(255,255,255,0.05);
                color: {THEME['text_secondary']};
                font-size: 12px; font-weight: 600;
                border: 1px solid rgba(255,255,255,0.08);
                border-radius: 9px; padding: 0 14px;
                letter-spacing: 0.3px;
            }}
            QPushButton:hover {{
                background: {c}22;
                color: {c};
                border-color: {c}66;
            }}
            QPushButton:pressed {{
                background: {c}44;
                border-color: {c};
            }}
        """)
        return btn

    def _vsep(self, layout):
        s = QFrame()
        s.setFrameShape(QFrame.Shape.VLine)
        s.setFixedHeight(26)
        s.setStyleSheet("color: rgba(108,99,255,0.2);")
        layout.addWidget(s)

    def _throttled(self, key: str, fn, delay: float = 0.6):
        now = datetime.now().timestamp()
        if now - self._throttle.get(key, 0) < delay:
            return
        self._throttle[key] = now
        fn()

    def _on_full(self):
        self._throttled("full", lambda: self.sig_full_screen.emit(
            self.screen_combo.currentIndex() if self.screen_combo else 0))

    def _on_snip(self):
        self._throttled("snip", self.sig_snip.emit)

    def _on_all(self):
        self._throttled("all", self.sig_all_screens.emit)

    def _on_note(self):
        self.sig_note.emit()

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = e.globalPosition().toPoint()

    def mouseMoveEvent(self, e):
        if e.buttons() == Qt.MouseButton.LeftButton and self._drag_pos:
            delta = e.globalPosition().toPoint() - self._drag_pos
            self.move(self.pos() + delta)
            self._drag_pos = e.globalPosition().toPoint()

    def mouseReleaseEvent(self, e):
        self._drag_pos = None

    def showEvent(self, e):
        super().showEvent(e)
        QTimer.singleShot(50, self._force_top)


# ─────────────────────────── ACTIVE SESSION POPUP ───────────────────────────
class ActiveSessionPopup(QWidget):
    """
    Pulsing 'SESSION ACTIVE' badge with  aesthetics.
    Registered in the global widget registry.
    """
    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint      |
            Qt.WindowType.WindowStaysOnTopHint     |
            Qt.WindowType.Tool                     |
            Qt.WindowType.NoDropShadowWindowHint   |
            Qt.WindowType.WindowDoesNotAcceptFocus |
            Qt.WindowType.BypassWindowManagerHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setAttribute(Qt.WidgetAttribute.WA_X11DoNotAcceptFocus, True)

        self._build_ui()
        self._position()

        self._pulse_up = True
        self._opacity  = 255
        self._pulse_timer = QTimer(self)
        self._pulse_timer.timeout.connect(self._pulse)
        self._pulse_timer.start(40)

        self._raise_timer = QTimer(self)
        self._raise_timer.timeout.connect(self._force_top)
        self._raise_timer.start(1500)

        register_ui_widget(self)

    def __del__(self):
        unregister_ui_widget(self)

    def _force_top(self):
        if self.isVisible():
            self.raise_()
            try:
                import ctypes
                flags = 0x0002 | 0x0001 | 0x0010 | 0x0040
                ctypes.windll.user32.SetWindowPos(
                    int(self.winId()), -1, 0, 0, 0, 0, flags)
            except Exception:
                pass

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)

        self._frame = QFrame()
        self._frame.setStyleSheet(f"""
            QFrame {{
                background: rgba(8,8,20,230);
                border: 1px solid rgba(108,99,255,0.6);
                border-radius: 24px;
            }}
        """)
        fl = QHBoxLayout(self._frame)
        fl.setContentsMargins(14, 7, 18, 7)
        fl.setSpacing(9)

        # Pulsing dot
        self._dot = QLabel("●")
        self._dot.setStyleSheet(f"color: {THEME['success']}; font-size: 9px;")
        fl.addWidget(self._dot)

        lbl = QLabel("SESSION  ACTIVE")
        lbl.setStyleSheet(f"""
            color: {THEME['text_primary']};
            font-size: 11px; font-weight: 700;
            letter-spacing: 2.5px;
        """)
        fl.addWidget(lbl)

        lay.addWidget(self._frame)

    def _position(self):
        sg = QGuiApplication.primaryScreen().geometry()
        self.adjustSize()
        self.move(sg.width() - self.width() - 20, sg.height() - self.height() - 56)

    def _pulse(self):
        step = 8
        if self._pulse_up:
            self._opacity = min(255, self._opacity + step)
            if self._opacity >= 255: self._pulse_up = False
        else:
            self._opacity = max(80, self._opacity - step)
            if self._opacity <= 80: self._pulse_up = True
        self._dot.setStyleSheet(
            f"color: rgba(16,185,129,{self._opacity}); font-size: 9px;"
        )

    def showEvent(self, e):
        super().showEvent(e)
        QTimer.singleShot(50, self._force_top)


# ─────────────────────────── MAIN APP ───────────────────────────
class ScreenshotApp:
    """Standalone app entry point"""

    def __init__(self):
        self.app = QApplication.instance() or QApplication(sys.argv)
        self.app.setStyleSheet(GLOBAL_STYLE)
        self.app.setApplicationName("SnapKit")

        self.save_path = "./screenshots"
        os.makedirs(self.save_path, exist_ok=True)

        self.tool    = ScreenshotTool()
        self.toolbar = FloatingToolbar()
        self.popup   = ActiveSessionPopup()

        self.tool.floating_toolbar     = self.toolbar
        self.tool.active_session_popup = self.popup

        self.toolbar.sig_full_screen.connect(self._on_full)
        self.toolbar.sig_snip.connect(self._on_snip)
        self.toolbar.sig_all_screens.connect(self._on_all)
        self.toolbar.sig_note.connect(self._on_note)

        self.toolbar.show()
        self.popup.show()

        print("✅  SnapKit v3 started")
        print(f"📁  Saving to: {os.path.abspath(self.save_path)}")
        screens = QGuiApplication.screens()
        print(f"🖥  {len(screens)} monitor(s):")
        for i, s in enumerate(screens):
            g = s.geometry()
            print(f"    Screen {i+1}: {g.width()}×{g.height()} @ {s.devicePixelRatio()}x DPR")

    def _on_full(self, screen_index: int):
        path = self.tool.capture_full_screen(self.save_path, screen_index)
        if path:
            self._open_editor(path)

    def _on_snip(self):
        path = self.tool.capture_snipping_area(self.save_path)
        if path:
            print(f"✅  Snip saved: {path}")

    def _on_all(self):
        paths = self.tool.capture_all_screens(self.save_path)
        print(f"✅  Captured {len(paths)} screens")

    def _on_note(self):
        print("📝  Note feature")

    def _open_editor(self, path: str):
        px = QPixmap(path)
        if px.isNull():
            return
        editor = AdvancedImageEditor(px)

        def on_done(result_px):
            if not result_px.isNull():
                result_px.save(path, "PNG", 100)
                print(f"✅  Edited: {path}")

        editor.editing_finished.connect(on_done)
        editor.show()
        self._editor = editor

    def run(self):
        return self.app.exec()


if __name__ == "__main__":
    app = ScreenshotApp()
    sys.exit(app.run())