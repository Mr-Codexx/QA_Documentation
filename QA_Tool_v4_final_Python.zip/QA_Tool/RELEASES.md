# Releasing updates — QA Documentation Assistant

The desktop app self-updates from a manifest served by your portal:

    https://codexqa.vercel.app/api/latest

That endpoint returns whatever you publish on the portal's **Releases** page
(stored at `/release` in Firebase). The app checks it on launch and from
**Settings → Check for Updates**, shows an Update modal, and on **Update Now**
downloads → SHA-256 verifies → installs → offers restart (auto-rollback on failure).

## Manifest format (what /api/latest returns)
```json
{ "version": "4.1.0",
  "url": "https://.../QA_Tool-4.1.0.zip",
  "sha256": "<checksum of the zip>",
  "notes": "• Faster exports\n• Bug fixes",
  "mandatory": false }
```
The app only updates when `version` is newer than the running `APP_VERSION`, and
**only accepts HTTPS** download URLs.

## Publish a new version (one-time per release)
1. **Bump the version** in `app_backend.py` → `APP_VERSION = "4.1.0"` and rebuild the app.
2. **Zip the build** so it extracts over the existing install (same folder layout).
   The app stages the zip and overlays it on the install dir, keeping a backup.
3. **Host the zip** at an HTTPS URL. Easiest: a **GitHub Release asset**
   (`https://github.com/<you>/<repo>/releases/download/v4.1.0/QA_Tool-4.1.0.zip`).
   Vercel Blob, S3, or any HTTPS host also works. (Don't host large binaries in the
   Next.js `public/` folder.)
4. **Compute the SHA-256:**
   - Windows: `certutil -hashfile QA_Tool-4.1.0.zip SHA256`
   - macOS/Linux: `shasum -a 256 QA_Tool-4.1.0.zip`
5. **Portal → Releases:** enter version, the HTTPS zip URL, the SHA-256, release
   notes, (optionally mark mandatory), then **Publish release**.

That's it — every desktop app will offer the update within seconds of its next
check. No redeploy of the portal is needed; the manifest is read live from Firebase.

## What users see
- On launch (≈2s after start) and via **Settings → Check for Updates Now**, the app
  fetches the manifest. If newer, a clean Update modal appears with your notes.
- **Update Now** → progress in the status bar → "Update Installed — restart to apply".

## Firebase rules
`/release` is public-read (so the endpoint/app can read it) and admin-write only —
already included in `database.rules.json`:
```json
"release": { ".read": true, ".write": "auth != null && root.child('admins').child(auth.uid).exists()" }
```

## Security & caveats
- HTTPS-only downloads, SHA-256 verified before install, automatic rollback on failure.
- A running single-file Windows `.exe` can't overwrite itself while open. For frozen
  builds prefer a **folder (onedir) build**, or ship a tiny external updater that swaps
  the exe after exit. Source/onedir installs update in place via the built-in flow.
